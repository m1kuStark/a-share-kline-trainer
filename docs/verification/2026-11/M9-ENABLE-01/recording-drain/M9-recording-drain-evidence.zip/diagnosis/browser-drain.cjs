const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const http = require('node:http');
const crypto = require('node:crypto');
const zlib = require('node:zlib');
const repo = String.raw`C:\Users\Stark_Du666\.codex\worktrees\m9-enable-01\a-share-kline-trainer`;
const out = path.join(String.raw`C:\Users\Stark_Du666\.codex\headroom-cache\M9-recording-related-pending-diagnosis`, 'controlled-browser');
const { createRequire } = require('node:module');
const requireRepo = createRequire(path.join(repo,'package.json'));
const esbuild = requireRepo('esbuild');
const { chromium } = requireRepo('playwright');
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
 await fsp.mkdir(out,{recursive:true});
 const srcPath=path.join(repo,'web/src/recording/recordingFile.ts');
 const raw=await fsp.readFile(srcPath); const original=raw.toString('utf8');
 const marker='  sourceReader.cancel().catch(() => {})\r\n  writer.abort().catch(() => {})\r\n  outReader.cancel().catch(() => {})\r\n  try {\r\n    await draining';
 if(original.split(marker).length!==2)throw new Error('Expected exactly one cleanup marker');
 const candidate=original.replace(marker,'  // External diagnostic candidate: finish normal output drain before cleanup.\r\n  if (!budgetHit && decompressError === null && inputError === null) await draining\r\n'+marker);
 await fsp.writeFile(path.join(out,'recordingFile.original.ts'),raw);
 await fsp.writeFile(path.join(out,'recordingFile.candidate.ts'),candidate);
 for (const [mode,contents] of [['original',original],['candidate',candidate]]) {
  await esbuild.build({stdin:{contents,resolveDir:path.dirname(srcPath),sourcefile:'recordingFile.'+mode+'.ts',loader:'ts'},bundle:true,format:'iife',globalName:mode==='original'?'OriginalRecordingFile':'CandidateRecordingFile',platform:'browser',target:'es2022',outfile:path.join(out,mode+'.bundle.js'),logLevel:'silent'});
 }
 const inputs={};
 for (const [name,run] of [['current','run-841877c0-d471-479d-8169-577c4d7a1606'],['old-green','run-d0722af9-3d20-41aa-af47-1abd04df643d']]) {
  const gzip=await fsp.readFile(path.join(repo,'.runs',run,'artifacts/screenshots/two-year-final.json.gz'));
  const plain=zlib.gunzipSync(gzip);JSON.parse(plain.toString('utf8'));
  await fsp.writeFile(path.join(out,name+'.json.gz'),gzip);
  inputs[name]={gzip,plain,compressedBytes:gzip.length,compressedSha256:sha(gzip),expectedBytes:plain.length,expectedSha256:sha(plain)};
 }
 const html='<!doctype html><meta charset="utf-8"><title>Recording drain diagnostic</title><p>Isolated local recording decoder diagnostic</p><script src="/original.bundle.js"></script><script src="/candidate.bundle.js"></script>';
 const requests=[];
 const server=http.createServer(async(req,res)=>{
  requests.push({time:new Date().toISOString(),method:req.method,url:req.url});
  if(req.method!=='GET'){res.writeHead(405);res.end();return;}
  if(req.url==='/'){res.setHeader('Content-Type','text/html; charset=utf-8');res.end(html);return;}
  if(req.url==='/favicon.ico'){res.writeHead(204);res.end();return;}
  const target={'/original.bundle.js':'original.bundle.js','/candidate.bundle.js':'candidate.bundle.js','/current.json.gz':'current.json.gz','/old-green.json.gz':'old-green.json.gz'}[req.url];
  if(!target){res.writeHead(404);res.end();return;}
  res.setHeader('Content-Type',target.endsWith('.js')?'text/javascript':'application/gzip');res.end(await fsp.readFile(path.join(out,target)));
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const baseURL='http://127.0.0.1:'+server.address().port;
 let context;
 const receipt={createdAt:new Date().toISOString(),node:process.version,sourceSha256:sha(raw),candidateSha256:sha(Buffer.from(candidate)),baseURL,inputs:Object.fromEntries(Object.entries(inputs).map(([k,{gzip,plain,...rest}])=>[k,rest])),trials:[],unexpectedRequests:[],pageErrors:[]};
 try {
  context=await chromium.launchPersistentContext(path.join(out,'edge-profile'),{channel:'msedge',headless:true,viewport:{width:1440,height:900},args:['--disable-background-networking']});
  receipt.browserVersion=context.browser()?.version()??null;
  await context.route('**/*',async route=>{const u=new URL(route.request().url());if(u.origin===baseURL)await route.continue();else {receipt.unexpectedRequests.push(u.href);await route.abort();}});
  const page=context.pages()[0]??await context.newPage();page.on('pageerror',e=>receipt.pageErrors.push(e.message));
  await page.goto(baseURL,{waitUntil:'load'});
  receipt.userAgent=await page.evaluate(()=>navigator.userAgent);
  for(const inputName of ['current','old-green']) {
   for(let iteration=1;iteration<=20;iteration++) {
    for(const mode of ['original','candidate']) {
     const trial=await page.evaluate(async ({inputName,mode,iteration})=>{
      const sha=async b=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',b))).map(x=>x.toString(16).padStart(2,'0')).join('');
      const gz=await (await fetch('/'+inputName+'.json.gz')).arrayBuffer();const blob=new Blob([gz]);
      const api=mode==='original'?window.OriginalRecordingFile:window.CandidateRecordingFile;
      const started=performance.now();const r={inputName,mode,iteration,compressedBytes:gz.byteLength,compressedSha256:await sha(gz)};
      try {const bytes=await api.inflateGzipWithBudget(blob.stream(),api.MAX_DECOMPRESSED_BYTES);r.bytes=bytes.length;r.sha256=await sha(bytes);try{const file=JSON.parse(new TextDecoder('utf8',{fatal:true}).decode(bytes));r.parse={ok:true,events:file.events.length,checkpoints:file.checkpoints.length};}catch(e){r.parse={ok:false,error:e.message};}}catch(e){r.inflateError=e.message;}
      try{const file=await api.readRecordingFile(blob);r.read={ok:true,events:file.events.length,checkpoints:file.checkpoints.length};}catch(e){r.read={ok:false,error:e.message};}
      r.durationMs=performance.now()-started;return r;
     },{inputName,mode,iteration});
     const expected=inputs[inputName];trial.byteIntegrity=trial.bytes===expected.expectedBytes&&trial.sha256===expected.expectedSha256;
     receipt.trials.push(trial);
     await fsp.appendFile(path.join(out,'trials.jsonl'),JSON.stringify(trial)+'\n');
    }
   }
  }
  receipt.summary={};
  for(const inputName of ['current','old-green'])for(const mode of ['original','candidate']){const t=receipt.trials.filter(t=>t.inputName===inputName&&t.mode===mode);receipt.summary[inputName+'/'+mode]={trials:t.length,integrityPass:t.filter(t=>t.byteIntegrity).length,parsePass:t.filter(t=>t.parse?.ok).length,readPass:t.filter(t=>t.read?.ok).length,outputByteLengths:[...new Set(t.map(t=>t.bytes))],errors:[...new Set(t.flatMap(t=>[t.inflateError,t.parse?.error,t.read?.error]).filter(Boolean))]};}
  console.log(JSON.stringify({summary:receipt.summary,browser:receipt.userAgent,unexpectedRequests:receipt.unexpectedRequests,pageErrors:receipt.pageErrors},null,2));
  receipt.nativeSuccess=true;
 }catch(e){receipt.fatal={message:e.message,stack:e.stack};process.exitCode=1;console.error(e.stack);}
 finally {if(context)await context.close();await new Promise(resolve=>server.close(resolve));receipt.requests=requests;receipt.finishedAt=new Date().toISOString();await fsp.writeFile(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2));}
})();
