from pathlib import Path
import gzip,json,hashlib,datetime,shutil
repo=Path(r'C:\Users\Stark_Du666\.codex\worktrees\m9-enable-01\a-share-kline-trainer')
out=Path(r'C:\Users\Stark_Du666\.codex\headroom-cache\M9-recording-related-pending-diagnosis')
cur=repo/'.runs/run-841877c0-d471-479d-8169-577c4d7a1606'
old=repo/'.runs/run-d0722af9-3d20-41aa-af47-1abd04df643d'
files=['e2e/recording-long.spec.ts','e2e/formula-chart.spec.ts','e2e/layout-fill.spec.ts','e2e/chart-toggles.spec.ts','e2e/pane-resize.spec.ts','playwright.config.ts','web/src/App.vue','web/src/components/RecordingLibrary.vue','web/src/components/KlineChart.vue','web/src/views/SessionReplay.vue','web/src/lib/recordingFile.ts']
hashes=[]
for rel in files:
 p=repo/rel
 if not p.exists(): continue
 raw=p.read_bytes(); dst=out/'source'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw)
 hashes.append({'path':rel,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
(out/'source-hashes.json').write_bytes(json.dumps(hashes,indent=2).encode())
def snap(run,label):
 d=out/label;d.mkdir(exist_ok=True)
 for name in ['manifest.json','run.json','artifacts/journey.log','artifacts/server.log','artifacts/browser-results.json','artifacts/screenshots/recording-two-year-metrics.json']:
  p=run/name
  if p.exists():
   dst=d/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
 return d
snap(cur,'current');snap(old,'old-green')
# Full matching source ranges stay external. Console uses a compact code transform.
ranges={'e2e/formula-chart.spec.ts':[(1,47),(444,477)],'e2e/layout-fill.spec.ts':[(1,60)],'web/src/components/KlineChart.vue':[(526,669),(2090,2144)],'web/src/views/SessionReplay.vue':[(60,82),(478,489)],'web/src/App.vue':[(130,163)],'e2e/recording-long.spec.ts':[(110,156)]}
parts=[]
for rel,rr in ranges.items():
 lines=(repo/rel).read_text(encoding='utf-8-sig').splitlines()
 for a,b in rr:
  parts.append('\n## '+rel+':'+str(a)+'-'+str(b)+'\n'+'\n'.join(str(n)+': '+lines[n-1] for n in range(a,min(b,len(lines))+1)))
(out/'source-excerpts.txt').write_bytes(('\n'.join(parts)).encode())
for label,run in [('current',cur),('old-green',old)]:
 req=[]
 p=run/'artifacts/server.log'
 if p.exists():
  for line in p.read_text(encoding='utf-8-sig',errors='replace').splitlines():
   try: x=json.loads(line)
   except: continue
   r=x.get('req') or {}
   if r.get('url','').startswith('/api/formulas') or r.get('url','').startswith('/api/settings'):
    dt=datetime.datetime.fromtimestamp(x['time']/1000,datetime.timezone(datetime.timedelta(hours=8)))
    req.append({'time':dt.isoformat(),'method':r.get('method'),'url':r.get('url'),'reqId':x.get('reqId')})
 (out/label/'formula-setting-requests.json').write_bytes(json.dumps(req,indent=2).encode())
 print(label+' formula/settings request counts: '+json.dumps({m:sum(r['method']==m for r in req) for m in ['GET','POST','PUT','PATCH','DELETE']}))
 print(label+' last mutations: '+json.dumps([r for r in req if r['method']!='GET'][-8:]))
 # Strict compact gzip summary, full original remains in run.
 gg=[]
 for name in ['two-year-initial.json.gz','two-year-final.json.gz']:
  p=run/'artifacts/screenshots'/name
  if not p.exists():continue
  raw=p.read_bytes();dec=gzip.decompress(raw);x=json.loads(dec)
  item={'file':name,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'jsonBytes':len(dec),'keys':list(x),'schemaVersion':x.get('schemaVersion'),'complete':x.get('complete'),'sessionId':x.get('sessionId'),'events':len(x.get('events',[])),'checkpoints':len(x.get('checkpoints',[])),'resources':{k:len(v) if hasattr(v,'__len__') else None for k,v in x.get('resources',{}).items()},'gaps':x.get('gaps')}
  for k in ['initialState','initial','finalState','final','meta','metadata','environment','app']:
   if k in x:item[k]=x[k]
  if x.get('checkpoints'):
   item['firstCheckpoint']=x['checkpoints'][0];item['lastCheckpoint']=x['checkpoints'][-1]
  gg.append(item)
 (out/label/'gzip-summary.json').write_bytes(json.dumps(gg,ensure_ascii=False,indent=2).encode())
 print(label+' gzip compact: '+json.dumps([{k:v for k,v in s.items() if k in ['file','schemaVersion','complete','events','checkpoints','bytes','jsonBytes','keys']} for s in gg]))
print('Saved raw sources/logs and compact derived evidence to '+str(out))
