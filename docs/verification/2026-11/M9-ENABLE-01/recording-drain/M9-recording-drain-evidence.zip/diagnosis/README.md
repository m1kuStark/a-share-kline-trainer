# M9 recording-long failure diagnosis

Updated: 2026-11-18 Asia/Shanghai. Repository inspected read-only: `C:/Users/Stark_Du666/.codex/worktrees/m9-enable-01/a-share-kline-trainer`.

## Confirmed current failure

Run `run-841877c0-d471-479d-8169-577c4d7a1606`, manifest commit `f9454fec92017eba74de2904abf9982deb685ab4`, finished its original 30-minute recording-long budget naturally. The parent observed native exit 1. Browser reporter: 18 expected, 1 unexpected, 0 flaky. No test, assertion, action timeout, or budget was changed for this diagnosis.

The precise pending await was `e2e/recording-long.spec.ts:140`: `getByRole('button', { name: '跳到最后一天' }).click()`.

The failure error-context shows the recording library, imported-recording count 0, and this alert:

> 录制文件读取失败：JSON 解析失败，文件可能被截断或不是合法 JSON（Unterminated string in JSON at position 3924624 (line 1 column 3924625)）

The import action at line 138 completed, but `readRecordingFile()` threw while parsing decoded JSON. `App.vue:146-150` catches this and shows the library error; the replay component was never mounted. The subsequent missing-button click spent the remaining test budget. This is an import failure followed by a missing-button wait, not a measured 30-minute successful import operation.

Current export is valid on disk:

- gzip SHA256 `0f9a1fde3d5514a6b0bc04f034ba14e98034eede0fd204fddd93b7b136958ee1`; 636191 bytes.
- Native gzip decompression: 4219137 bytes. Plain SHA256 `4ceacc3327caf6be72d4385c57a82b1eee14459a35e9203577966273c7706751`.
- JSON parses successfully, schemaVersion 2, complete true, 974 events, 975 checkpoints, gaps empty.
- Session `4069f57b-a9ae-404d-866b-70b18e2667ea`; settled training id 18, 600519, 2Y.
- GET `/api/trainings/18/bars?tf=1D` completed at 11:13:26.923; this is the post-export/checkpoint-inspection branch at test line 120.
- The metrics and final replay screenshot are absent because execution never reached their writes.

Do not treat the V8 JSON error offset as a verified decompressed byte count. The original browser's intermediate decompressed byte array was not captured.

## Confirmed cleanup defect and its limits

`web/src/recording/recordingFile.ts:168-172` cancels the output reader before awaiting the concurrently running output-drain loop:

```ts
sourceReader.cancel().catch(() => {})
writer.abort().catch(() => {})
outReader.cancel().catch(() => {})
try {
  await draining
```

Closing the writable side can finish while readable output remains queued. Cancelling that readable side discards the pending tail. The drain then observes done without an error, and the function returns a short byte array. JSON parsing reports the truncation afterward.

This defect is demonstrated independently by both the native Edge schedule probe and a deterministic stream test double below. The original Journey has no decompressor trace, so the evidence does not establish its exact internal microtask sequence. The native uninstrumented probe did not reproduce the original failure. The cleanup defect is the best-supported candidate for the current browser-only truncation, with an explicit remaining attribution limit.

The diagnostic candidate changes only the normal-path ordering: await `draining` when no budget/input/decompression error is present, then perform existing cleanup. Error-path interrupt handling and all fixed byte budgets are retained. This candidate exists only in this external directory; it is not a production fix or an acceptance result.

## Controlled experiments

All three scripts completed with native exit 0. A diagnostic script's exit 0 means it completed its comparisons; it does not convert intentionally failing original-decoder trials into passing product tests.

| Experiment | Original implementation | External drain-order candidate |
|---|---:|---:|
| Native Edge, current gzip, no scheduling injection | 20/20 complete bytes, SHA, JSON and read入口 | 20/20 |
| Native Edge, old GREEN gzip, no scheduling injection | 20/20 complete bytes, SHA, JSON and read入口 | 20/20 |
| Native Edge, current gzip, delay each output read by 0/1/5ms, 3 trials each | 0/9 byte integrity; all truncated JSON | 9/9 exact bytes and SHA |
| Deterministic queued-output stream double, 5 trials | 0/5; returned 192 of 4096 bytes | 5/5; exact 4096 bytes |

Native Edge version: `Edg/154.0.0.0`, headless. Each native probe used its own OS-selected loopback port and fresh persistent profile. Requests to any other origin were blocked and recorded; unexpectedRequests and pageErrors were empty. No existing app or server was contacted.

The scheduling probe still uses the native decompression algorithm and current real gzip, but explicitly wraps output `read()` to yield before pulling the next chunk. It returned 638588 or 1005427 bytes under the original implementation, with `Unterminated string in JSON`. Candidate output was always exactly 4219137 bytes with the expected SHA. These changed scheduling conditions are disclosed; this is mechanism evidence, not an unmodified Journey reproduction.

Representative original trace:

```text
writer close resolved: outputBytes=638588
outReader.cancel: outputBytes=638588
drain read done: outputBytes=638588
```

Representative candidate trace:

```text
writer close resolved: outputBytes=1005427
drain read done: outputBytes=4219137
outReader.cancel: outputBytes=4219137
```

The deterministic test double uses real WHATWG ReadableStream/WritableStream plumbing. On writable close it enqueues 64 output chunks of 64 bytes and closes the readable producer. The original implementation cancels after 128 bytes have been observed, accepts one already resolved read, then returns 192 bytes. The candidate first drains all 4096 bytes. This gives a small regression-test shape: assert exact concatenated output, and assert reader cancellation occurs only after normal drain completion. Preserve the existing over-budget/corrupt-input cancellation and deadline cases in the same suite.

## Actual earlier GREEN

Run `run-d0722af9-3d20-41aa-af47-1abd04df643d`, manifest commit `f70137182ac75635b006d567b34616cc9a9f1bd4`, ran three percent-hover tests followed by recording-long. Browser reporter: 4 expected, 0 unexpected, 0 flaky. Recording-long passed in 1.1m.

Archived metrics: 483 advances, 974 events, 975 checkpoints, gzip 635705 bytes, JSON 4218668 bytes, export 558ms, import 467ms, advance p95 112ms, restoredCheckpoints 975, unexpectedPageErrors empty.

The two runs are not the same commit and their gzip bytes differ. However, `recordingFile.ts` in both commits is byte-identical (LF SHA256 `eb66af9ede802432dd30363cc9730a9d04f086eaaeaf895851928dc7374b5b3a`). The current working-tree file differs only in CRLF line endings and is text-identical to those committed versions. Current raw SHA256 is `9ead6891f7b7dd6dd1d0ff85734f94994397228cbdb14ab7024a7b707953c4df`. Therefore do not call this decoder flaw a newly introduced f701-to-f945 regression.

## Earlier candidate boundaries checked

- Both current and old initial/final recordings have the same 1440×900/DPR1 environment, dark theme, tool null, weak magnet, multiSelect false, timeframe 1D and empty paneHeights. No observed export-state evidence supports preceding drawing-tool/maximize leakage.
- Standard Playwright page fixtures create separate browser contexts; no shared storageState/custom context is configured. The server DB is shared across this Journey, so server mutation evidence was also checked.
- The current run made 10 formula POSTs and 10 formula DELETEs. `formula-chart.spec.ts:18-27` uses finally cleanup and explicitly checks no named fixture formula remains. The final dense-formula fixture deletions completed at 11:11:17, before recording-long began at 11:12:28. This does not support leftover custom-formula panes as the cause of this import parse failure.
- API abort at test line 134 explains server silence in the offline branch. The recording import decoder operates on the uploaded Blob; its JSON parser fails before SessionReplay formula fetch or KlineChart layout-budget mounting. The new layout-budget code therefore is not on the observed failing mount path.
- These observations narrow scope; they do not prove all cross-test state is irrelevant.

## Next bounded action

Do not increase the 30-minute budget or label this failure a flake. Keep this failed gate intact. If implementation is authorized later, first add the deterministic queued-output regression to the existing `server/test/recording-file.test.ts`, verify RED against the original, then implement the minimal normal-drain ordering fix. Verify prior budget/corrupt-input cancellation cases plus actual native Edge import, then rerun the required whole related Journey under unchanged assertions/budgets. A fast explicit import-error assertion can be considered separately to improve diagnosis, but it is not the product repair and must not hide this failed gate.

## Artifact map

- `current/error-context.md`: complete original failure context.
- `current/artifacts/journey.log`, `browser-results.json`, `server.log`: raw failed run snapshots.
- `old-green/artifacts/journey.log`, `browser-results.json`, `screenshots/recording-two-year-metrics.json`: actual old GREEN.
- `current/gzip-summary.json`, `old-green/gzip-summary.json`: derived compact snapshots.
- `source/`: fixed raw relevant source snapshots, including recordingFile.ts.
- `recording-file-version-comparison.json`: current/committed text identity.
- `controlled-browser/receipt.json`, `trials.jsonl`: unmodified-native scheduling comparison; both gzip originals and source/bundles retained alongside.
- `controlled-drain-schedule/receipt.json`, `trials.jsonl`: disclosed native read-scheduling injection comparison.
- `deterministic-close-queue/receipt.json`: deterministic queued-tail comparison.
- `browser-drain.cjs`, `browser-drain-schedule.cjs`, `deterministic-close-queue.cjs`: standalone external repro scripts.
- `artifact-manifest.json`: hashes of diagnostic evidence, excluding disposable browser profiles and the manifest itself.

During the read-only diagnosis phase no repository/control/matrix file was changed. A subsequent parent-authorized RED-only phase added one regression to server/test/recording-file.test.ts, as recorded below. No running Journey was interrupted, no existing assertion or production timeout/budget was changed, and this subagent did not write a production repair.


## Authorized RED regression handoff (11:56 Asia/Shanghai)

The parent explicitly authorized only `server/test/recording-file.test.ts`. This subagent added `vi` to the existing import and one test; all pre-existing tests and assertions remain unchanged.

Test ID: `server/test/recording-file.test.ts::正常gzip关闭写端后仍排空延迟读取的全部尾块`.

The fixture is independently constructed deterministic data, 256KiB+123 bytes. It compresses through the existing real native CompressionStream helper. Its DecompressionStream subclass retains the real native decompressor and changes only output `read()` scheduling by yielding 1ms. `write`, `close`, output bytes and cancellation behavior stay native. Global stubbing is restored in `finally` with `vi.unstubAllGlobals()`.

The parent-specified exact command ran from the absolute repository root, after removing `Env:TRAINER_CONTROL_ROOT`:

```text
npx vitest run --config server/vitest.config.ts server/test/recording-file.test.ts -t '正常gzip关闭写端后仍排空延迟读取的全部尾块'
```

Native exit: **1**, for the intended behavioral assertion: expected 262267 bytes, received 262144, losing the final 123 bytes. The next assertion compares the complete output bytes using Buffer.equals. Reporter selected one test; the other 25 were filtered by `-t`, not newly skipped in source.

Product source SHA256 before and after the RED run was `9ead6891f7b7dd6dd1d0ff85734f94994397228cbdb14ab7024a7b707953c4df`, confirming the RED was obtained against the original implementation. This subagent did not change production code. Parent owns the product repair and documentation/matrix writes.

Evidence: `test-red/native.log`, `test-red/receipt.json`, `test-red/regression.patch`, and `test-red/recording-file.test.ts`. No GREEN claim is made in this handoff.
