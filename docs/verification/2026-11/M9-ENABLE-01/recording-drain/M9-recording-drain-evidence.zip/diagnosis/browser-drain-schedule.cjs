const fs=require('node:fs/promises'),path=require('node:path'),http=require('node:http'),crypto=require('node:crypto'),zlib=require('node:zlib');
const repo=String.raw`C:\Users\Stark_Du666\.codex\worktrees\m9-enable-01\a-share-kline-trainer`;
const root=String.raw`C:\Users\Stark_Du666\.codex\headroom-cache\M9-recording-related-pending-diagnosis`;
const inputDir=path.join(root,'controlled-browser'),out=path.join(root,'controlled-drain-schedule');
const {chromium}=require(require.resolve('playwright',{paths:[repo]}));
(async()=>{
 await fs.mkdir(out,{recursive:true});
 const gzip=await fs.readFile(path.join(inputDir,'current.json.gz'));const plain=zlib.gunzipSync(gzip);const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
 const receipt={createdAt:new Date().toISOString(),scope:'Native Edge decompressor with explicitly injected per-read scheduling delay; this is a mechanism probe, not unmodified Journey reproduction',inputSha256:sha(gzip),expectedBytes:plain.length,expectedSha256:sha(plain),trials:[],unexpectedRequests:[]};
 const server=http.createServer(async(req,res)=>{if(req.url==='/'){res.setHeader('Content-Type','text/html');res.end('<!doctype html><script src="/original.bundle.js"></script><script src="/candidate.bundle.js"></script>');return;}const name={'/original.bundle.js':'original.bundle.js','/candidate.bundle.js':'candidate.bundle.js','/input.gz':'current.json.gz'}[req.url];if(!name){res.writeHead(404);res.end();return;}res.setHeader('Content-Type',name.endsWith('.js')?'text/javascript':'application/gzip');res.end(await fs.readFile(path.join(inputDir,name)));});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;receipt.origin=origin;let ctx;
 try{
 ctx=await chromium.launchPersistentContext(path.join(out,'edge-profile'),{channel:'msedge',headless:true,args:['--disable-background-networking']});await ctx.route('**/*',async r=>{if(new URL(r.request().url()).origin===origin)await r.continue();else{receipt.unexpectedRequests.push(r.request().url());await r.abort();}});const page=ctx.pages()[0];await page.goto(origin);receipt.userAgent=await page.evaluate(()=>navigator.userAgent);
 for(const delayMs of [0,1,5])for(let iteration=1;iteration<=3;iteration++)for(const mode of ['original','candidate']){
 const r=await page.evaluate(async({delayMs,iteration,mode})=>{
 const Native=window.DecompressionStream;const trace=[];let outputBytes=0,readCount=0;
 window.DecompressionStream=class {constructor(format){const ds=new Native(format);const reader=ds.readable.getReader(),writer=ds.writable.getWriter();this.readable={getReader:()=>({read:async()=>{readCount++;await new Promise(resolve=>setTimeout(resolve,delayMs));const result=await reader.read();if(result.done)trace.push({event:'read-done',outputBytes});else outputBytes+=result.value.byteLength;return result;},cancel:reason=>{trace.push({event:'out-cancel',outputBytes,readCount});return reader.cancel(reason);}})};this.writable={getWriter:()=>({write:v=>writer.write(v),close:async()=>{await writer.close();trace.push({event:'close-resolved',outputBytes,readCount});},abort:reason=>writer.abort(reason)})};}};
 const gz=await(await fetch('/input.gz')).arrayBuffer();const api=mode==='original'?window.OriginalRecordingFile:window.CandidateRecordingFile;
 const result={mode,delayMs,iteration};try{const bytes=await api.inflateGzipWithBudget(new Blob([gz]).stream(),api.MAX_DECOMPRESSED_BYTES);result.bytes=bytes.length;result.sha256=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))).map(b=>b.toString(16).padStart(2,'0')).join('');try{JSON.parse(new TextDecoder('utf8',{fatal:true}).decode(bytes));result.parseOk=true;}catch(e){result.parseOk=false;result.parseError=e.message;}}catch(e){result.error=e.message;}finally{window.DecompressionStream=Native;}result.trace=trace;return result;
 },{delayMs,iteration,mode});r.integrity=r.bytes===receipt.expectedBytes&&r.sha256===receipt.expectedSha256;receipt.trials.push(r);await fs.appendFile(path.join(out,'trials.jsonl'),JSON.stringify(r)+'\n');
 }
 receipt.summary={};for(const delayMs of [0,1,5])for(const mode of ['original','candidate']){const t=receipt.trials.filter(t=>t.mode===mode&&t.delayMs===delayMs);receipt.summary[mode+'/'+delayMs+'ms']={trials:t.length,integrityPass:t.filter(t=>t.integrity).length,bytes:[...new Set(t.map(t=>t.bytes))],errors:[...new Set(t.map(t=>t.error||t.parseError).filter(Boolean))]};}
 console.log(JSON.stringify({summary:receipt.summary,firstOriginal:receipt.trials.find(t=>t.mode==='original'),firstCandidate:receipt.trials.find(t=>t.mode==='candidate')},null,2));receipt.nativeSuccess=true;
 }catch(e){receipt.fatal={message:e.message,stack:e.stack};console.error(e.stack);process.exitCode=1;}finally{if(ctx)await ctx.close();await new Promise(r=>server.close(r));receipt.finishedAt=new Date().toISOString();await fs.writeFile(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2));}
})();
