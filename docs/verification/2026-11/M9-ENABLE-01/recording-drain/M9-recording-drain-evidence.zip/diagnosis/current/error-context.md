# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: recording-long.spec.ts >> 两年前复权训练含交易画线周期切换，可压缩导出并离线回放
- Location: e2e\recording-long.spec.ts:26:1

# Error details

```
Test timeout of 1800000ms exceeded.
```

```
Error: locator.click: Test timeout of 1800000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '跳到最后一天' })

```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - complementary "主导航" [ref=f1e4]:
    - generic [ref=f1e5]: K
    - navigation [ref=f1e6]:
      - button "训练" [ref=f1e7] [cursor=pointer]
      - button "历史排行" [ref=f1e13] [cursor=pointer]:
        - generic [ref=f1e20]: 排行
      - button "历史训练" [ref=f1e21] [cursor=pointer]:
        - generic [ref=f1e26]: 历史
      - button "训练录像" [ref=f1e27] [cursor=pointer]:
        - generic [ref=f1e31]: 录像
    - button "保存并退出训练器" [ref=f1e32] [cursor=pointer]:
      - generic [ref=f1e35]: 退出
    - button "训练默认设置" [ref=f1e36] [cursor=pointer]:
      - generic [ref=f1e40]: 设置
  - main [ref=f1e41]:
    - generic [ref=f1e42]:
      - generic [ref=f1e43]: A股 K线训练器
      - generic [ref=f1e45]:
        - button "切换到浅色主题" [ref=f1e46] [cursor=pointer]
        - generic [ref=f1e54]: TDX · 截止 2026-09-16
    - region "训练录像库" [ref=f1e55]:
      - generic [ref=f1e56]:
        - generic [ref=f1e57]:
          - heading "训练录像" [level=1] [ref=f1e58]
          - paragraph [ref=f1e59]: 本机训练录像与导入的分享录像分开保存，互不覆盖。
        - button "返回训练" [ref=f1e60] [cursor=pointer]
      - generic [ref=f1e63]:
        - generic [ref=f1e64] [cursor=pointer]:
          - text: 导入分享的录像
          - button "导入录制" [ref=f1e68]
        - button "全部导出" [ref=f1e69] [cursor=pointer]
        - alert [ref=f1e73]: 录制文件读取失败：JSON 解析失败，文件可能被截断或不是合法 JSON（Unterminated string in JSON at position 3924624 (line 1 column 3924625)）
      - navigation "收藏目录" [ref=f1e74]:
        - generic [ref=f1e75]:
          - generic [ref=f1e76]: 目录
          - generic [ref=f1e77]:
            - button "全部 (1)" [pressed] [ref=f1e78] [cursor=pointer]
            - button "收藏 (0)" [ref=f1e79] [cursor=pointer]
            - button "新建目录" [ref=f1e82] [cursor=pointer]
      - generic [ref=f1e84]:
        - region "本机训练录像 (1)" [ref=f1e85]:
          - generic [ref=f1e86]:
            - heading "本机训练录像 (1)" [level=2] [ref=f1e87]
            - generic [ref=f1e88]:
              - button "批量选择" [ref=f1e89] [cursor=pointer]
              - button "清空本机录像" [ref=f1e90] [cursor=pointer]
          - list [ref=f1e91]:
            - listitem [ref=f1e92]:
              - button "加入收藏" [ref=f1e93] [cursor=pointer]
              - button [ref=f1e96] [cursor=pointer]:
                - strong [ref=f1e97]: 11/18/2026, 11:12:34 AM
                - generic [ref=f1e98]:
                  - emphasis [ref=f1e99]: 贵州茅台 · 600519
                  - text: 974 个事件 · 查看回放 →
              - button "加入目录" [ref=f1e100] [cursor=pointer]
              - button "删除录像" [ref=f1e103] [cursor=pointer]
        - region "导入的分享录像 (0)" [ref=f1e107]:
          - generic [ref=f1e108]:
            - heading "导入的分享录像 (0)" [level=2] [ref=f1e109]
            - generic [ref=f1e110]:
              - button "批量选择" [disabled] [ref=f1e111] [cursor=pointer]
              - button "清空导入录像" [disabled] [ref=f1e112]
          - status [ref=f1e113]:
            - strong [ref=f1e114]: 还没有导入分享录像
            - generic [ref=f1e115]: 使用上方「导入分享的录像」，打开收到的录像文件。
```

# Test source

```ts
  40  |       commissionRate: trainingDefaults.commissionRate ?? 0.00025,
  41  |       minimumCommission: trainingDefaults.minimumCommission ?? 5,
  42  |       stampDutyRate: trainingDefaults.stampDutyRate ?? 0.0005,
  43  |     },
  44  |   })
  45  |   expect(defaultsPut.status()).toBe(200)
  46  |   await page.goto('/')
  47  |   await page.getByPlaceholder('股票代码，如 600519').fill('600519')
  48  | await expect(page.locator(".suggestions button").first()).toBeVisible()
  49  | await page.locator(".suggestions button").first().click()
  50  |   await expect(page.getByText(/已选：/)).toBeVisible()
  51  |   await page.getByRole('button', { name: '2年', exact: true }).click()
  52  |   await page.locator('input[type="date"]').fill('2024-09-13')
  53  |   await startTrainingFromForm(page)
  54  |   const recording = page.getByRole('status').filter({ hasText: '正在记录' })
  55  |   await expect(recording).toBeVisible()
  56  |   // Fail early against the old implementation, before the costly two-year journey.
  57  |   const initialRecording = await exported(page, '导出录制', 'two-year-initial.json.gz')
  58  |   await page.getByRole('button', { name: '买入', exact: true }).click()
  59  |   // 满载启动窗口内首次点击可能落在按钮可用前；重试一次并必须确认成交，后续卖出断言才有持仓可卖
  60  |   let initialBuyFilled = false
  61  |   for (let attempt = 0; attempt < 2; attempt += 1) {
  62  |     if (attempt > 0) await page.getByRole('button', { name: '买入', exact: true }).click()
  63  |     const filled = await expect(page.locator('.status-message')).toContainText('成交', { timeout: 10_000 }).then(() => true, () => false)
  64  |     if (filled) { initialBuyFilled = true; break }
  65  |   }
  66  |   expect(initialBuyFilled).toBe(true)
  67  |   await expect(page.getByRole('button', { name: '刷新图表', exact: true })).toBeEnabled()
  68  |   await page.getByRole('button', { name: '卖出', exact: true }).click()
  69  |   await expect(page.locator('.status-message')).toHaveClass(/error-text/)
  70  |   await page.locator('.draw-toolbar').getByRole('button', { name: '线段', exact: true }).click()
  71  |   const box = await page.locator('.chart-host').boundingBox()
  72  |   await page.mouse.click(box!.x + box!.width * .35, box!.y + 140)
  73  |   await page.waitForTimeout(550)
  74  |   await page.mouse.click(box!.x + box!.width * .55, box!.y + 180)
  75  |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.drawings().length)).toBe(1)
  76  |   await expect(page.locator('.drawing-save-status')).toHaveText('已保存')
  77  |   const advanceTimes: number[] = []
  78  |   let finalSnapshot: any = null
  79  |   for (let count = 1; count <= 510; count++) {
  80  |     const started = Date.now()
  81  |     const response = page.waitForResponse(r => /\/api\/trainings\/\d+\/next$/.test(r.url()) && r.request().method() === 'POST', { timeout: 20_000 })
  82  |     await page.getByRole('button', { name: '推进下一日', exact: true }).click()
  83  |     const result = await (await response).json()
  84  |     expect(result.snapshot).toBeTruthy()
  85  |     finalSnapshot = result.snapshot
  86  |     await expect(page.getByRole('button', { name: '刷新图表', exact: true })).toBeEnabled()
  87  |     await expect(recording).toBeVisible()
  88  |     advanceTimes.push(Date.now() - started)
  89  |     if (result.settled) break
  90  |     if (count === 1) {
  91  |       await page.getByRole('button', { name: '卖出', exact: true }).click()
  92  |       await expect(page.locator('.status-message')).toContainText('成交')
  93  |       await expect(page.getByRole('button', { name: '刷新图表', exact: true })).toBeEnabled()
  94  |     }
  95  |     if (count % 60 === 0) {
  96  |       for (const name of ['周K', '月K', '日K']) {
  97  |         await page.getByRole('tab', { name, exact: true }).click()
  98  |         await expect(page.getByRole('button', { name: '刷新图表', exact: true })).toBeEnabled()
  99  |       }
  100 |     }
  101 |     if (count === 240) {
  102 |       await page.reload()
  103 |       await expect(page.locator('.training-topbar')).toBeVisible({ timeout: 30_000 })
  104 |       await expect(recording).toBeVisible({ timeout: 30_000 })
  105 |     }
  106 |   }
  107 |   expect(finalSnapshot.training.status).toBe('settled')
  108 |   expect(advanceTimes.length).toBeGreaterThan(450)
  109 |   // 自然到期同样出现结算结果面板，「保留到本机训练历史」默认勾选（返修合同行为3）
  110 |   await expectSettledResultsDialog(page)
  111 |   const output = await exported(page, '导出本场录制', 'two-year-final.json.gz')
  112 |   const file = output.file
  113 |   expect(file.sessionId).toBe(initialRecording.file.sessionId)
  114 |   expect(file.events.filter(event => event.action === 'training.advance' && event.phase === 'started')).toHaveLength(advanceTimes.length)
  115 |   expect(file.gaps).toEqual([])
  116 |   const reader = new CompactReader(file)
  117 |   const last = reader.checkpointAt(file.checkpoints.length - 1)
  118 |   expect(last.training?.account).toEqual(finalSnapshot.account)
  119 |   // The chart query additionally supplies chartPrice in the current adjustment basis.
  120 |   const displayed = await (await page.request.get(`/api/trainings/${finalSnapshot.training.id}/bars?tf=1D`)).json()
  121 |   expect(last.training?.trades).toEqual(displayed.trades)
  122 |   expect(last.training?.trades.map(({ chartPrice: _chartPrice, ...trade }) => trade)).toEqual(finalSnapshot.trades)
  123 |   expect(last.chart?.drawings.length).toBe(1)
  124 |   expect(file.events.some(e => e.action === 'training.trade' && e.outcome === 'rejected')).toBe(true)
  125 |   for (let i = 0; i < file.checkpoints.length; i++) {
  126 |     const checkpoint = reader.checkpointAt(i)
  127 |     if (!checkpoint.chart) continue
  128 |     const cutoff = checkpoint.training!.training.currentDate!
  129 |     expect(checkpoint.chart.bars.every(bar => (bar.date.length === 7 ? `${bar.date}-01` : bar.date) <= cutoff)).toBe(true)
  130 |   }
  131 |   await page.getByRole('button', { name: '完成，返回首页', exact: true }).click()
  132 |   await page.getByRole('button', { name: '训练录像', exact: true }).click()
  133 |   await expect(page.getByRole('heading', { name: '训练录像', exact: true })).toBeVisible()
  134 |   await page.route('**/api/**', route => route.abort())
  135 |   const writes: string[] = []
  136 |   page.on('request', request => { const url = request.url(); if (/\/api\//.test(url) && ['POST','PUT','DELETE'].includes(request.method()) && !/\/api\/diagnostics\/events$/.test(url)) writes.push(url) })
  137 |   const importedAt = Date.now()
  138 |   await page.getByLabel('导入录制', { exact: true }).setInputFiles(output.path)
  139 |   // REC-03 按日回放：跳到最后一天后画线仍在，且 b/Delete/鼠标都改不动（只读）
> 140 |   await page.getByRole('button', { name: '跳到最后一天' }).click()
      |                                                      ^ Error: locator.click: Test timeout of 1800000ms exceeded.
  141 |   await expect(page.locator('.replay-day')).toHaveText(/第 \d+ \/ \d+ 日/)
  142 |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart?.drawings().length)).toBe(1)
  143 |   const importMs = Date.now() - importedAt
  144 |   await page.keyboard.press('b')
  145 |   await page.keyboard.press('Delete')
  146 |   await page.screenshot({ path: evidencePath('recording-two-year-replay.png') })
  147 |   expect(writes).toEqual([])
  148 |   expect(pageErrors).toEqual([])
  149 |   const sorted = [...advanceTimes].sort((a,b) => a-b)
  150 |   await writeFile(evidencePath('recording-two-year-metrics.json'), JSON.stringify({
  151 |     steps: advanceTimes.length, events: file.events.length, checkpoints: file.checkpoints.length,
  152 |     fileBytes: (await stat(output.path)).size, jsonBytes: Buffer.byteLength(JSON.stringify(file)),
  153 |     exportMs: output.durationMs, importMs, advanceP95Ms: sorted[Math.floor(sorted.length*.95)],
  154 |     restoredCheckpoints: file.checkpoints.length, unexpectedPageErrors: pageErrors,
  155 |   }, null, 2))
  156 | })
  157 | 
```