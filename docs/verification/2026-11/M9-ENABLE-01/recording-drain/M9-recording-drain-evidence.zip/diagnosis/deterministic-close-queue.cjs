const fs=require('node:fs/promises'),path=require('node:path'),crypto=require('node:crypto');
const repo=String.raw`C:\Users\Stark_Du666\.codex\worktrees\m9-enable-01\a-share-kline-trainer`,root=String.raw`C:\Users\Stark_Du666\.codex\headroom-cache\M9-recording-related-pending-diagnosis`;
const {build}=require(require.resolve('esbuild',{paths:[repo]}));
(async()=>{
 const out=path.join(root,'deterministic-close-queue');await fs.mkdir(out,{recursive:true});const receipt={scope:'Deterministic decompressor test double: writable closes after queuing 64 output chunks; readable still must drain',trials:[]};
 for(const mode of ['original','candidate']){const contents=await fs.readFile(path.join(root,'controlled-browser','recordingFile.'+mode+'.ts'),'utf8');await build({stdin:{contents,resolveDir:path.join(repo,'web/src/recording'),sourcefile:'recordingFile.'+mode+'.ts',loader:'ts'},bundle:true,platform:'node',format:'cjs',outfile:path.join(out,mode+'.cjs'),logLevel:'silent'});}
 const expected=Uint8Array.from({length:4096},(_,i)=>i%251);const sha=b=>crypto.createHash('sha256').update(b).digest('hex');receipt.expectedBytes=expected.length;receipt.expectedSha256=sha(expected);
 const Native=globalThis.DecompressionStream;
 try{for(let iteration=1;iteration<=5;iteration++)for(const mode of ['original','candidate']){
 const trace=[];let readBytes=0;
 globalThis.DecompressionStream=class{constructor(){let controller;const readable=new ReadableStream({start(c){controller=c;}});const writable=new WritableStream({write(){},close(){for(let i=0;i<expected.length;i+=64)controller.enqueue(expected.slice(i,i+64));controller.close();trace.push({event:'sink-close-queued-64-chunks',readBytes});}});const reader=readable.getReader(),writer=writable.getWriter();this.readable={getReader:()=>({read:async()=>{const r=await reader.read();if(!r.done)readBytes+=r.value.byteLength;else trace.push({event:'read-done',readBytes});return r;},cancel:reason=>{trace.push({event:'out-cancel',readBytes});return reader.cancel(reason);}})};this.writable={getWriter:()=>({write:b=>writer.write(b),close:async()=>{await writer.close();trace.push({event:'writer-close-settled',readBytes});},abort:r=>writer.abort(r)})};}};
 const api=require(path.join(out,mode+'.cjs'));const input=new ReadableStream({start(c){c.enqueue(new Uint8Array([1]));c.close();}});const bytes=await api.inflateGzipWithBudget(input,256*1024*1024);receipt.trials.push({mode,iteration,bytes:bytes.length,sha256:sha(bytes),integrity:bytes.length===expected.length&&sha(bytes)===receipt.expectedSha256,trace});
 }}finally{globalThis.DecompressionStream=Native;}
 receipt.summary=Object.fromEntries(['original','candidate'].map(mode=>{const t=receipt.trials.filter(t=>t.mode===mode);return[mode,{trials:t.length,integrityPass:t.filter(t=>t.integrity).length,bytes:[...new Set(t.map(t=>t.bytes))]}];}));
 await fs.writeFile(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2));console.log(JSON.stringify({summary:receipt.summary,firstOriginal:receipt.trials.find(t=>t.mode==='original'),firstCandidate:receipt.trials.find(t=>t.mode==='candidate')},null,2));
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
