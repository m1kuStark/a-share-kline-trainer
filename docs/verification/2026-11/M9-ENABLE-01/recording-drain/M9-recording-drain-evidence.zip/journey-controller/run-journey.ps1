param([Parameter(Mandatory)][string]$Label,[string[]]$Cases=@('e2e/formula-chart.spec.ts'),[string]$Grep='dense formula panes')
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$taskRepo='C:/Users/Stark_Du666/.codex/worktrees/m9-enable-01/a-share-kline-trainer'
$taskRoot='C:/Users/Stark_Du666/.codex/headroom-cache/M9-pane-layout-preparation'
$taskLog=Join-Path $taskRoot ($Label+'.log')
$taskReceipt=Join-Path $taskRoot ($Label+'.receipt.json')
if((Test-Path -LiteralPath $taskLog) -or (Test-Path -LiteralPath $taskReceipt)){throw 'Fresh label required'}
Set-Location -LiteralPath $taskRepo
Remove-Item Env:TRAINER_CONTROL_ROOT -ErrorAction SilentlyContinue
$env:TDX_ROOT=Join-Path $taskRepo '.runs/run-89c83849-aaae-4f07-a5cd-7cd58edf29f8/tdx-snapshot'
if(!(Test-Path -LiteralPath $env:TDX_ROOT)){throw 'Expected isolated sample missing'}
$taskArgs=@('run','journey','--')+$Cases+@('--retries=0','--forbid-only')
if($Grep){$taskArgs+=@('--grep',$Grep)}
$taskResult=[ordered]@{label=$Label;startedAt=(Get-Date).ToUniversalTime().ToString('o');repo=$taskRepo;commit=(git rev-parse HEAD);tdxRoot=$env:TDX_ROOT;command=@('npm.cmd')+$taskArgs;diff=(git diff --stat);scriptSha256=(Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()}
& npm.cmd @taskArgs > $taskLog 2>&1
$taskExit=$LASTEXITCODE
$taskResult.nativeExitCode=$taskExit
$taskResult.endedAt=(Get-Date).ToUniversalTime().ToString('o')
$taskResult.logSha256=(Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLowerInvariant()
$taskResult | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $taskReceipt -Encoding utf8NoBOM
Get-Content -LiteralPath $taskLog -Tail 35
Write-Output "nativeExit=$taskExit"
exit $taskExit
