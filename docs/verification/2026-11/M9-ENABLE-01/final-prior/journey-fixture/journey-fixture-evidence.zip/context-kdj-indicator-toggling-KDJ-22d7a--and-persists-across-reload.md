# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: kdj-indicator.spec.ts >> toggling KDJ off/on takes effect immediately and persists across reload
- Location: e2e\kdj-indicator.spec.ts:72:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 4
Received: 5

Call Log:
- Timeout 15000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary "主导航" [ref=e4]:
    - generic [ref=e5]: K
    - navigation [ref=e6]:
      - button "训练" [ref=e7] [cursor=pointer]
      - button "历史排行" [ref=e13] [cursor=pointer]:
        - generic [ref=e20]: 排行
      - button "历史训练" [ref=e21] [cursor=pointer]:
        - generic [ref=e26]: 历史
      - button "训练录像" [ref=e27] [cursor=pointer]:
        - generic [ref=e31]: 录像
    - button "保存并退出训练器" [ref=e32] [cursor=pointer]:
      - generic [ref=e35]: 退出
    - button "训练默认设置" [ref=e36] [cursor=pointer]:
      - generic [ref=e40]: 设置
  - main [ref=e41]:
    - generic [ref=e42]:
      - generic [ref=e43]: A股 K线训练器
      - generic [ref=e45]:
        - generic [ref=e47]:
          - generic [ref=e48]:
            - checkbox "记录操作" [checked] [ref=e49]
            - text: 记录操作
          - status [ref=e50]: 正在记录 · 0 次操作
          - button "导出录制" [ref=e51] [cursor=pointer]
        - button "切换到浅色主题" [ref=e52] [cursor=pointer]
        - generic [ref=e60]: TDX · 截止 2026-09-16
    - generic [ref=e61]:
      - generic [ref=e62]:
        - generic [ref=e63]:
          - generic "贵州茅台 · 600519" [ref=e65]
          - generic [ref=e66]:
            - text: 当前
            - strong [ref=e67]: 2025-01-02
          - tablist "K线周期" [ref=e68]:
            - tab "日K" [selected] [ref=e69] [cursor=pointer]
            - tab "周K" [ref=e70] [cursor=pointer]
            - tab "月K" [ref=e71] [cursor=pointer]
          - group "副图指标开关" [ref=e72]:
            - button "VOL" [pressed] [ref=e73] [cursor=pointer]
            - button "MACD" [pressed] [ref=e74] [cursor=pointer]
            - button "KDJ" [pressed] [ref=e75] [cursor=pointer]
            - button "多空反转" [ref=e76] [cursor=pointer]
          - group [ref=e77]:
            - generic "训练详情" [ref=e78] [cursor=pointer]
        - generic [ref=e81]:
          - button "划线" [pressed] [ref=e82] [cursor=pointer]
          - button "日线数据更新：最新交易日待确认，点击重新读取本地日线" [ref=e86] [cursor=pointer]: 更新
          - button "刷新图表" [ref=e87] [cursor=pointer]
          - button "回到最新K线" [ref=e93] [cursor=pointer]
          - button "推进下一日" [ref=e96] [cursor=pointer]
          - button "提前结算" [ref=e99] [cursor=pointer]
          - button "放弃训练" [ref=e100] [cursor=pointer]
      - generic [ref=e101]:
        - generic "训练就绪" [ref=e102]
        - group "K线行情" [ref=e104]:
          - generic [ref=e105]: 日K 2025-01-02 周四
          - generic [ref=e106]: 开 1524.00
          - generic [ref=e107]: 高 1524.49
          - generic [ref=e108]: 低 1480.00
          - generic [ref=e109]: 收 1488.00
          - generic [ref=e110]: 日涨幅 -2.36%
          - generic [ref=e111]: 最近已知K线
        - generic "空格：推进下一日；[ / ]：日周月周期；Home：回到最新；↑ / ↓：缩放；Shift+← / →：平移视图；Del：删除选中画线；B / S：买入卖出；Ctrl+Z / Ctrl+Y：撤销重做。输入、弹窗和画线取点期间部分快捷键暂停。" [ref=e112]: 空格 下一日 · [ ] 周期 · Home 最新 · ↑↓ 缩放 · Shift←→ 平移 · Del 删线
        - generic [ref=e113]: 可见至 2025-01-02 周四
        - generic "当前同屏K线根数 / 同屏上限" [ref=e114]: 152 / 840 根
      - generic [ref=e115]:
        - generic [ref=e117]:
          - button "设置均线" [ref=e119] [cursor=pointer]: MA 设置
          - group "成交标记" [ref=e169]
        - complementary [ref=e170]:
          - generic [ref=e171]:
            - generic [ref=e172]:
              - generic [ref=e173]: 训练账户
              - generic [ref=e174]: ● 进行中
            - generic [ref=e175]:
              - generic [ref=e176]: 账户权益
              - strong [ref=e177]:
                - generic [ref=e178]: ¥100,000,000
              - emphasis [ref=e179]:
                - generic [ref=e180]: +0.00%
            - generic [ref=e181]:
              - generic [ref=e182]:
                - generic [ref=e183]: 可用资金
                - strong [ref=e184]: ¥100,000,000
              - generic [ref=e185]:
                - generic [ref=e186]: 持仓市值
                - strong [ref=e187]: ¥0
              - generic [ref=e188]:
                - generic [ref=e189]: 持仓（可卖）
                - strong [ref=e190]: 0（0）
              - generic [ref=e191]:
                - generic [ref=e192]: 摊薄成本
                - strong [ref=e193]: "--"
            - generic [ref=e195]:
              - tablist "下单方式" [ref=e196]:
                - tab "普通下单" [selected] [ref=e197] [cursor=pointer]
              - generic [ref=e198]: 按当日收盘价成交
            - generic [ref=e199]:
              - button "10%" [ref=e200] [cursor=pointer]
              - button "20%" [ref=e201] [cursor=pointer]
              - button "25%" [ref=e202] [cursor=pointer]
              - button "30%" [ref=e203] [cursor=pointer]
              - button "50%" [ref=e204] [cursor=pointer]
              - button "75%" [ref=e205] [cursor=pointer]
              - button "100%" [ref=e206] [cursor=pointer]
              - spinbutton "自定义%" [ref=e207]
            - generic [ref=e208]:
              - spinbutton "按股数买卖" [ref=e209]
              - generic [ref=e210]: 留空则按左侧比例
            - generic [ref=e211]:
              - button "买入" [ref=e212] [cursor=pointer]
              - button "卖出" [ref=e213] [cursor=pointer]
          - generic [ref=e214]:
            - generic [ref=e215]:
              - button "折叠画线工具条" [expanded] [ref=e224] [cursor=pointer]
              - generic [ref=e227]: 常用工具
              - button "自定义常用" [ref=e228] [cursor=pointer]
              - button "固定工具面板" [ref=e232] [cursor=pointer]
            - generic [ref=e235]:
              - generic [ref=e236]:
                - button "线段" [ref=e238] [cursor=pointer]
                - button "射线" [ref=e245] [cursor=pointer]
                - button "直线" [ref=e252] [cursor=pointer]
                - button "水平直线" [ref=e257] [cursor=pointer]
                - button "垂直直线" [ref=e261] [cursor=pointer]
                - button "价位线" [ref=e265] [cursor=pointer]
                - button "百分比线" [ref=e269] [cursor=pointer]
              - button "其他工具 16" [expanded] [ref=e275] [cursor=pointer]:
                - text: 其他工具
                - generic [ref=e278]: "16"
              - generic [ref=e279]:
                - button "水平线段" [ref=e281] [cursor=pointer]
                - button "水平射线" [ref=e287] [cursor=pointer]
                - button "垂直线段" [ref=e293] [cursor=pointer]
                - button "垂直射线" [ref=e299] [cursor=pointer]
                - button "平行直线" [ref=e305] [cursor=pointer]
                - button "价格通道线" [ref=e311] [cursor=pointer]
                - button "斐波那契线" [ref=e317] [cursor=pointer]
                - button "画笔" [ref=e321] [cursor=pointer]
                - button "矩形" [ref=e326] [cursor=pointer]
                - button "圆圈" [ref=e331] [cursor=pointer]
                - button "圆弧" [ref=e336] [cursor=pointer]
                - button "箭头线" [ref=e341] [cursor=pointer]
                - button "看涨箭头" [ref=e347] [cursor=pointer]
                - button "看跌箭头" [ref=e353] [cursor=pointer]
                - button "诅咒线" [ref=e359] [cursor=pointer]
                - button "文本" [ref=e364] [cursor=pointer]
            - generic [ref=e368]:
              - button "多选" [ref=e369] [cursor=pointer]
              - button "撤销" [disabled] [ref=e370]
              - button "重做" [disabled] [ref=e374]
              - button "清空" [ref=e378] [cursor=pointer]
              - combobox "吸附" [ref=e382]:
                - option "关闭"
                - option "弱吸附" [selected]
                - option "强吸附"
            - status "已保存" [ref=e384]
            - separator "调整工具面板尺寸（拖动调整宽高，双击恢复默认）" [ref=e385]
```

# Test source

```ts
  1   | import { evidencePath } from './runtime'
  2   | import { expect, test, type Page } from '@playwright/test'
  3   | 
  4   | // M6-01 KDJ 副图（通达信口径）真实浏览器回归：
  5   | // ① 默认偏好开启时 KDJ 副图随 VOL/MACD 同等挂载（窗格语义名/几何）；
  6   | // ② 开关（M6-04 起迁至训练页周期按钮行 .indicator-toggles）立即增删窗格并持久化
  7   | //    （localStorage + 刷新后保持；按钮可寻址名不变，断言无需随位置改写）；
  8   | // ③ KDJ 副图与既有窗格交互语义同等：框选缩放可从 KDJ 窗格启动、双击最大化/还原、
  9   | //    画线可落在 KDJ 窗格并以语义名 'KDJ' 保存/恢复。
  10  | // 数值口径（RSV/SMA 平滑/种子 50）由 server/test/kdj-indicator.test.ts 的独立 oracle 锁定，
  11  | // 本套件不重复数值断言。真实鼠标事件驱动；__trainerChart 只读。
  12  | 
  13  | type Pane = { id: string; name: string; top: number; height: number; width: number; left: number }
  14  | const errors = new WeakMap<Page, string[]>()
  15  | 
  16  | test.beforeEach(({ page }) => {
  17  |   const list: string[] = []
  18  |   errors.set(page, list)
  19  |   page.on('pageerror', error => list.push(error.message))
  20  | })
  21  | test.afterEach(({ page }) => { expect(errors.get(page)).toEqual([]) })
  22  | 
  23  | async function openChart(page: Page): Promise<void> {
  24  |   const active = await (await page.request.get('/api/trainings/active')).json()
  25  |   if (active.training) await page.request.post(`/api/trainings/${active.training.id}/abandon`)
  26  |   const response = await page.request.post('/api/trainings', {
  27  |     data: { code: '600519', tier: '1Y', start_date: '2025-01-02', initial_cash: 100_000_000 },
  28  |   })
  29  |   expect(response.status()).toBe(201)
  30  |   await page.goto('/')
  31  |   await expect(page.locator('.training-current-date')).toBeVisible({ timeout: 15_000 })
  32  |   await expect(page.locator('.drawing-save-status')).toHaveText('已保存')
  33  |   await expect(page.locator('.loading-dot')).not.toBeVisible()
  34  |   // 默认偏好（开）：candle/VOL/MACD/KDJ 四个绘图窗格
> 35  |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart?.panes().length)).toBe(4)
      |                                                                                                ^ Error: expect(received).toBe(expected) // Object.is equality
  36  | }
  37  | 
  38  | // UI-TOOLBAR-01/02 起划线工具面板是默认左下停靠的浮层，会盖住图表左下区域（KDJ 窗格所在处）；
  39  | // 涉及图表取点/双击窗格的几何用例先隐藏浮层，取工具时再显示（真实用户也可随时隐藏/拖动）。
  40  | async function setToolbarVisible(page: Page, visible: boolean): Promise<void> {
  41  |   const shown = await page.locator('.draw-toolbar').isVisible()
  42  |   if (shown !== visible) await page.locator('.draw-toolbar-toggle').click()
  43  | }
  44  | function kdjButton(page: Page) { return page.getByRole('button', { name: 'KDJ', exact: true }) }
  45  | 
  46  | async function panes(page: Page): Promise<Pane[]> {
  47  |   return page.evaluate(() => (window as any).__trainerChart.panes())
  48  | }
  49  | 
  50  | async function kdjPane(page: Page): Promise<Pane> {
  51  |   const pane = (await panes(page)).find(item => item.name === 'KDJ')
  52  |   expect(pane, 'KDJ 副图窗格').toBeTruthy()
  53  |   return pane!
  54  | }
  55  | 
  56  | test('KDJ subchart mounts by default with the VOL/MACD panes intact', async ({ page }) => {
  57  |   await openChart(page)
  58  |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.indicatorPanes()))
  59  |     .toEqual(['candle_pane', 'VOL', 'MACD', 'KDJ'])
  60  |   const [candle, vol, macd, kdj] = await panes(page)
  61  |   expect(candle.height).toBeGreaterThan(0)
  62  |   expect(vol.height).toBeGreaterThan(0)
  63  |   expect(macd.height).toBeGreaterThan(0)
  64  |   // 副图高度同量级（KDJ 与 VOL/MACD 等高带），主图仍占大头
  65  |   expect(kdj.height).toBeGreaterThan(40)
  66  |   expect(candle.height).toBeGreaterThan(kdj.height)
  67  |   await expect(kdjButton(page)).toHaveAttribute('aria-pressed', 'true')
  68  |   await expect(kdjButton(page)).not.toHaveClass(/off/)
  69  |   await page.screenshot({ path: evidencePath('kdj-subchart-default.png') })
  70  | })
  71  | 
  72  | test('toggling KDJ off/on takes effect immediately and persists across reload', async ({ page }) => {
  73  |   await openChart(page)
  74  |   const expectedWithoutKdj = ['candle_pane', 'VOL', 'MACD']
  75  |   // 关闭：立即生效（窗格移除）＋持久化
  76  |   await kdjButton(page).click()
  77  |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.indicatorPanes())).toEqual(expectedWithoutKdj)
  78  |   await expect(kdjButton(page)).toHaveAttribute('aria-pressed', 'false')
  79  |   await expect(kdjButton(page)).toHaveClass(/off/)
  80  |   expect(await page.evaluate(() => localStorage.getItem('trainer_kdj_subchart'))).toBe('0')
  81  |   // 刷新：偏好保持关闭（不属于录像布局，按当前开关渲染）
  82  |   await page.reload()
  83  |   await expect(page.locator('.training-current-date')).toBeVisible({ timeout: 15_000 })
  84  |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart?.indicatorPanes?.() ?? null)).toEqual(expectedWithoutKdj)
  85  |   // 重新开启：窗格回来，偏好写回 '1'
  86  |   await kdjButton(page).click()
  87  |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.indicatorPanes()))
  88  |     .toEqual(['candle_pane', 'VOL', 'MACD', 'KDJ'])
  89  |   expect(await page.evaluate(() => localStorage.getItem('trainer_kdj_subchart'))).toBe('1')
  90  |   await page.screenshot({ path: evidencePath('kdj-subchart-toggled-back-on.png') })
  91  | })
  92  | 
  93  | test('KDJ pane participates in box select, dbl-click maximize and drawing like other panes', async ({ page }) => {
  94  |   await openChart(page)
  95  |   await setToolbarVisible(page, false)
  96  |   const host = await page.locator('.chart-host').boundingBox()
  97  |   expect(host).not.toBeNull()
  98  | 
  99  |   // ① 框选缩放从 KDJ 窗格启动（绘图 pane 同权）：选中框 DOM 可见，松手后可见根数变少
  100 |   const before = await page.evaluate(() => (window as any).__trainerChart.visibleRange())
  101 |   const kdj = await kdjPane(page)
  102 |   const y = host!.y + kdj.top + kdj.height / 2
  103 |   await page.mouse.move(host!.x + kdj.width * .62, y)
  104 |   await page.mouse.down()
  105 |   await page.mouse.move(host!.x + kdj.width * .92, y, { steps: 12 })
  106 |   await expect(page.locator('.select-rect')).toBeVisible()
  107 |   await page.mouse.up()
  108 |   await expect(page.locator('.select-rect')).not.toBeVisible()
  109 |   await expect.poll(() => {
  110 |     const range = page.evaluate(() => (window as any).__trainerChart.visibleRange())
  111 |     return range
  112 |   }).not.toEqual(before)
  113 |   const after = await page.evaluate(() => (window as any).__trainerChart.visibleRange())
  114 |   expect(after.to - after.from).toBeLessThan(before.to - before.from)
  115 | 
  116 |   // ② 双击 KDJ 窗格：最大化（其余窗格高度归零），再双击还原
  117 |   await page.mouse.dblclick(host!.x + kdj.width * .72, host!.y + kdj.top + kdj.height * .5)
  118 |   await expect.poll(async () => (await panes(page))[0].height).toBe(0)
  119 |   await page.mouse.dblclick(host!.x + kdj.width * .72, host!.y + 100)
  120 |   await expect.poll(async () => (await panes(page))[0].height).toBeGreaterThan(0)
  121 | 
  122 |   // ③ 画线落在 KDJ 窗格：语义 paneId='KDJ'，保存刷新后按语义名恢复回 KDJ 窗格
  123 |   await setToolbarVisible(page, true)
  124 |   const button = page.locator('[data-tool-name="segment"]')
  125 |   if (!await button.isVisible()) await page.locator('.other-tools-toggle').click()
  126 |   await button.click()
  127 |   const pane = await kdjPane(page)
  128 |   // 取点留在右侧，避开左下悬浮工具面板（隐藏面板会取消画线工具，故不隐藏）
  129 |   await page.mouse.click(host!.x + pane.width * .62, host!.y + pane.top + pane.height * .3)
  130 |   await page.waitForTimeout(560)
  131 |   await page.mouse.click(host!.x + pane.width * .85, host!.y + pane.top + pane.height * .7)
  132 |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.drawings().length)).toBe(1)
  133 |   const saved = await page.evaluate(() => (window as any).__trainerChart.drawings())
  134 |   expect(saved[0].paneId).toBe('KDJ')
  135 |   await expect(page.locator('.drawing-save-status')).toHaveText('已保存')
```