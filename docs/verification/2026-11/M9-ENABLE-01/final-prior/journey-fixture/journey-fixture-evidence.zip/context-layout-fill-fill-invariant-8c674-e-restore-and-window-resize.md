# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: layout-fill.spec.ts >> fill invariants survive MACD toggle, maximize/restore and window resize
- Location: e2e\layout-fill.spec.ts:206:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 4
Received: 5

Call Log:
- Timeout 15000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary "主导航" [ref=e4]:
    - generic [ref=e5]: K
    - navigation [ref=e6]:
      - button "训练" [ref=e7] [cursor=pointer]
      - button "历史排行" [ref=e13] [cursor=pointer]:
        - generic [ref=e20]: 排行
      - button "历史训练" [ref=e21] [cursor=pointer]:
        - generic [ref=e26]: 历史
      - button "训练录像" [ref=e27] [cursor=pointer]:
        - generic [ref=e31]: 录像
    - button "保存并退出训练器" [ref=e32] [cursor=pointer]:
      - generic [ref=e35]: 退出
    - button "训练默认设置" [ref=e36] [cursor=pointer]:
      - generic [ref=e40]: 设置
  - main [ref=e41]:
    - generic [ref=e42]:
      - generic [ref=e43]: A股 K线训练器
      - generic [ref=e45]:
        - generic [ref=e47]:
          - generic [ref=e48]:
            - checkbox "记录操作" [checked] [ref=e49]
            - text: 记录操作
          - status [ref=e50]: 正在记录 · 0 次操作
          - button "导出录制" [ref=e51] [cursor=pointer]
        - button "切换到浅色主题" [ref=e52] [cursor=pointer]
        - generic [ref=e60]: TDX · 截止 2026-09-16
    - generic [ref=e61]:
      - generic [ref=e62]:
        - generic [ref=e63]:
          - generic "贵州茅台 · 600519" [ref=e65]
          - generic [ref=e66]:
            - text: 当前
            - strong [ref=e67]: 2024-09-13
          - tablist "K线周期" [ref=e68]:
            - tab "日K" [selected] [ref=e69] [cursor=pointer]
            - tab "周K" [ref=e70] [cursor=pointer]
            - tab "月K" [ref=e71] [cursor=pointer]
          - group "副图指标开关" [ref=e72]:
            - button "VOL" [pressed] [ref=e73] [cursor=pointer]
            - button "MACD" [pressed] [ref=e74] [cursor=pointer]
            - button "KDJ" [pressed] [ref=e75] [cursor=pointer]
            - button "多空反转" [ref=e76] [cursor=pointer]
          - group [ref=e77]:
            - generic "训练详情" [ref=e78] [cursor=pointer]
        - generic [ref=e81]:
          - button "划线" [pressed] [ref=e82] [cursor=pointer]
          - button "日线数据更新：最新交易日待确认，点击重新读取本地日线" [ref=e86] [cursor=pointer]: 更新
          - button "刷新图表" [ref=e87] [cursor=pointer]
          - button "回到最新K线" [ref=e93] [cursor=pointer]
          - button "推进下一日" [ref=e96] [cursor=pointer]
          - button "提前结算" [ref=e99] [cursor=pointer]
          - button "放弃训练" [ref=e100] [cursor=pointer]
      - generic [ref=e101]:
        - generic "训练就绪" [ref=e102]
        - group "K线行情" [ref=e104]:
          - generic [ref=e105]: 日K 2024-09-13 周五
          - generic [ref=e106]: 开 1331.00
          - generic [ref=e107]: 高 1332.00
          - generic [ref=e108]: 低 1297.30
          - generic [ref=e109]: 收 1304.13
          - generic [ref=e110]: 日涨幅 -2.32%
          - generic [ref=e111]: 最近已知K线
        - generic "空格：推进下一日；[ / ]：日周月周期；Home：回到最新；↑ / ↓：缩放；Shift+← / →：平移视图；Del：删除选中画线；B / S：买入卖出；Ctrl+Z / Ctrl+Y：撤销重做。输入、弹窗和画线取点期间部分快捷键暂停。" [ref=e112]: 空格 下一日 · [ ] 周期 · Home 最新 · ↑↓ 缩放 · Shift←→ 平移 · Del 删线
        - generic [ref=e113]: 可见至 2024-09-13 周五
        - generic "当前同屏K线根数 / 同屏上限" [ref=e114]: 152 / 840 根
      - generic [ref=e115]:
        - generic [ref=e117]:
          - button "设置均线" [ref=e119] [cursor=pointer]: MA 设置
          - group "成交标记" [ref=e169]
        - complementary [ref=e170]:
          - generic [ref=e171]:
            - generic [ref=e172]:
              - generic [ref=e173]: 训练账户
              - generic [ref=e174]: ● 进行中
            - generic [ref=e175]:
              - generic [ref=e176]: 账户权益
              - strong [ref=e177]:
                - generic [ref=e178]: ¥1,000,000
              - emphasis [ref=e179]:
                - generic [ref=e180]: +0.00%
            - generic [ref=e181]:
              - generic [ref=e182]:
                - generic [ref=e183]: 可用资金
                - strong [ref=e184]: ¥1,000,000
              - generic [ref=e185]:
                - generic [ref=e186]: 持仓市值
                - strong [ref=e187]: ¥0
              - generic [ref=e188]:
                - generic [ref=e189]: 持仓（可卖）
                - strong [ref=e190]: 0（0）
              - generic [ref=e191]:
                - generic [ref=e192]: 摊薄成本
                - strong [ref=e193]: "--"
            - generic [ref=e195]:
              - tablist "下单方式" [ref=e196]:
                - tab "普通下单" [selected] [ref=e197] [cursor=pointer]
              - generic [ref=e198]: 按当日收盘价成交
            - generic [ref=e199]:
              - button "10%" [ref=e200] [cursor=pointer]
              - button "20%" [ref=e201] [cursor=pointer]
              - button "25%" [ref=e202] [cursor=pointer]
              - button "30%" [ref=e203] [cursor=pointer]
              - button "50%" [ref=e204] [cursor=pointer]
              - button "75%" [ref=e205] [cursor=pointer]
              - button "100%" [ref=e206] [cursor=pointer]
              - spinbutton "自定义%" [ref=e207]
            - generic [ref=e208]:
              - spinbutton "按股数买卖" [ref=e209]
              - generic [ref=e210]: 留空则按左侧比例
            - generic [ref=e211]:
              - button "买入" [ref=e212] [cursor=pointer]
              - button "卖出" [ref=e213] [cursor=pointer]
          - generic [ref=e214]:
            - generic [ref=e215]:
              - button "折叠画线工具条" [expanded] [ref=e224] [cursor=pointer]
              - generic [ref=e227]: 常用工具
              - button "自定义常用" [ref=e228] [cursor=pointer]
              - button "固定工具面板" [ref=e232] [cursor=pointer]
            - generic [ref=e235]:
              - generic [ref=e236]:
                - button "线段" [ref=e238] [cursor=pointer]
                - button "射线" [ref=e245] [cursor=pointer]
                - button "直线" [ref=e252] [cursor=pointer]
                - button "水平直线" [ref=e257] [cursor=pointer]
                - button "垂直直线" [ref=e261] [cursor=pointer]
                - button "价位线" [ref=e265] [cursor=pointer]
                - button "百分比线" [ref=e269] [cursor=pointer]
              - button "其他工具 16" [expanded] [ref=e275] [cursor=pointer]:
                - text: 其他工具
                - generic [ref=e278]: "16"
              - generic [ref=e279]:
                - button "水平线段" [ref=e281] [cursor=pointer]
                - button "水平射线" [ref=e287] [cursor=pointer]
                - button "垂直线段" [ref=e293] [cursor=pointer]
                - button "垂直射线" [ref=e299] [cursor=pointer]
                - button "平行直线" [ref=e305] [cursor=pointer]
                - button "价格通道线" [ref=e311] [cursor=pointer]
                - button "斐波那契线" [ref=e317] [cursor=pointer]
                - button "画笔" [ref=e321] [cursor=pointer]
                - button "矩形" [ref=e326] [cursor=pointer]
                - button "圆圈" [ref=e331] [cursor=pointer]
                - button "圆弧" [ref=e336] [cursor=pointer]
                - button "箭头线" [ref=e341] [cursor=pointer]
                - button "看涨箭头" [ref=e347] [cursor=pointer]
                - button "看跌箭头" [ref=e353] [cursor=pointer]
                - button "诅咒线" [ref=e359] [cursor=pointer]
                - button "文本" [ref=e364] [cursor=pointer]
            - generic [ref=e368]:
              - button "多选" [ref=e369] [cursor=pointer]
              - button "撤销" [disabled] [ref=e370]
              - button "重做" [disabled] [ref=e374]
              - button "清空" [ref=e378] [cursor=pointer]
              - combobox "吸附" [ref=e382]:
                - option "关闭"
                - option "弱吸附" [selected]
                - option "强吸附"
            - status "已保存" [ref=e384]
            - separator "调整工具面板尺寸（拖动调整宽高，双击恢复默认）" [ref=e385]
```

# Test source

```ts
  75  |       containerContentBottom: containerEl.getBoundingClientRect().top + containerEl.clientTop + containerEl.clientHeight,
  76  |       frameDisplay: frameStyle.display,
  77  |       gridRows: frameStyle.display === 'grid' ? frameStyle.gridTemplateRows.split(' ').filter(Boolean).map(Number) : null,
  78  |       children,
  79  |       panes: chart.panes(),
  80  |       paneRects: chart.paneRects(),
  81  |       scroll: { width: document.documentElement.scrollWidth, height: document.documentElement.scrollHeight, innerWidth, innerHeight },
  82  |     }
  83  |   })
  84  | }
  85  | 
  86  | const near = (actual: number, expected: number, label: string, tolerance = 1) =>
  87  |   expect(Math.abs(actual - expected), `${label}: actual ${actual} vs expected ${expected}`).toBeLessThanOrEqual(tolerance)
  88  | 
  89  | // 等待布局稳定：连续两次采样 frame/host/rail/grid 形状一致（klinecharts 的 _layout 经 Promise 微任务，
  90  | // ResizeObserver 也会排一次重排；CHART-VIEWPORT 要求先等布局稳定再断言）。
  91  | async function settle(page: Page): Promise<void> {
  92  |   await page.evaluate(async () => {
  93  |     await document.fonts.ready
  94  |     await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())))
  95  |   })
  96  |   let previous = ''
  97  |   await expect.poll(async () => {
  98  |     const m = await layout(page)
  99  |     const key = JSON.stringify([m.frame.height, m.host.height, m.rail.height, m.frameDisplay, m.gridRows, m.panes.map(pane => [pane.id, pane.height, pane.top])])
  100 |     const stable = key === previous
  101 |     previous = key
  102 |     return stable
  103 |   }, { timeout: 8_000, intervals: [120, 120, 120, 120] }).toBe(true)
  104 |   await page.waitForTimeout(80)
  105 |   await settleFrames(page)
  106 | }
  107 | async function settleFrames(page: Page): Promise<void> {
  108 |   await page.evaluate(() => new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))))
  109 | }
  110 | 
  111 | function expectNoEmptyRow(m: LayoutSnapshot, label: string): void {
  112 |   near(m.frame.bottom, m.containerContentBottom, `${label}: frame 底边 vs 面板内容底边`)
  113 |   near(m.frame.y, m.containerContentTop, `${label}: frame 顶边 vs 面板内容顶边`)
  114 |   const children = [...m.children].sort((a, b) => a.top - b.top)
  115 |   expect(children.length, `${label}: frame 直接布局子元素数量`).toBeGreaterThanOrEqual(2)
  116 |   near(children[0]!.top, m.frame.y, `${label}: 首个子元素顶边 vs frame 顶边`)
  117 |   near(children[children.length - 1]!.bottom, m.frame.bottom, `${label}: 末个子元素底边 vs frame 底边`)
  118 |   for (let i = 0; i + 1 < children.length; i++) {
  119 |     near(children[i + 1]!.top, children[i]!.bottom, `${label}: 子元素 ${children[i]!.className} 与 ${children[i + 1]!.className} 之间无空行/重叠`)
  120 |   }
  121 |   // 旧 3 行 grid 在行情条 Teleport 后保留空 auto 行：行数 > 流内子元素数，且行高总和仍等于 frame 高度。
  122 |   if (m.gridRows) {
  123 |     expect(m.gridRows.length, `${label}: grid 行数 vs 流内子元素数`).toBe(children.length)
  124 |   }
  125 | }
  126 | 
  127 | function expectPanesFillHost(m: LayoutSnapshot, label: string): void {
  128 |   const panes = [...m.panes].sort((a, b) => a.top - b.top)
  129 |   const xAxis = m.paneRects.xAxis
  130 |   expect(panes.length, `${label}: 绘图窗格数量`).toBeGreaterThanOrEqual(1)
  131 |   near(panes[0]!.top, 0, `${label}: 首个窗格顶边`)
  132 |   near(xAxis.top + xAxis.height, m.host.height, `${label}: 时间轴底边 vs host 高度`)
  133 |   const gaps: number[] = []
  134 |   for (let i = 0; i + 1 < panes.length; i++) gaps.push(panes[i + 1]!.top - (panes[i]!.top + panes[i]!.height))
  135 |   for (const gap of gaps) {
  136 |     expect(gap, `${label}: 相邻窗格间隙 ${gap}（不得出现空白带）`).toBeGreaterThanOrEqual(0)
  137 |     // 分隔条布局带实测 1px（7px 是事件命中带，不参与布局）；收紧到 ≤2，避免 7px 级空白带被当作分隔条放过
  138 |     expect(gap, `${label}: 相邻窗格间隙 ${gap}（不得出现空白带）`).toBeLessThanOrEqual(2)
  139 |   }
  140 |   const separator = gaps[0] ?? 0
  141 |   for (const gap of gaps) near(gap, separator, `${label}: 分隔条布局宽度一致`)
  142 |   const panesTotal = panes.reduce((sum, pane) => sum + pane.height, 0)
  143 |   near(panesTotal + xAxis.height + separator * gaps.length, m.host.height, `${label}: 主图+副图+分隔条+时间轴总高 vs host 高度`)
  144 | }
  145 | 
  146 | function expectViewportClean(m: LayoutSnapshot, label: string): void {
  147 |   expect(m.scroll.height, `${label}: 页面无纵向滚动`).toBeLessThanOrEqual(m.scroll.innerHeight + 1)
  148 |   expect(m.scroll.width, `${label}: 页面无横向溢出`).toBeLessThanOrEqual(m.scroll.innerWidth + 1)
  149 | }
  150 | 
  151 | // 训练页：行情条 Teleport 到状态条（不在 frame 流内）→ host 必须 = frame − 成交标记带。
  152 | function expectTrainingFill(m: LayoutSnapshot, label: string): void {
  153 |   expect(m.quoteInFrame, `${label}: 训练页行情条不在图表 frame 内（Teleport 到状态条）`).toBe(false)
  154 |   expectNoEmptyRow(m, label)
  155 |   near(m.rail.height, 40, `${label}: 成交标记带保持 40px`)
  156 |   near(m.host.height, m.frame.height - m.rail.height, `${label}: 图表宿主高度 = frame 高度 − 成交标记带高度`)
  157 |   near(m.host.y, m.frame.y, `${label}: 图表宿主顶边`)
  158 |   near(m.host.bottom, m.rail.y, `${label}: 图表宿主底边 vs 成交标记带顶边`)
  159 |   expect(m.host.width, `${label}: 图表宿主宽度`).toBeGreaterThan(0)
  160 |   expectPanesFillHost(m, label)
  161 | }
  162 | 
  163 | async function createTraining(page: Page): Promise<void> {
  164 |   const active = (await (await page.request.get('/api/trainings/active')).json()).training
  165 |   if (active) await page.request.post(`/api/trainings/${active.id}/abandon`)
  166 |   const response = await page.request.post('/api/trainings', {
  167 |     data: { code: '600519', tier: '2Y', start_date: '2024-09-13', initial_cash: 1_000_000 },
  168 |   })
  169 |   expect(response.status()).toBe(201)
  170 |   await page.goto('/')
  171 |   await expect(page.locator('.training-current-date')).toBeVisible({ timeout: 120_000 })
  172 |   await expect(page.locator('.drawing-save-status')).toHaveText('已保存')
  173 |   await expect(page.locator('.loading-dot')).not.toBeVisible()
  174 |   // 默认偏好：candle/VOL/MACD/KDJ 四个绘图窗格
> 175 |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart?.panes().length)).toBe(4)
      |                                                                                                ^ Error: expect(received).toBe(expected) // Object.is equality
  176 | }
  177 | 
  178 | async function setTheme(page: Page, mode: 'dark' | 'light'): Promise<void> {
  179 |   const isDark = await page.locator('body').evaluate(body => body.classList.contains('dark'))
  180 |   if (isDark !== (mode === 'dark')) await page.locator('.theme-toggle').click()
  181 |   expect(await page.locator('body').evaluate(body => body.classList.contains('dark')), `theme=${mode}`).toBe(mode === 'dark')
  182 |   await settle(page)
  183 | }
  184 | 
  185 | test('training chart fills the available height at three desktop sizes in both themes', async ({ page }) => {
  186 |   test.setTimeout(180_000)
  187 |   await createTraining(page)
  188 |   for (const size of SIZES) {
  189 |     await page.setViewportSize(size)
  190 |     await settle(page)
  191 |     for (const mode of THEMES) {
  192 |       await setTheme(page, mode)
  193 |       const label = `${size.width}x${size.height}-${mode}`
  194 |       const m = await layout(page)
  195 |       expectTrainingFill(m, label)
  196 |       expectViewportClean(m, label)
  197 |       // 几何快照进运行产物（frame/host/rail/panes 的实测值，供证据核对）
  198 |       await test.info().attach(`layout-${label}`, { body: JSON.stringify(m, null, 2), contentType: 'application/json' })
  199 |       // 行情条仍常驻状态条可见（Teleport 形态不因铺满修复而丢失）
  200 |       await expect(page.locator('.status-strip .chart-quote')).toBeVisible()
  201 |       await page.screenshot({ path: evidencePath(`layout-fill-${size.width}x${size.height}-${mode}.png`) })
  202 |     }
  203 |   }
  204 | })
  205 | 
  206 | test('fill invariants survive MACD toggle, maximize/restore and window resize', async ({ page }) => {
  207 |   test.setTimeout(180_000)
  208 |   await page.setViewportSize({ width: 1440, height: 900 })
  209 |   await createTraining(page)
  210 |   await settle(page)
  211 |   let m = await layout(page)
  212 |   expectTrainingFill(m, 'initial-1440x900')
  213 |   expectViewportClean(m, 'initial-1440x900')
  214 | 
  215 |   const macdToggle = page.locator('.indicator-toggles').getByRole('button', { name: 'MACD', exact: true })
  216 |   // 关闭 MACD：窗格移除后仍铺满
  217 |   await macdToggle.click()
  218 |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.panes().length)).toBe(3)
  219 |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.indicatorPanes())).toEqual(['candle_pane', 'VOL', 'KDJ'])
  220 |   await settle(page)
  221 |   m = await layout(page)
  222 |   expectTrainingFill(m, 'macd-off')
  223 |   expectViewportClean(m, 'macd-off')
  224 |   await page.screenshot({ path: evidencePath('layout-fill-macd-off.png') })
  225 | 
  226 |   // 重新开启 MACD：副图回来仍铺满
  227 |   await macdToggle.click()
  228 |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.panes().length)).toBe(4)
  229 |   await settle(page)
  230 |   m = await layout(page)
  231 |   expectTrainingFill(m, 'macd-on')
  232 |   expectViewportClean(m, 'macd-on')
  233 | 
  234 |   // 双击 MACD 副图最大化：主图归零但 host 仍铺满 frame（分隔条让位、时间轴保留）
  235 |   const host = (await page.locator('.chart-host').boundingBox())!
  236 |   const macdPane = (await page.evaluate(() => (window as any).__trainerChart.panes())).find((pane: Pane) => pane.name === 'MACD')!
  237 |   await page.mouse.dblclick(host.x + macdPane.width * .45, host.y + macdPane.top + macdPane.height * .5)
  238 |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.panes().find((pane: { id: string }) => pane.id === 'candle_pane').height)).toBe(0)
  239 |   await settle(page)
  240 |   m = await layout(page)
  241 |   expectTrainingFill(m, 'macd-maximized')
  242 |   expectViewportClean(m, 'macd-maximized')
  243 |   await page.screenshot({ path: evidencePath('layout-fill-macd-maximized.png') })
  244 | 
  245 |   // 再双击主图区域还原
  246 |   await page.mouse.dblclick(host.x + host.width * .45, host.y + 100)
  247 |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.panes().find((pane: { id: string }) => pane.id === 'candle_pane').height)).toBeGreaterThan(0)
  248 |   await settle(page)
  249 |   m = await layout(page)
  250 |   expectTrainingFill(m, 'macd-restored')
  251 |   expectViewportClean(m, 'macd-restored')
  252 | 
  253 |   // 窗口 resize 1440 → 1024 → 1440：每次都在新的可用高度内铺满
  254 |   for (const size of [{ width: 1024, height: 680 }, { width: 1440, height: 900 }]) {
  255 |     await page.setViewportSize(size)
  256 |     await settle(page)
  257 |     const label = `resize-${size.width}x${size.height}`
  258 |     m = await layout(page)
  259 |     expectTrainingFill(m, label)
  260 |     expectViewportClean(m, label)
  261 |     await page.screenshot({ path: evidencePath(`layout-fill-${label}.png`) })
  262 |   }
  263 | })
  264 | 
  265 | // 回放页无 #chart-quote-slot：ChartQuote 内联在 frame 流内（Quote 内联形态）。
  266 | // 铺满不变量：frame 无空行，host = frame − 行情条高度 − 成交标记带高度。
  267 | test('replay page keeps the inline quote and fills the frame without an empty row', async ({ page }) => {
  268 |   test.setTimeout(180_000)
  269 |   await page.setViewportSize({ width: 1366, height: 705 })
  270 |   await createTraining(page)
  271 |   await page.getByRole('button', { name: '推进下一日', exact: true }).click()
  272 |   await expect(page.getByRole('button', { name: '刷新图表', exact: true })).toBeEnabled()
  273 |   await page.waitForTimeout(600)
  274 |   const active = (await (await page.request.get('/api/trainings/active')).json()).training
  275 |   await page.request.post(`/api/trainings/${active.id}/abandon`)
```