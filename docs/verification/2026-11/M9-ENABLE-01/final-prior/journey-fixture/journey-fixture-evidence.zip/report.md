# formula-chart 夹具泄漏诊断与待执行补丁

冻结源码：f70137182ac75635b006d567b34616cc9a9f1bd4。此审查仅读取源码及已有运行产物；未访问 SQLite、未启动服务、未运行浏览器或产品代码、未修改仓库/矩阵/control。补丁仅位于外部 cache，交由 root 显式扩展关联范围后应用。

## 结论与证据

高置信根因是 formula-chart 测试结束后没有删除自建公式。最后一测保留启用的 CHART_SUB，随后默认图表多出一个副图窗格。七份原始失败上下文均直接记录 Expected: 4 / Received: 5，15 秒 predicate timeout；这与源码及测试顺序一致。未读取运行数据库，具体泄漏对象仍需 root 的 RED/GREEN 浏览器重跑完成动态因果确认。

- e2e/AGENTS.md:9 明确同次运行及重试共用测试数据库；Playwright 页面/上下文销毁不会清除服务端公式库。
- e2e/formula-chart.spec.ts:18 的 afterEach 仅断言 pageErrors；:22-29 的清理只在每测开头调用，GET 非成功时静默返回，DELETE 状态不检查。
- 最后一测 :156-187 在 :158-159 创建 CHART_MAIN 和 CHART_SUB，无结束清理。POST 未指定 enabled，server/src/formulas/storage.ts:107 与 api.ts:117 默认 enabled=1。
- web/src/views/Training.vue:513-521 重读持久公式库；web/src/formulaIndicators.ts:71 保留已启用公式；KlineChart.vue:571-608 的副图分支创建新 pane，后续输出复用同一 pane。因此 CHART_MAIN 叠加主图，CHART_SUB 两条线共用一个额外 pane，4+1=5。
- 后续 formula-enable.spec.ts:18-26 仅禁用 builtin、删除 ENABLE_CUSTOM；formula-manager.spec.ts:11-23 仅删除自身命名，均不会删除 CHART_SUB。其自身通过不能证明前套件没有残留。
- journey.spec.ts:112、kdj-indicator.spec.ts:35、layout-fill.spec.ts:175 继续要求默认四窗格，这是有效产品断言。不得把预期改为五，或让所有套件清空全库来掩盖泄漏。

## 最小补丁

01-red-postcondition.patch：只把 afterEach 改为 async；保留 pageErrors 原断言，新增 GET 200 和本套件 FORMULA_NAMES 全部不存在的断言，不进行 teardown 清理。原四个测试正文完整保留。这一步应在原实现产生夹具残留失败；需记录实际错误对象、原始退出码与完整产物。

02-green-cleanup.patch：在保留的 pageErrors 断言外加 try/finally，finally 先清理本套件自建、非 builtin 公式，再执行 RED 的 GET/不存在断言。cleanFormulas 的 GET 必须 200，逐项 DELETE 必须 204。成功清理时，try 中的 pageErrors 失败仍会向外传播；清理失败也会使测试失败。

03-combined.patch 是 base→GREEN 汇总 diff，不应与 01/02 重复应用。只有 e2e/formula-chart.spec.ts 一个路径，只有 hook 与清理 helper 改动；全部四个测试正文在归一换行后逐字一致。

静态 expect 调用点：base 41，RED 43（+2），GREEN 45（相对 base +4）。这是调用点数，不是 Playwright 用例数。原四个用例不增减。以全新数据库、七个正常创建的夹具且无已有同名夹具估算，GREEN 新增 23 次运行时断言：8 次清理 GET（原4次 setup+新增4次 teardown）、7 次 DELETE、4 次清后 GET、4 次不存在断言；这是静态推算，尚未运行。

补丁的 TypeScript 语法解析均无诊断；三份补丁在独立 cache 副本上 git apply --check --no-index 均 native exit 0，检查前后源文件哈希不变。这些检查不代替真实 RED/GREEN。

## root 后续验证建议

1. 显式把 formula-chart.spec.ts 记录为 formula-chart 矩阵关联范围；保留原始全 Journey 失败产物。新建自己拥有的 manifest/端口/SQLite/构建目录运行，避免复用失败 run 的数据库。
2. 先应用 01，仅运行原四测、retries=0，确认 postcondition 因实际 CHART_* 残留而 RED，并核验最终一测也被覆盖；不靠下一测的 setup 清理作为 oracle。
3. 再应用 02，相同产品断言全部保留；运行公式三套件及 Journey/KDJ/layout 的完整组合。保留启用状态、主副图挂载、随机信息遮蔽、回放和四窗格原断言。
4. 在新 run 完整重跑 candidate，不用定向绿色结果拼接原失败总验收。确认末尾清理与后续四窗格都成功，再更新矩阵/gate/候选文档。

此诊断只覆盖七个 4→5 失败。观察时全 Journey 尚未给出最终汇总；另见 #119 m3-tools D28 失败，未审查其根因，不应将它自动归入此问题。

## 产物

- fixture-diagnosis.receipt.json：冻结头、源码哈希、调用点统计、七份失败上下文错误全文、运行日志采样时间及哈希。
- journey.observed.log：正在运行日志的一次快照，不能当作最终日志。
- context-*.md：七份原始失败上下文副本。
- patch-apply-check.receipt.json：三个只读 cache 补丁检查的原生退出码。
- base.ts/red.ts/green.ts 与三份 patch：可复查、可重生成，尚未应用到工程。
