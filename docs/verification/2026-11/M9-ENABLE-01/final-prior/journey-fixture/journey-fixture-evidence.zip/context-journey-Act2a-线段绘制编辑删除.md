# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: journey.spec.ts >> Act2a 线段绘制编辑删除
- Location: e2e\journey.spec.ts:141:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 4
Received: 5

Call Log:
- Timeout 15000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary "主导航" [ref=e4]:
    - generic [ref=e5]: K
    - navigation [ref=e6]:
      - button "训练" [ref=e7] [cursor=pointer]
      - button "历史排行" [ref=e13] [cursor=pointer]:
        - generic [ref=e20]: 排行
      - button "历史训练" [ref=e21] [cursor=pointer]:
        - generic [ref=e26]: 历史
      - button "训练录像" [ref=e27] [cursor=pointer]:
        - generic [ref=e31]: 录像
    - button "保存并退出训练器" [ref=e32] [cursor=pointer]:
      - generic [ref=e35]: 退出
    - button "训练默认设置" [ref=e36] [cursor=pointer]:
      - generic [ref=e40]: 设置
  - main [ref=e41]:
    - generic [ref=e42]:
      - generic [ref=e43]: A股 K线训练器
      - generic [ref=e45]:
        - generic [ref=e47]:
          - generic [ref=e48]:
            - checkbox "记录操作" [checked] [ref=e49]
            - text: 记录操作
          - status [ref=e50]: 正在记录 · 0 次操作
          - button "导出录制" [ref=e51] [cursor=pointer]
        - button "切换到浅色主题" [ref=e52] [cursor=pointer]
        - generic [ref=e60]: TDX · 截止 2026-09-16
    - generic [ref=e61]:
      - generic [ref=e62]:
        - generic [ref=e63]:
          - generic "贵州茅台 · 600519" [ref=e65]
          - generic [ref=e66]:
            - text: 当前
            - strong [ref=e67]: 2026-09-01
          - tablist "K线周期" [ref=e68]:
            - tab "日K" [selected] [ref=e69] [cursor=pointer]
            - tab "周K" [ref=e70] [cursor=pointer]
            - tab "月K" [ref=e71] [cursor=pointer]
          - group "副图指标开关" [ref=e72]:
            - button "VOL" [pressed] [ref=e73] [cursor=pointer]
            - button "MACD" [pressed] [ref=e74] [cursor=pointer]
            - button "KDJ" [pressed] [ref=e75] [cursor=pointer]
            - button "多空反转" [ref=e76] [cursor=pointer]
          - group [ref=e77]:
            - generic "训练详情" [ref=e78] [cursor=pointer]
        - generic [ref=e81]:
          - button "划线" [pressed] [ref=e82] [cursor=pointer]
          - button "日线数据更新：最新交易日待确认，点击重新读取本地日线" [ref=e86] [cursor=pointer]: 更新
          - button "刷新图表" [ref=e87] [cursor=pointer]
          - button "回到最新K线" [ref=e93] [cursor=pointer]
          - button "推进下一日" [ref=e96] [cursor=pointer]
          - button "提前结算" [ref=e99] [cursor=pointer]
          - button "放弃训练" [ref=e100] [cursor=pointer]
      - generic [ref=e101]:
        - generic "训练就绪" [ref=e102]
        - group "K线行情" [ref=e104]:
          - generic [ref=e105]: 日K 2026-09-01 周二
          - generic [ref=e106]: 开 1295.00
          - generic [ref=e107]: 高 1307.99
          - generic [ref=e108]: 低 1286.10
          - generic [ref=e109]: 收 1299.56
          - generic [ref=e110]: 日涨幅 0.00%
          - generic [ref=e111]: 最近已知K线
        - generic "空格：推进下一日；[ / ]：日周月周期；Home：回到最新；↑ / ↓：缩放；Shift+← / →：平移视图；Del：删除选中画线；B / S：买入卖出；Ctrl+Z / Ctrl+Y：撤销重做。输入、弹窗和画线取点期间部分快捷键暂停。" [ref=e112]: 空格 下一日 · [ ] 周期 · Home 最新 · ↑↓ 缩放 · Shift←→ 平移 · Del 删线
        - generic [ref=e113]: 可见至 2026-09-01 周二
        - generic "当前同屏K线根数 / 同屏上限" [ref=e114]: 152 / 840 根
      - generic [ref=e115]:
        - generic [ref=e117]:
          - button "设置均线" [ref=e119] [cursor=pointer]: MA 设置
          - group "成交标记" [ref=e169]
        - complementary [ref=e170]:
          - generic [ref=e171]:
            - generic [ref=e172]:
              - generic [ref=e173]: 训练账户
              - generic [ref=e174]: ● 进行中
            - generic [ref=e175]:
              - generic [ref=e176]: 账户权益
              - strong [ref=e177]:
                - generic [ref=e178]: ¥1,000,000
              - emphasis [ref=e179]:
                - generic [ref=e180]: +0.00%
            - generic [ref=e181]:
              - generic [ref=e182]:
                - generic [ref=e183]: 可用资金
                - strong [ref=e184]: ¥1,000,000
              - generic [ref=e185]:
                - generic [ref=e186]: 持仓市值
                - strong [ref=e187]: ¥0
              - generic [ref=e188]:
                - generic [ref=e189]: 持仓（可卖）
                - strong [ref=e190]: 0（0）
              - generic [ref=e191]:
                - generic [ref=e192]: 摊薄成本
                - strong [ref=e193]: "--"
            - generic [ref=e195]:
              - tablist "下单方式" [ref=e196]:
                - tab "普通下单" [selected] [ref=e197] [cursor=pointer]
              - generic [ref=e198]: 按当日收盘价成交
            - generic [ref=e199]:
              - button "10%" [ref=e200] [cursor=pointer]
              - button "20%" [ref=e201] [cursor=pointer]
              - button "25%" [ref=e202] [cursor=pointer]
              - button "30%" [ref=e203] [cursor=pointer]
              - button "50%" [ref=e204] [cursor=pointer]
              - button "75%" [ref=e205] [cursor=pointer]
              - button "100%" [ref=e206] [cursor=pointer]
              - spinbutton "自定义%" [ref=e207]
            - generic [ref=e208]:
              - spinbutton "按股数买卖" [ref=e209]
              - generic [ref=e210]: 留空则按左侧比例
            - generic [ref=e211]:
              - button "买入" [ref=e212] [cursor=pointer]
              - button "卖出" [ref=e213] [cursor=pointer]
          - generic [ref=e214]:
            - generic [ref=e215]:
              - button "折叠画线工具条" [expanded] [ref=e224] [cursor=pointer]
              - generic [ref=e227]: 常用工具
              - button "自定义常用" [ref=e228] [cursor=pointer]
              - button "固定工具面板" [ref=e232] [cursor=pointer]
            - generic [ref=e235]:
              - generic [ref=e236]:
                - button "线段" [ref=e238] [cursor=pointer]
                - button "射线" [ref=e245] [cursor=pointer]
                - button "直线" [ref=e252] [cursor=pointer]
                - button "水平直线" [ref=e257] [cursor=pointer]
                - button "垂直直线" [ref=e261] [cursor=pointer]
                - button "价位线" [ref=e265] [cursor=pointer]
                - button "百分比线" [ref=e269] [cursor=pointer]
              - button "其他工具 16" [expanded] [ref=e275] [cursor=pointer]:
                - text: 其他工具
                - generic [ref=e278]: "16"
              - generic [ref=e279]:
                - button "水平线段" [ref=e281] [cursor=pointer]
                - button "水平射线" [ref=e287] [cursor=pointer]
                - button "垂直线段" [ref=e293] [cursor=pointer]
                - button "垂直射线" [ref=e299] [cursor=pointer]
                - button "平行直线" [ref=e305] [cursor=pointer]
                - button "价格通道线" [ref=e311] [cursor=pointer]
                - button "斐波那契线" [ref=e317] [cursor=pointer]
                - button "画笔" [ref=e321] [cursor=pointer]
                - button "矩形" [ref=e326] [cursor=pointer]
                - button "圆圈" [ref=e331] [cursor=pointer]
                - button "圆弧" [ref=e336] [cursor=pointer]
                - button "箭头线" [ref=e341] [cursor=pointer]
                - button "看涨箭头" [ref=e347] [cursor=pointer]
                - button "看跌箭头" [ref=e353] [cursor=pointer]
                - button "诅咒线" [ref=e359] [cursor=pointer]
                - button "文本" [ref=e364] [cursor=pointer]
            - generic [ref=e368]:
              - button "多选" [ref=e369] [cursor=pointer]
              - button "撤销" [disabled] [ref=e370]
              - button "重做" [disabled] [ref=e374]
              - button "清空" [ref=e378] [cursor=pointer]
              - combobox "吸附" [ref=e382]:
                - option "关闭"
                - option "弱吸附" [selected]
                - option "强吸附"
            - status "已保存" [ref=e384]
            - separator "调整工具面板尺寸（拖动调整宽高，双击恢复默认）" [ref=e385]
```

# Test source

```ts
  12  | async function resetToLauncher(page: import('@playwright/test').Page): Promise<void> {
  13  |   const active = (await (await page.request.get('/api/trainings/active')).json()).training
  14  |   if (active) await page.request.post(`/api/trainings/${active.id}/abandon`)
  15  |   await page.goto('/')
  16  |   await page.waitForTimeout(400)
  17  |   await expect(page.getByRole('button', { name: '开始训练' })).toBeVisible()
  18  | }
  19  | 
  20  | test('Act1 创建训练并进入训练视图', async ({ page }) => {
  21  |   await resetToLauncher(page)
  22  |   await page.getByPlaceholder('股票代码，如 600519').fill('600519')
  23  | await expect(page.locator(".suggestions button").first()).toBeVisible()
  24  | await page.locator(".suggestions button").first().click()
  25  |   await expect(page.getByText(/已选：/)).toBeVisible()
  26  |   await page.getByRole('button', { name: '3个月' }).click()
  27  |   await page.locator('input[type="date"]').fill('2026-09-01')
  28  |   await startTrainingFromForm(page)
  29  |   await expect(page.locator('.training-meta')).toContainText('时长 3个月')
  30  |   // 工具条与多选开关就绪
  31  |   await expect(toolButton(page, '线段')).toBeVisible()
  32  |   await expect(toolButton(page, '射线')).toBeVisible()
  33  |   await expect(toolButton(page, '直线')).toBeVisible()
  34  |   await expect(toolButton(page, '多选')).toBeVisible()
  35  |   // 模式机初始状态
  36  |   const mode = await page.evaluate(() => (window as any).__trainerChart.mode())
  37  |   expect(mode).toEqual({ draw: null, multiSelect: false, axisScaleDrag: false })
  38  | })
  39  | 
  40  | test('Act5 买入推进卖出结算', async ({ page }) => {
  41  |   await resetToLauncher(page)
  42  |   // 重建训练（serial 顺序在 Act1 之后，库中状态由 Act5 前置步骤决定）
  43  |   await page.getByPlaceholder('股票代码，如 600519').fill('600519')
  44  | await expect(page.locator(".suggestions button").first()).toBeVisible()
  45  | await page.locator(".suggestions button").first().click()
  46  |   await expect(page.getByText(/已选：/)).toBeVisible()
  47  |   await page.getByRole('button', { name: '3个月' }).click()
  48  |   await page.locator('input[type="date"]').fill('2026-09-01')
  49  |   await startTrainingFromForm(page)
  50  |   await expect(page.locator('.training-meta')).toContainText('时长 3个月')
  51  |   // B 买入：B/S 标记 overlay 出现（引擎标记不可选中，不在多选集合）。
  52  |   // A visible training page can still be waiting for recording initialization;
  53  |   // keyboard actions must wait for the same readiness guard as real controls.
  54  |   await expect(page.getByRole('status').filter({ hasText: '正在记录' })).toBeVisible()
  55  |   await expect(page.locator('.training-grid')).not.toHaveAttribute('inert', '')
  56  |   await expect(page.getByRole('button', { name: '刷新图表', exact: true })).toBeEnabled()
  57  |   // 注意：expect(promise).resolves 不做重试，此处成交→快照刷新→refreshMarks 有异步链，改轮询断言
  58  |   await page.keyboard.press('b')
  59  |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.overlayCount('bsMark')), { timeout: 5000 }).toBe(1)
  60  |   await expect(page.getByRole('button', { name: '刷新图表', exact: true })).toBeEnabled()
  61  |   // Space 推进：当前日期前进
  62  |   const metaBefore = await page.locator('.training-current-date').innerText()
  63  |   await page.keyboard.press('Space')
  64  |   await expect(page.locator('.training-current-date')).not.toHaveText(metaBefore)
  65  |   await expect(page.getByRole('button', { name: '刷新图表', exact: true })).toBeEnabled()
  66  |   // S 卖出
  67  |   await page.keyboard.press('s')
  68  |   await expect(page.locator('.status-message')).toContainText('卖出成交')
  69  |   await expect(page.getByRole('button', { name: '刷新图表', exact: true })).toBeEnabled()
  70  |   // 提前结算：结束训练确认弹窗（真实点击确认结算一次）→ 结算面板 → 返回首页
  71  |   await settleThroughConfirmation(page)
  72  |   await expect(page.getByRole('heading', { name: '创建训练' })).toBeVisible()
  73  | })
  74  | 
  75  | // ---------- Act 2：画线全生命周期（绘制/编辑/删除/延伸段命中） ----------
  76  | // Existing fixture points describe line geometry in the original panes, not absolute screen positions.
  77  | async function screenPoint(page: Page, x: number, y: number): Promise<{ x: number; y: number }> {
  78  |   return page.evaluate(({ x, y }) => {
  79  |     const chart = (window as any).__trainerChart
  80  |     const host = document.querySelector('.chart-host')!.getBoundingClientRect()
  81  |     const panes = chart.panes()
  82  |     const reference = y < 656 ? { index: 0, top: 266, height: 389 }
  83  |       : y < 757 ? { index: 1, top: 656, height: 100 }
  84  |         : { index: 2, top: 757, height: 100 }
  85  |     const pane = panes[reference.index]
  86  |     const mainWidth = chart.viewportMetrics().width
  87  |     return {
  88  |       x: host.left + (x >= 1035 ? mainWidth + (pane.width - mainWidth) / 2 : (x - 107) / (1035 - 107) * mainWidth),
  89  |       y: host.top + pane.top + (y - reference.top) / reference.height * pane.height,
  90  |     }
  91  |   }, { x, y })
  92  | }
  93  | async function clickAt(page: Page, x: number, y: number, options?: Parameters<Page['mouse']['click']>[2]): Promise<void> {
  94  |   const point = await screenPoint(page, x, y)
  95  |   await page.mouse.click(point.x, point.y, options)
  96  | }
  97  | async function moveTo(page: Page, x: number, y: number, options?: Parameters<Page['mouse']['move']>[2]): Promise<void> {
  98  |   const point = await screenPoint(page, x, y)
  99  |   await page.mouse.move(point.x, point.y, options)
  100 | }
  101 | async function openTraining(page: import('@playwright/test').Page): Promise<void> {
  102 |   await resetToLauncher(page)
  103 |   await page.getByPlaceholder('股票代码，如 600519').fill('600519')
  104 | await expect(page.locator(".suggestions button").first()).toBeVisible()
  105 | await page.locator(".suggestions button").first().click()
  106 |   await expect(page.getByText(/已选：/)).toBeVisible()
  107 |   await page.getByRole('button', { name: '3个月' }).click()
  108 |   await page.locator('input[type="date"]').fill('2026-09-01')
  109 |   await startTrainingFromForm(page)
  110 |   await expect(page.locator('.training-meta')).toContainText('时长 3个月')
  111 |   // M6-01：KDJ 副图默认随偏好挂载（candle/VOL/MACD/KDJ）
> 112 |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart?.panes().length)).toBe(4)
      |                                                                                                ^ Error: expect(received).toBe(expected) // Object.is equality
  113 |   await expect(page.locator('.loading-dot')).not.toBeVisible()
  114 |   // 控制台滚动到底，露出完整工具条
  115 |   await page.locator('.console-scroll').evaluate((el: HTMLElement) => { el.scrollTop = el.scrollHeight })
  116 | }
  117 | 
  118 | // 工具按钮精确定位（'线段' 与 '水平线段' 等互为子串，hasText 会 strict 冲突）
  119 | function toolButton(page: import('@playwright/test').Page, label: string): import('@playwright/test').Locator {
  120 |   return page.locator('.draw-toolbar button').filter({ has: page.locator(`text="${label}"`) })
  121 | }
  122 | 
  123 | async function pickTool(page: import('@playwright/test').Page, label: string): Promise<void> {
  124 |   if (!await toolButton(page, label).isVisible()) await page.locator('.other-tools-toggle').click()
  125 |   await toolButton(page, label).click()
  126 |   await expect(page.locator('.status-strip')).toContainText(`画线模式：${label}`)
  127 |   // watch(props.drawTool) 的 createOverlay 在微任务中完成：等一拍再开始取点，避免工具激活竞态
  128 |   await page.waitForTimeout(300)
  129 | }
  130 | 
  131 | async function drawTwoPointLine(page: import('@playwright/test').Page, x1: number, y1: number, x2: number, y2: number): Promise<void> {
  132 |   await clickAt(page, x1, y1)
  133 |   // 两次点击间隔 >500ms：避开 klinecharts 双击判定窗口（Delay.ResetClick=500）
  134 |   await page.waitForTimeout(650)
  135 |   await clickAt(page, x2, y2)
  136 |   await page.waitForTimeout(400)
  137 |   // 完成后自动退出画线模式
  138 |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.mode().draw)).toBeNull()
  139 | }
  140 | 
  141 | test('Act2a 线段绘制编辑删除', async ({ page }) => {
  142 |   await openTraining(page)
  143 |   await pickTool(page, '线段')
  144 |   const before = await page.evaluate(() => (window as any).__trainerChart.overlayCount('segment'))
  145 |   await drawTwoPointLine(page, 400, 480, 700, 350)
  146 |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.overlayCount('segment'))).toBe(before + 1)
  147 |   // 右键线体 → 编辑面板 → 改颜色与端点价位 → 确定 → 断言生效
  148 |   await clickAt(page, 550, 415, { button: 'right' })
  149 |   await page.getByText('编辑划线', { exact: true }).click()
  150 |   await page.locator('.overlay-edit-panel input[type="color"]').fill('#ff4d4f')
  151 |   const v = page.locator('.overlay-edit-panel input[type="number"]').first()
  152 |   await v.fill('1250')
  153 |   await page.getByRole('button', { name: '确定' }).click()
  154 |   await page.waitForTimeout(300)
  155 |   // Delete 删除（先左键点选编辑后的线体：端点1 已改价 1250、线体已移位，点未移动的端点2 精确位置保证命中。
  156 |   // 旧坐标 (550,415) 在编辑后脱靶——旧流程靠"画线完成后的残留选中态"误打误撞删除，正是 Act2d 修掉的缺陷）
  157 |   await clickAt(page, 700, 350)
  158 |   await page.waitForTimeout(200)
  159 |   await page.keyboard.press('Delete')
  160 |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.overlayCount('segment'))).toBe(before)
  161 | })
  162 | 
  163 | test('Act2d 空白点击解除持久选中（选中状态机）', async ({ page }) => {
  164 |   await openTraining(page)
  165 |   await pickTool(page, '线段')
  166 |   await drawTwoPointLine(page, 400, 480, 700, 350)
  167 |   // 左键点选线体 → 持久选中态（库 click 选中，端点显示）
  168 |   await clickAt(page, 550, 415)
  169 |   await page.waitForTimeout(300)
  170 |   const selectedId = await page.evaluate(() => (window as any).__trainerChart.singleSelected())
  171 |   expect(selectedId).not.toBeNull()
  172 |   // 左键点击主图空白（图内、远离线体）→ 持久选中立即解除（框选拦截不得吞掉解除链路——端点常显假选中回归）
  173 |   await clickAt(page, 400, 300)
  174 |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.singleSelected())).toBeNull()
  175 | })
  176 | 
  177 | test('Act2b 射线延伸段可选中', async ({ page }) => {
  178 |   await openTraining(page)
  179 |   await pickTool(page, '射线')
  180 |   await drawTwoPointLine(page, 450, 550, 650, 400)
  181 |   // 延伸段（p2 之外、主图窗格内）左键点击 → Delete 应删除（命中几何延伸）
  182 |   await clickAt(page, 780, 305)
  183 |   await page.keyboard.press('Delete')
  184 |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.overlayCount('rayLine'))).toBe(0)
  185 | })
  186 | 
  187 | test('Act2c 直线两端延伸段可选中', async ({ page }) => {
  188 |   await openTraining(page)
  189 |   await pickTool(page, '直线')
  190 |   await drawTwoPointLine(page, 450, 550, 650, 400)
  191 |   // 左下延伸段（p1 之外）：线方向 (0.8,-0.6)，x=330 处 y=640（主图窗格内；旧坐标 (200,610) 实际距线 102px，
  192 |   // 旧流程靠"画线完成后的残留选中态"误打误撞删除——正是 Act2d 修掉的缺陷）
  193 |   await clickAt(page, 330, 640)
  194 |   await page.keyboard.press('Delete')
  195 |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.overlayCount('straightLine'))).toBe(0)
  196 | })
  197 | 
  198 | test('Act2e 水平线系三工具（D5~D7）', async ({ page }) => {
  199 |   await openTraining(page)
  200 |   // 水平直线：单点完成（totalStep 2），线体全宽
  201 |   await pickTool(page, '水平直线')
  202 |   await clickAt(page, 500, 380)
  203 |   await page.waitForTimeout(650)
  204 |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.overlayCount('horizontalStraightLine'))).toBe(1)
  205 |   // 水平线段：两点之间
  206 |   await pickTool(page, '水平线段')
  207 |   await clickAt(page, 420, 430)
  208 |   await page.waitForTimeout(650)
  209 |   await clickAt(page, 700, 430)
  210 |   await page.waitForTimeout(400)
  211 |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.overlayCount('horizontalSegment'))).toBe(1)
  212 |   // 水平射线：点1 沿点2 方向延伸到边
```