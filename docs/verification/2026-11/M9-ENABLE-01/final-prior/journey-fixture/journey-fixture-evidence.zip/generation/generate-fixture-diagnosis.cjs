const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const assert = require('node:assert/strict');
const repo = 'C:/Users/Stark_Du666/.codex/worktrees/m9-enable-01/a-share-kline-trainer';
const cache = 'C:/Users/Stark_Du666/.codex/headroom-cache/M9-final-code-review/journey-fixture-diagnosis';
const rel = 'e2e/formula-chart.spec.ts';
const expectedHead = 'f70137182ac75635b006d567b34616cc9a9f1bd4';
const sha256 = data => crypto.createHash('sha256').update(data).digest('hex');
const git = args => {
  const r = spawnSync('git', ['-C', repo, ...args], { encoding: 'utf8', windowsHide: true });
  return { status: r.status, stdout: r.stdout || '', stderr: r.stderr || '' };
};
fs.mkdirSync(cache, { recursive: true });
const head = git(['rev-parse', 'HEAD']);
assert.equal(head.status, 0); assert.equal(head.stdout.trim(), expectedHead);
const raw = fs.readFileSync(path.join(repo, rel));
const base = raw.toString('utf8').replace(/\r\n/g, '\n');
const committed = git(['show', 'HEAD:' + rel]);
assert.equal(committed.status, 0); assert.equal(committed.stdout.replace(/\r\n/g, '\n'), base);
const oldHook = 'test.afterEach(({ page }) => { expect(errors.get(page)).toEqual([]) })';
const redHook = [
  'test.afterEach(async ({ page }) => {',
  '  expect(errors.get(page)).toEqual([])',
  "  const response = await page.request.get('/api/formulas')",
  '  expect(response.status()).toBe(200)',
  '  const payload = (await response.json()) as { formulas: Array<{ name: string }> }',
  '  const leakedNames = payload.formulas.filter(formula => FORMULA_NAMES.includes(formula.name)).map(formula => formula.name)',
  "  expect(leakedNames, 'formula-chart 夹具必须在每个用例后全部清理').toEqual([])",
  '})',
].join('\n');
const greenHook = [
  'test.afterEach(async ({ page }) => {',
  '  try {',
  '    expect(errors.get(page)).toEqual([])',
  '  } finally {',
  '    await cleanFormulas(page)',
  "    const response = await page.request.get('/api/formulas')",
  '    expect(response.status()).toBe(200)',
  '    const payload = (await response.json()) as { formulas: Array<{ name: string }> }',
  '    const leakedNames = payload.formulas.filter(formula => FORMULA_NAMES.includes(formula.name)).map(formula => formula.name)',
  "    expect(leakedNames, 'formula-chart 夹具必须在每个用例后全部清理').toEqual([])",
  '  }',
  '})',
].join('\n');
assert.equal(base.split(oldHook).length, 2);
const red = base.replace(oldHook, redHook);
const oldDelete = "    if (!formula.builtin && FORMULA_NAMES.includes(formula.name)) await page.request.delete('/api/formulas/' + formula.id)";
const newDelete = [
  '    if (!formula.builtin && FORMULA_NAMES.includes(formula.name)) {',
  "      const deleted = await page.request.delete('/api/formulas/' + formula.id)",
  '      expect(deleted.status()).toBe(204)',
  '    }',
].join('\n');
assert.equal(red.split(oldDelete).length, 2);
let green = red.replace(redHook, greenHook)
  .replace('  if (!response.ok()) return', '  expect(response.status()).toBe(200)')
  .replace(oldDelete, newDelete);
const bodyMarker = "\ntest('公式图表：主图叠加与副图窗格可见，周期切换与推进后仍存在'";
const body = base.slice(base.indexOf(bodyMarker));
assert.ok(body.length > 0);
for (const text of [red, green]) {
  assert.equal(text.slice(text.indexOf(bodyMarker)), body);
  assert.ok(text.includes('expect(errors.get(page)).toEqual([])'));
  assert.equal((text.match(/^test\('/gm) || []).length, 4);
}
const ts = require(path.join(repo, 'node_modules/typescript'));
const parse = text => ts.createSourceFile(rel, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS).parseDiagnostics.map(d => ({ code: d.code, start: d.start, message: ts.flattenDiagnosticMessageText(d.messageText, '\n') }));
assert.deepEqual(parse(red), []); assert.deepEqual(parse(green), []);
for (const [name, text] of [['base.ts', base], ['red.ts', red], ['green.ts', green]]) fs.writeFileSync(path.join(cache, name), text);
const makePatch = (from, to, output) => {
  const r = git(['diff', '--no-index', '--no-color', '--text', '--', path.join(cache, from), path.join(cache, to)]);
  assert.equal(r.status, 1);
  const patch = r.stdout
    .replace(/^diff --git .+$/m, 'diff --git a/' + rel + ' b/' + rel)
    .replace(/^--- .+$/m, '--- a/' + rel)
    .replace(/^\+\+\+ .+$/m, '+++ b/' + rel);
  fs.writeFileSync(path.join(cache, output), patch);
  fs.writeFileSync(path.join(cache, output + '.generation.json'), JSON.stringify({ nativeExit: r.status, expectedDiffExit: 1, stderr: r.stderr }, null, 2));
};
makePatch('base.ts', 'red.ts', '01-red-postcondition.patch');
makePatch('red.ts', 'green.ts', '02-green-cleanup.patch');
makePatch('base.ts', 'green.ts', '03-combined.patch');
const artifactRoot = path.join(repo, '.runs/run-42206f8c-3a30-4e98-9c72-822f4ad8382a/artifacts');
const observedAt = new Date().toISOString();
const log = fs.readFileSync(path.join(artifactRoot, 'journey.log'));
fs.writeFileSync(path.join(cache, 'journey.observed.log'), log);
const failureContexts = [];
for (const entry of fs.readdirSync(path.join(artifactRoot, 'test-results'), { withFileTypes: true })) {
  if (!entry.isDirectory() || !/^(journey-Act2a|kdj-indicator-|layout-fill-)/.test(entry.name)) continue;
  const source = path.join(artifactRoot, 'test-results', entry.name, 'error-context.md');
  if (!fs.existsSync(source)) continue;
  const data = fs.readFileSync(source);
  const dest = 'context-' + entry.name + '.md';
  fs.writeFileSync(path.join(cache, dest), data);
  const text = data.toString('utf8');
  failureContexts.push({ file: dest, sha256: sha256(data), bytes: data.length, error: text.match(/# Error details\s*\n\s*\x60{3}([\s\S]*?)\x60{3}/)?.[1].trim() || null });
}
const sources = [
  rel, 'e2e/AGENTS.md', 'e2e/formula-enable.spec.ts', 'e2e/formula-manager.spec.ts',
  'e2e/journey.spec.ts', 'e2e/kdj-indicator.spec.ts', 'e2e/layout-fill.spec.ts',
  'server/src/formulas/storage.ts', 'server/src/formulas/api.ts',
  'web/src/formulaIndicators.ts', 'web/src/components/KlineChart.vue', 'web/src/views/Training.vue',
  'playwright.config.ts',
].map(file => { const data = fs.readFileSync(path.join(repo, file)); return { file, sha256: sha256(data), bytes: data.length }; });
const count = text => (text.match(/\bexpect(?:\.poll)?\(/g) || []).length;
const receipt = {
  observedAt, repo, head: expectedHead, sourceRawSha256: sha256(raw), sourceNormalizedSha256: sha256(base),
  limitation: 'Read-only source and existing failure evidence; no server, browser test, product process or database access. RED/GREEN are unapplied proposals, syntactically parsed only.',
  fourOriginalTestBodiesByteIdenticalAfterNewlineNormalization: true, originalPageErrorAssertionRetained: true,
  assertionCallsites: { base: count(base), red: count(red), green: count(green), redAdded: count(red)-count(base), greenAddedVersusBase: count(green)-count(base) },
  fixtureCreationCount: 7, expectedFreshGreenRuntimeExtraAssertions: 23,
  runtimeExtraAssertionsExplanation: '8 strict cleanup GETs (4 existing setup + 4 added teardown), 7 successful DELETEs, 4 postcondition GETs, 4 absence assertions; assumes no pre-existing own-name fixtures.',
  syntaxParseDiagnostics: { red: parse(red), green: parse(green) },
  journeyLogSnapshot: { bytes: log.length, sha256: sha256(log), observedAt, finalSummaryPresent: /\d+ failed\s*$/m.test(log.toString('utf8')) },
  failureContexts, sources
};
fs.writeFileSync(path.join(cache, 'fixture-diagnosis.receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
console.log(JSON.stringify({ cache, head: expectedHead, assertions: receipt.assertionCallsites, failureContexts: failureContexts.map(x => ({ file: x.file, error: x.error })), journeySnapshot: receipt.journeyLogSnapshot }, null, 2));

