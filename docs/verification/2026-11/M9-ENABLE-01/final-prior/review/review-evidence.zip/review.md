# M9-ENABLE-01 冻结源码五维审查

日期：2026-11-18（Asia/Shanghai）。静态技术裁决：**可合入，C0 / I0 / M0**。此裁决限于下述冻结差异的实现与专项证据；完整候选、生产包、主代理视觉、用户整批验收及最终合入就绪暂不判定。

## 身份与范围

- 仓库：`C:/Users/Stark_Du666/.codex/worktrees/m9-enable-01/a-share-kline-trainer`。
- BASE：`58ba0ffc13458fb136c7d885b62ee0c898d4bab8`，已包含独立 PR54 EMA 修复。本审查不把该已合入依赖重新算作本卡实现。
- HEAD：`f70137182ac75635b006d567b34616cc9a9f1bd4`；tree：`bcc9d32afd37e67a1ebc7e04325b7146335bb3ef`；审查采样前后 HEAD 相同，工作树为空。
- BASE..HEAD 共275个变更路径，均符合当前任务卡 allowed_paths。产品、测试完整差异保存在 `reviewed-product.diff`，SHA256 `d72ab42aa0b974d4c06fd0d0115a23fddd1df0fe02c12e95c83d361cd529cbe8`。
- 七个产品/测试文件的工作区原字节SHA、Git blob、过滤后匹配结果见 `static-review-identity.json`。`core.autocrlf=true`，六个工作区文件为CRLF而Git blob为LF；经 `git hash-object --path` 七个均匹配冻结HEAD，不将正常换行差异误报为脏源码。
- 最终E2E为212行，SHA256 `a1970bc9113aee90b8837f92cb0376a22d4ddfa84f6d5d1da6712b56ebcc38a9`。外置formula-ui矩阵SHA256 `8d3e3f05f40d3e1b6755aca4187e0018d2750033f33de32a091f2ef1900fec92`，不属于Git tree。

## 1. 计划与产品口径

批准记录 `docs/verification/2026-11/ENG-PLAN-01/approval.md:13` 与规格 `docs/specs/formulas.md:9` 一致：三个内置新seed默认停用，逐个启用后自动按预设位置挂载；用户已保存的选择不被升级重置。内置名称/源码/删除继续受保护，保存失败必须显示错误并清除旧成功提示。

`FormulaSettings.vue:131` 始终发送当前enabled，按是否内置决定是否携带name/source。`server/src/formulas/seed.ts` 仅修正文内说明，运行默认值和幂等策略未改。`server/test/formula-seed.test.ts:75` 独立检查空库默认关，`:81` 后续重seed保留已开启选择。E2E主动关闭夹具不被当作默认值证据。

## 2. 代码质量

- `web/src/components/FormulaSettings.vue:129` 在发请求前清掉旧saveMessage；catch保留实际API错误。未发现本次修改引入成功/失败混报。
- `:134` 直接传boolean；`web/src/api.ts:847` 补创建输入类型，`:858` / `:866` 直接JSON.stringify，false不会丢失。
- `:135` 内置更新省略name/source，而非放宽服务端。`server/src/formulas/storage.ts:87` 检查undefined并校验布尔，`:128` 用nullish保留0；`:120` 与`:144` 的内置保护保持不变。
- payload构造与selectedId快照之间没有await，补丁未新增异步目标错配。创建路径显式提供必需name/source，类型边界完整。

未发现新增Critical、Important或Minor问题；不据此覆盖所有既有设置交互。

## 3. 架构与集成

修复沿用真实公式API和SQLite契约，未新增缓存真源、数据库迁移、行情旁路或交易写入。内置保护继续在服务端执行。启停影响现有图表挂载链，主/副图预设仍来自已批准种子。

公共EMA修复作为BASE中的独立依赖承接；本卡没有继续改引擎语义。录像使用当前公式库、公式pane高度不入录像、公式pane画线回落主图仍是待用户整批确认的限制，开发批准不构成接受这些限制。

## 4. 测试真实性

原始 `red/red-journey-detail.txt` 保留5失败：自定义预期false实际true；三个内置期望200实际403；保存拒绝后旧成功节点期望0实际1。失败原因与被修复的三处行为直接对应。原运行wrapper记录exit1，历史原生退出码来源仍按原归档注明，不补造独立当时收据。

当前E2E保持真实设置点击、POST/PUT/GET和SQLite状态，图表hook仅只读核验。唯一HTTP拦截用于固定503拒绝；没有把它描述为真实SQLite事务故障。新主图与失败后刷新断言增强原覆盖，未移除有限数值、固定4/3/3线、pane位置、刷新或停用断言，未加skip或降低oracle。

已独立读取 `run-277d3278-7e99-4c96-837a-e434de3bcdba` 的journey日志、manifest及browser-results：expected=6、unexpected=0、skipped=0、flaky=0、errors=[]，每项一次运行且passed。browser-results SHA256 `859e20d6b558911e05ec0677fbed958d4d9b4f29a1c074b3487ca6c9ea2a2bfb`。

自定义main/sub分别由固定入参约束位置，三内置分别以固定名称/位置/输出数作预期。seed默认值、存储保护、HTTP路由保护各有不同层级证据，不互相冒充。原RED是实际执行；本轮UI源码变异仅纸面推演，不声称另有mutant killed收据。

## 5. Harness与档案收据

四份专项receipt的日志长度/SHA逐份独立吻合：production build、seed/storage/API 3文件13项、6项enable journey、formula-ui strict binding均记录nativeExitCode=0；最后一项8 covered / 0 open / 0 RED。上述运行发生于3ec3d730阶段，最终产品文件及扩展E2E已另以冻结hash复核；仍须最终完整候选运行绑定f701，不把历史专项冒称本冻结完整绿。

按root授权只执行vitest list，删除进程TRAINER_CONTROL_ROOT并显式独立cache TRAINER_DB。native0，实际9个leaf含矩阵绑定的空库幂等、内置保护与服务端403标题。见 `vitest-list.receipt.json`。第一次list本身native0，收据构造误用false而非$false产生PowerShell错误；错误和原输出已保留，重跑list生成有效完整收据。没有运行测试或启动产品。

archive-index的76项逐个核验：44 identity、32 base64，全部decoded bytes/SHA及encoded SHA吻合，未丢原始错误。当前cache中两份preparation源已推进，故与历史归档不同；这不破坏归档完整性，也不能把旧preparation当作最终实际执行脚本。root已说明最终脚本将另归档并明确旧版历史身份。README现有旧source-identity应作为历史，最终交付入口需绑定f701及后继证据提交。

## 问题与裁决

Critical 0；Important 0；Minor 0。冻结实现差异的静态技术裁决为可合入。合入/提验的最终门禁由集成人在完整候选及生产包收据到齐后判定，本报告不提前批准发布。

## 明确拒绝判断

1. 正在运行的完整candidate、全部本机公式语料和最终完整门禁终态。
2. 本冻结构建到Windows ZIP/NSIS/portable的身份、实际生产脚本运行、录像回放与退出清理。
3. 生产无Journey hook时的数值正确性与三内置视觉质量；截图存在本身不够。
4. 主代理真实UI/UX检查、真实设备覆盖、用户接受当前回放限制或整批验收。
5. 最终合入就绪、GitHub Release、tag、更新feed、上传许可。
6. 全部历史依赖/安全问题、275个档案内容的逐行事实正确性或全工程健康无风险。

审查者仅新增本cache目录报告/收据，未写repo、index、HEAD、branch、control、matrix或ledger；不派子代理。Gate ledger由root单写。本次未使用记忆事实。
