const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const cp = require('node:child_process')
const vm = require('node:vm')
const assert = require('node:assert/strict')

const [repo, prod, verifier, baseline, evidence, commit, mode] = process.argv.slice(2)
const boundaryRoot = path.resolve(__dirname, 'asar-boundary-check') + path.sep
assert.ok(path.resolve(evidence).startsWith(boundaryRoot), 'Case evidence must stay within review cache')
assert.ok(!fs.existsSync(evidence), 'Fresh case directory required')
fs.mkdirSync(evidence, { recursive: true })
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex')
const targetRel = 'server/dist/formulas/api.js'
let interceptionCount = 0
const childProcessAdapter = {
  ...cp,
  execFileSync(program, args, options) {
    if (program === process.execPath && args[1] === 'extract') {
      interceptionCount++
      assert.equal(path.resolve(args[2]), path.resolve(prod, 'win-unpacked/resources/app.asar'))
      const target = args[3]
      assert.equal(path.resolve(target), path.resolve(evidence, 'asar-extracted-v2'))
      assert.ok(!fs.existsSync(target))
      fs.mkdirSync(target)
      for (const rel of ['desktop/dist', 'server/dist', 'web/dist', 'package.json']) {
        const dest = path.join(target, rel)
        fs.mkdirSync(path.dirname(dest), { recursive: true })
        fs.cpSync(path.join(baseline, rel), dest, { recursive: true, errorOnExist: true })
      }
      const runtimeTarget = path.join(target, targetRel)
      const original = fs.readFileSync(runtimeTarget)
      const fixture = { mode, adapter: 'Only replaces ASAR extraction with a fresh cache copy of the independently extracted actual ASAR. The verifier source, real source build tree, product directory, file/hash logic, and assertions remain unchanged.', target: targetRel, originalSha256: sha(original), verifierSha256: sha(fs.readFileSync(verifier)) }
      if (mode === 'runtime-byte-change') {
        const changed = Buffer.from(original)
        changed[0] ^= 1
        fs.writeFileSync(runtimeTarget, changed)
        fixture.changedSha256 = sha(changed)
        fixture.changedByteCount = 1
      } else if (mode === 'runtime-missing') {
        fs.unlinkSync(runtimeTarget)
      } else if (mode === 'runtime-extra') {
        fixture.extraPath = 'server/dist/__unexpected-runtime-review.js'
        fs.writeFileSync(path.join(target, fixture.extraPath), '// cache-only unexpected runtime file\n')
      } else {
        assert.equal(mode, 'positive')
      }
      fs.writeFileSync(path.join(evidence, 'fixture.json'), JSON.stringify(fixture, null, 2) + '\n')
      return Buffer.alloc(0)
    }
    return cp.execFileSync(program, args, options)
  },
}

const verifierSource = fs.readFileSync(verifier, 'utf8')
const context = {
  require(name) { return name === 'node:child_process' ? childProcessAdapter : require(name) },
  process: { argv: [process.execPath, verifier, repo, prod, evidence, commit], execPath: process.execPath },
  __filename: verifier,
  console,
  Buffer,
}
try {
  vm.runInNewContext(verifierSource, context, { filename: verifier })
} finally {
  assert.equal(interceptionCount, 1, 'Exactly one fixture extraction adapter invocation required')
}
