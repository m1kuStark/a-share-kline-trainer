const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const cp = require('node:child_process')
const assert = require('node:assert/strict')
const [repo, prod, evidence, commit] = process.argv.slice(2)
const hash = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex')
const extracted = path.join(evidence, 'asar-extracted-v2')
assert.ok(!fs.existsSync(extracted), 'Fresh extraction required')
assert.equal(cp.execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim(),commit)
const asar = path.join(prod,'win-unpacked','resources','app.asar')
cp.execFileSync(process.execPath,[path.join(repo,'node_modules/@electron/asar/bin/asar.js'),'extract',asar,extracted],{cwd:repo,stdio:'pipe'})
const files = dir => fs.readdirSync(dir,{withFileTypes:true}).flatMap(e => {const f=path.join(dir,e.name);assert.ok(!e.isSymbolicLink()); return e.isDirectory()?files(f):[f]})
const builderDefaults=path.join(repo,'node_modules/app-builder-lib/out/fileMatcher.js')
assert.ok(fs.readFileSync(builderDefaults,'utf8').includes('swp,csproj,sln,suo,xproj,cc,d.ts,'),'Reconfirm builder default declaration exclusion')
const receipt = {sourceCommit:commit, asarSha256:hash(asar), scriptSha256:hash(__filename), builderDefault:{path:builderDefaults,sha256:hash(builderDefaults),lines:[21,157],rule:'Default excludes .d.ts declarations; all remaining production output requires exact file-set and byte identity'}, excludedDeclarations:[], compared:[], migrationResources:[], failures:[], passed:false}
for(const dir of ['desktop/dist','server/dist','web/dist']) {
  const source=path.join(repo,dir), dest=path.join(extracted,dir)
  const allSourceFiles=files(source).map(f=>path.relative(source,f)).sort()
  receipt.excludedDeclarations.push(...allSourceFiles.filter(rel=>rel.endsWith('.d.ts')).map(rel=>({path:dir+'/'+rel.replaceAll('\\','/'),sha256:hash(path.join(source,rel))})))
  const sourceFiles=allSourceFiles.filter(rel=>!rel.endsWith('.d.ts')), destFiles=files(dest).map(f=>path.relative(dest,f)).sort()
  if(JSON.stringify(sourceFiles)!==JSON.stringify(destFiles)) receipt.failures.push({dir,sourceFiles,destFiles})
  for(const rel of sourceFiles) {
    const a=path.join(source,rel),b=path.join(dest,rel)
    const row={path:dir+'/'+rel.replaceAll('\\','/'),bytes:fs.statSync(a).size,sourceSha256:hash(a),packagedSha256:fs.existsSync(b)?hash(b):null}
    receipt.compared.push(row)
    if(row.sourceSha256!==row.packagedSha256)receipt.failures.push(row)
  }
}
assert.equal(JSON.parse(fs.readFileSync(path.join(extracted,'package.json'),'utf8')).version,JSON.parse(fs.readFileSync(path.join(repo,'package.json'),'utf8')).version)
for(const name of ['migration-export-inline.html','migration-import-recordings.js']) {
  const a=path.join(repo,'desktop/build-resources',name),b=path.join(prod,'win-unpacked/resources',name)
  const row={name,sourceSha256:hash(a),packagedSha256:hash(b)}
  receipt.migrationResources.push(row);if(row.sourceSha256!==row.packagedSha256)receipt.failures.push(row)
}
receipt.passed=receipt.failures.length===0
fs.writeFileSync(path.join(evidence,'asar-identity-v2.receipt.json'),JSON.stringify(receipt,null,2)+'\n')
console.log(JSON.stringify({passed:receipt.passed,files:receipt.compared.length,excludedDeclarations:receipt.excludedDeclarations.length,failures:receipt.failures.length,asarSha256:receipt.asarSha256}))
assert.equal(receipt.failures.length,0,'Packaged output differs from same-source production build')
