# M9 ASAR 同源校验边界补充

2026-11-18（Asia/Shanghai）。结论：v2将 `.d.ts` 默认排除写入预期文件集合，符合当前实际 electron-builder 规则；运行时代码的字节、缺失文件和额外文件检查仍有效。原产品五维审查结论保持不变。本补充不判断生产UI、录像、用户验收或发布。

## 原始失败与修订边界

独立读取了 `production-f701371/asar-identity.receipt.json` 和 v2 receipt。首轮77个failure准确分解为：1项server/dist文件集合不符，76项 `.d.ts` 声明缺失。不存在其他缺失、额外文件或已入包运行时文件的字节差异；不是77个运行时代码问题。原失败、原脚本和原始日志保留。

当前安装的 `node_modules/app-builder-lib/out/fileMatcher.js:21` 将 `d.ts` 列入excludedExts，`:157` 将其加入默认排除glob。文件SHA256 `fb3f2039238d502a84eb1a465c77e14115d79c64d0069a30dc6cd65409e28c10`。另用该模块实际导出的excludedExts和实际minimatch执行六个代表路径：`.d.ts`被排除；`.js`、`.js.map`、`.d.ts.js`、`.d.ts.map`及web JS均未被此规则排除。见 `builder-exclusion-rule.receipt.json`，native0。

v2 SHA256 `8e0c055f3d0d1102876b23aacd0af2aa03543f945781f1dcfa41eb6e726d63d2`。它只从源集合排除 `.d.ts`，将76份声明逐项列出SHA；其余源文件和包内目标的完整文件集合必须相等，每份文件SHA必须相同。目标集合没有被同样过滤来隐藏额外文件。

准确计数为：ASAR内178份构建文件，加ASAR外2份迁移资源；76份声明另列为默认排除。声明路径全部唯一、都以 `.d.ts` 结尾、SHA均与真实构建源文件一致。

## 正反例执行

先用真实 `@electron/asar` CLI 从实际ASAR独立解包至本审查cache，native0。四个子进程执行的是原v2脚本原文，不改比较逻辑和断言。测试适配器只把脚本的解包命令替换成这份真实解包内容的全新cache副本，再按用例修改该副本；git身份查询、真实源构建目录、实际产品目录与所有哈希判断保持原样。该方法验证比较器敏感性，不冒称修改过实际ASAR。

| 用例 | 修改对象 | 子进程原生退出码 | 校验器结果 |
|---|---|---:|---|
| positive | 不修改cache副本 | 0 | passed=true，178文件、76声明排除、0failure |
| runtime-byte-change | cache的 `server/dist/formulas/api.js` 首字节异或1 | 1 | passed=false，准确1项该JS文件SHA不符 |
| runtime-missing | 删除cache同一JS文件 | 1 | passed=false，文件集合及该JS缺失共2项 |
| runtime-extra | cache加入 `server/dist/__unexpected-runtime-review.js` | 1 | passed=false，准确1项文件集合不符 |

每个反例均实际触发原校验器最终AssertionError，完整stdout/stderr和其原生receipt保存在 `asar-boundary-check/`。父测试程序只在上述预期全部成立时返回native0；完整收据为 `asar-boundary-review.receipt.json`。这既证明运行时代码单字节变化仍被拒绝，也证明修订未只校验共同文件而忽略缺失或多余文件。

## 身份与限制

执行前后HEAD均为 `f70137182ac75635b006d567b34616cc9a9f1bd4`，工作树均为空。实际ASAR执行前后SHA256均为 `bc1ecac5e917d0407590fff1900078ad480324ff2d516031516b441ffb10a5a1`，v2脚本SHA也未变。未启动产品、未修改源码、实际asar、生产包、repo/index/control/矩阵。

这项检查证明本次受检构建输出与入包文件的一致性，以及比较器对运行时差异的拒绝能力；它不替代构建来源的全部可复现性证明、真实生产行为、视觉质量、完整候选终态或用户验收。
