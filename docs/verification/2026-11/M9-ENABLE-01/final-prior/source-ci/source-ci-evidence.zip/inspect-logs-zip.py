from pathlib import Path
import hashlib
import json
import re
import zipfile
from datetime import datetime, timezone

root = Path(__file__).resolve().parent
source = json.loads((root / 'source-ci-summary.json').read_text(encoding='utf-8'))
assert len(source['runs']) == 1
run = source['runs'][0]
archive = Path(run['zipPath'])
archive_bytes = archive.read_bytes()
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha(archive_bytes) == run['zipSha256']
merge_sha = source['syntheticMerge']['sha']
source_sha = source['sourceFreeze']
ansi = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
entries, summaries, merge_occurrences, source_occurrences, checkout_traces, warnings = [], [], [], [], [], []
with zipfile.ZipFile(archive) as package:
    assert len(package.namelist()) == len(set(package.namelist())), 'Duplicate ZIP member names are not accepted'
    for info in package.infolist():
        if info.is_dir():
            continue
        data = package.read(info)  # ZipFile.read verifies each member CRC; no member is extracted.
        assert len(data) == info.file_size
        entries.append({'name': info.filename, 'bytes': len(data), 'compressedBytes': info.compress_size, 'crc32': f'{info.CRC:08x}', 'sha256': sha(data)})
        lines = ansi.sub('', data.decode('utf-8', errors='replace')).splitlines()
        for index, line in enumerate(lines):
            item = {'member': info.filename, 'line': index + 1, 'text': line}
            if re.search(r'\bTest Files\s+|\bTests\s+\d+\s+passed', line):
                summaries.append(item)
            if merge_sha in line:
                merge_occurrences.append(item)
            if source_sha in line:
                source_occurrences.append(item)
            if ('refs/pull/55/merge' in line or 'git log -1 --format=%H' in line or 'git.exe log -1 --format=%H' in line):
                checkout_traces.append(item)
                if index + 1 < len(lines):
                    checkout_traces.append({'member': info.filename, 'line': index + 2, 'text': lines[index + 1]})
            if ('TRAINER_DOCS_ALLOW_MISSING_STATE' in line or ('warning' in line.lower() and ('control' in line.lower() or 'state' in line.lower()))):
                warnings.append(item)

assert len(entries) > 0
assert len(merge_occurrences) > 0, 'Actual CI log must show the synthetic test-merge SHA'
assert source['syntheticMerge']['sourceIsParent']
assert source['syntheticMerge']['tree'] == 'bcc9d32afd37e67a1ebc7e04325b7146335bb3ef'
normalized_summary = sorted(set(re.sub(r'^\S+Z\s+', '', row['text']).strip() for row in summaries))
member_index = {'capturedAt': datetime.now(timezone.utc).isoformat(), 'archive': archive.name, 'archiveBytes': len(archive_bytes), 'archiveSha256': sha(archive_bytes), 'memberCount': len(entries), 'uncompressedBytes': sum(row['bytes'] for row in entries), 'crcAllVerified': True, 'members': entries, 'extractedFilesWritten': 0}
(root / 'zip-member-hashes.json').write_text(json.dumps(member_index, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
summary = {'capturedAt': datetime.now(timezone.utc).isoformat(), 'runId': run['id'], 'sourceFreeze': source_sha, 'runMetadataHeadSHA': run['headSHA'], 'syntheticMergeSHA': merge_sha, 'syntheticMergeParents': source['syntheticMerge']['parents'], 'syntheticMergeTree': source['syntheticMerge']['tree'], 'sourceTreeMatchesSyntheticMergeTree': True, 'memberCount': len(entries), 'archiveBytes': len(archive_bytes), 'archiveSha256': sha(archive_bytes), 'crcAllVerified': True, 'extractedFilesWritten': 0, 'uniqueTestSummaryLines': normalized_summary, 'testSummaryOccurrences': summaries, 'syntheticMergeLogOccurrences': merge_occurrences, 'sourceFreezeLogOccurrences': source_occurrences, 'checkoutTraces': checkout_traces, 'externalControlStateWarningLines': warnings, 'scope': 'Source-freeze CI logs only. Repeated job/step logs are not added together as test totals. CI passing is not local-corpus, full Journey, package, visual, or human acceptance.'}
(root / 'zip-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'archive': archive.name, 'archiveBytes': len(archive_bytes), 'archiveSha256': sha(archive_bytes), 'memberCount': len(entries), 'crcAllVerified': True, 'extractedFilesWritten': 0, 'uniqueTestSummaryLines': normalized_summary, 'syntheticMergeSHA': merge_sha, 'syntheticMergeLogOccurrences': len(merge_occurrences), 'sourceTreeMatchesSyntheticMergeTree': True}, ensure_ascii=False, indent=2))
