# PR55 冻结源码 CI 只读快照

采集日期：2026-11-18（Asia/Shanghai）。这是 `f70137182ac75635b006d567b34616cc9a9f1bd4` 的首轮源码CI，不代替后续finaldocs提交的CI。

PR55在采集前后均为open/draft，source HEAD均为f701，base为 `58ba0ffc13458fb136c7d885b62ee0c898d4bab8`。实际active main Ruleset要求 `docs`、`verify`、`pr-policy`，三项当前required check均SUCCESS。采集未发评论、review、状态变更、合并或workflow dispatch。

- Workflow run：`44160559239`，attempt1，completed/success，run metadata head为f701；3个job全部completed/success。
- PR合成merge SHA：`06e1c4e7b265b27c6fa5138f8ae22cb1a952467a`，parents为58ba0ffc与f701；tree为 `bcc9d32afd37e67a1ebc7e04325b7146335bb3ef`，与冻结源码tree相同。
- 实际CI checkout日志包含该合成merge SHA及 `refs/pull/55/merge`，因此明确区分run metadata source head和CI实际checkout merge，不将二者混称一个commit。
- verify原日志独立报告188文件/2664测试以及34文件/369测试，共222文件/3033测试。job汇总日志与step日志是重复视图，只计一次。
- 云端docs明确设置 `TRAINER_DOCS_ALLOW_MISSING_STATE=1`；此成功不证明本地外置control状态新鲜度，也不证明本机私有公式语料、Journey、Windows包、视觉或用户验收。

## 原始证据

`logs-44160559239.zip` 为GH API直接下载的原ZIP字节，106268 bytes，SHA256 `a0f9acd88126f978e2d534f2245486d5a95241771958076fc489ed1203c6bfdf`。实际包含32个文件成员（以ZIP实测为准），逐项CRC、未压缩字节长度和SHA见 `zip-member-hashes.json`。只在内存读取成员，未解出重复日志文件。

`source-ci-summary.json` 汇总PR/run/jobs/required checks/active Ruleset/合成merge；`zip-summary.json`保留计数原行及其ZIP成员/行号。每个原生GH调用都有原JSON/ZIP、stderr及 `.exit.json`：10项全部直接child exit0，无shell或pipeline。ZIP分析也单独native0并留脚本SHA。

所有缓存文件的指纹索引见 `artifact-index.json`。源码、repo/index、control与矩阵没有写入。本快照完成时不得推断PR已脱离draft、用户已验收或获发布许可。
