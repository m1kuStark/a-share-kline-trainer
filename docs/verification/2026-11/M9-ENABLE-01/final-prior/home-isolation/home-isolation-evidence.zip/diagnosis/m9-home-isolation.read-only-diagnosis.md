# M9 packaged acceptance: Windows home isolation diagnosis

Scope: read-only source/evidence/official-document inspection. No application/build/acceptance rerun, product changes, acceptance-script changes, process termination or delivery-tree modification. The frozen e809 acceptance failure remains a failure.

## Finding

The home assertion confuses two different APIs. Electron `app.getPath('home')` uses Chromium's native Windows user-profile lookup. Node `os.homedir()` uses USERPROFILE on Windows when supplied. Setting USERPROFILE/HOME does not promise to change Electron's native home under the current Windows user token. This explains the observed real user home without implying that the trainer database uses that location.

The local lock pins Electron44.10.2; its DEPS pins Chromium152.0.7977.169 and Node24.22.2. Matching official sources and SHA256 records are in `m9-home-isolation.official-sources.json`.

## Exact primary sources

- Electron44.10.2 API implementation: https://github.com/electron/electron/blob/v44.10.2/shell/browser/api/electron_api_app.cc#L413 ; lines413 and949-957 map home to base::DIR_HOME and resolve it through PathService.
- Electron44.10.2 dependency pins: https://github.com/electron/electron/blob/v44.10.2/DEPS#L4 ; lines4-7 pin the Chromium and Node versions inspected here.
- Chromium152.0.7977.169 generic path provider: https://chromium.googlesource.com/chromium/src/+/refs/tags/152.0.7977.169/base/base_paths.cc#79 ; lines79-81 resolve DIR_HOME with GetHomeDir.
- Chromium152.0.7977.169 Windows home implementation: https://chromium.googlesource.com/chromium/src/+/refs/tags/152.0.7977.169/base/files/file_util_win.cc#807 ; lines807-812 use SHGetFolderPath with CSIDL_PROFILE, current-user token and SHGFP_TYPE_CURRENT. The success path does not read HOME or USERPROFILE.
- Node24.22.2 os documentation: https://github.com/nodejs/node/blob/v24.22.2/doc/api/os.md#L204 ; lines204-218 document USERPROFILE priority on Windows. HOME priority is the POSIX rule.
- Electron44.10.2 app documentation: https://github.com/electron/electron/blob/v44.10.2/docs/api/app.md#L677 ; lines677-692 distinguish userData and sessionData, with sessionData defaulting to userData; lines733-746 describe explicit setPath overrides and the before-ready requirement.
- Microsoft profile API: https://learn.microsoft.com/en-us/windows/win32/api/shlobj_core/nf-shlobj_core-shgetknownfolderpath ; NULL hToken requests the current user's known folder.
- Microsoft known-folder identity: https://learn.microsoft.com/en-us/windows/win32/shell/knownfolderid ; FOLDERID_Profile is5E6C858F-0E22-4760-9AFE-EA3317B67173 and corresponds to CSIDL_PROFILE.
- Microsoft SHGetFolderPathW source archive: `microsoft-SHGetFolderPathW.md`, official source URL and SHA in the sources index; lines83-97 document the token semantics.

The cached exploratory Chromium152.0.7961.0 source is superseded by the exact152.0.7977.169 archives for this conclusion.

## Product persistence and current run evidence

Let A = D:/Superlinear_Academy/Stock_WorkSpace/a-share-kline-trainer/output/acceptance/M9-ENABLE-01-20261118/zip-roundtrip/.acceptance-data.

| Persistence | Source route | Evidence / limit |
| --- | --- | --- |
| Trainer data root and SQLite, including custom formulas | desktop/src/desktop-config.ts72-75 gives TRAINER_DATA_DIR/TRAINER_DB first priority; desktop/src/main.ts20,700,737 uses Node homedir for fallback; server/src/index.ts43-44 opens config.databasePath; server/src/formulas/storage.ts38,45 receives DatabaseSync | A/trainer-state.json records databasePath=A/trainer.sqlite, pid74368, port11574, run-97beda2d-0499-41d0-a434-88fdc14e96f5. The SQLite file exists at A/trainer.sqlite. |
| First-run legacy-home adoption | desktop/src/data-home.ts216-221 | Explicit data env returns before default-home discovery, record persistence or probing. It still reads package-side legacy config first; this is inside the isolated extracted package. |
| Backend data/db/ready paths | desktop/src/desktop-config.ts111-115; server/src/config.ts66-76,86-91 | Main constructs explicit TRAINER_RUN_ID/DB/DATA_DIR/STATIC_DIR/READY_FILE. Isolated server discovery is restricted to the configured TDX root. |
| Main logs and window state | desktop/src/main.ts748-749 | A/logs/main.log records its own attached absolute location. A/window-state.json exists. |
| Recording library | web/src/recording/storage.ts64-69 uses IndexedDB | Main BrowserWindow at desktop/src/main.ts322-337 has no custom session/partition; no getPath/setPath/session/partition overrides were found in desktop/src. A/profile/IndexedDB exists. Actual sessionData must still be collected and asserted in a new run. |
| Chromium profile/cache | frozen script launches with --user-data-dir=A/profile; Electron sessionData default documented above | A/profile contains IndexedDB, Cache, Code Cache, blob_storage and GPU-related caches. Parent observed userData and appData matching expected paths, but raw identity was not saved before the assertion. Do not treat the failed receipt as complete identity proof. |
| Updater cache | installed node_modules/electron-updater/out/AppAdapter.js6-19 uses LOCALAPPDATA first on Windows, then Node homedir fallback | The acceptance env sets LOCALAPPDATA=A/home/AppData/Local. This is source reasoning, not proof that the update flow ran. |
| Other desktop data-side archive/migration/update state | desktop/src/main.ts751-761 assigns these to config.dataDir/config.databasePath | These assignments share the explicit data root; the failed boot did not exercise every write path. |

Frozen script lines67-68 clean inherited TRAINER_/PORTABLE/NODE options; line352 injects DB/data, sample market, USERPROFILE/HOME, APPDATA/LOCALAPPDATA/TEMP/TMP; line95 supplies the isolated Chromium profile. Line107 assumes Electron native home equals the environment home. That equality is the unsupported part of the oracle.

## Independent read-only Windows measurement and cleanup

`m9-home-isolation.native-profile.json` records direct SHGetKnownFolderPath(FOLDERID_Profile,flags0,hTokenNULL) and SHGetFolderPathW(CSIDL_PROFILE,SHGFP_TYPE_CURRENT,hTokenNULL). Both returned C:/Users/Stark_Du666; the independent .NET UserProfile query agreed. No create/set/redirect API was called.

`m9-home-isolation.historical-processes.json` records Win32_Process queries at2026-11-17T19:53:45.9657652Z: both historical app PID74368 and launcher PID73108 were absent. This is a point-in-time PID check, not proof about every descendant or all previous writes. The failed receipt also records port11574 released.

The main log contains an error preserved verbatim: `2026-11-17T19:47:00.339Z [error] [desktop] before-quit reached without graceful drain; closing server as fallback`. It occurred during failure cleanup; it is not a successful graceful-shutdown receipt.

## Minimal provable scheme, pending root decision

Preserve e809 and all failed evidence. Any new oracle revision needs its own hash/diff/rationale and a fresh extraction/run; do not relabel this failure as passed.

1. Observe and immediately persist the complete runtime identity, including exe, hash association, pid, process creation time, packaged/version, Electron nativeHome, Node homedir, userData/appData/sessionData/temp and relevant env values. Keep observed identity separate from a verified identity.
2. Compare Electron nativeHome with an independently queried Windows KnownFolder profile under the same token. Compare Node homedir with A/home. This preserves both strict checks while assigning each API its documented contract. It does not pretend environment redirection creates an OS security sandbox.
3. Continue exact exe/hash/source/version and isolated userData/appData/sessionData checks, plus actual trainer-state pid/runId/port/databasePath, data-dir settings effectiveDir, log path and window-state path. No app.setPath monkey-patch: an after-start override could hide initial writes and would alter the subject under test.
4. Mark cleanup identity verified only after the launched executable path and file hashes are correct and the evaluated product pid is corroborated with its OS image path/creation time. Save observations before any later assertion so a failed path check still leaves evidence. Only a verified matching process may become a forced-cleanup target; preserve graceful-close errors separately.
5. For the narrower claim that the enumerated trainer/browser persistence paths are isolated, the source chain plus these actual path/file checks is the minimum evidence. For a broader no-writes-anywhere-outside claim, add process-tree filesystem tracing or execute in an OS sandbox/VM. Before/after hashes of selected real data directories alone cannot detect all transient writes.

If the requirement remains literally Electron nativeHome=A/home, environment variables and --user-data-dir cannot meet it under the present Windows token. That requires an actual suitable Windows account/profile or isolated OS environment, rather than deleting the assertion or spoofing the native return value.

## Verification limits

No second application run was performed. Node homedir and Electron sessionData from the failed process were not captured and cannot be reconstructed from the receipt; they remain required runtime evidence for a future run. Current evidence supports the configured and observed data root, not complete application acceptance or zero outside writes. The acceptance script remains SHA256 e809b3a2dee64e1d09f92a7961da1a7afe6cd4010e866019cda0587bc8763def.
