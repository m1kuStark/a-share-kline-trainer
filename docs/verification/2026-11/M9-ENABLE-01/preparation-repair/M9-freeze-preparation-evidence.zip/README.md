# M9 freeze preparation evidence

This is an external, byte-preserving supplemental stage. It retains prior verified source/CI/review archives, the failed f701 candidate, preparation fixes, CMD encoding diagnosis, home-oracle repair evidence, fixture RED/GREEN patches, and the later targeted reproduction receipts. It does not claim full candidate or user acceptance.

All source evidence is copied unchanged. artifact-manifest.json maps source paths to archive paths, sizes and SHA256. credential-scan.json records filename and pattern screening without credential values. Runtime profiles, redundant patch-apply work copies and reversible CCR caches are excluded; no personal database, release executable, production package or user recording is intentionally included.

ZIP contents are verified again against staged hashes, including the complete nested evidence ZIP bytes. The paired .copy-integrity.json outside the ZIP records its own hash and source/stage/ZIP equality. Copy the ZIP and paired manifest/integrity files only; the expanded stage is optional.