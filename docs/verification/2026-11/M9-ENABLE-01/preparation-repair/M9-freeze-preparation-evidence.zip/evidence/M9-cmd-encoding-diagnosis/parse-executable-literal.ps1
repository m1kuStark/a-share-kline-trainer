param([Parameter(Mandatory=$true)][string]$ScriptPath,[Parameter(Mandatory=$true)][string]$ReceiptPath)
$ErrorActionPreference = 'Stop'
$tokens = $null
$parseErrors = $null
$ast = [Management.Automation.Language.Parser]::ParseFile($ScriptPath,[ref]$tokens,[ref]$parseErrors)
$literals = @($ast.FindAll({param($node) $node -is [Management.Automation.Language.StringConstantExpressionAst] -and $node.Value.StartsWith('app\K') -and $node.Value.EndsWith('.exe')},$true))
$expected = 'app\K' + [char]0x7EBF + [char]0x8BAD + [char]0x7EC3 + [char]0x5668 + '.exe'
$literal = if ($literals.Count -eq 1) { $literals[0].Value } else { $null }
$matches = $literals.Count -eq 1 -and [string]::Equals($literal,$expected,[StringComparison]::Ordinal)
$bytes = [IO.File]::ReadAllBytes($ScriptPath)
$sha = (Get-FileHash -LiteralPath $ScriptPath -Algorithm SHA256).Hash.ToLowerInvariant()
$errors = @($parseErrors | ForEach-Object { [ordered]@{message=$_.Message;errorId=$_.ErrorId;startLine=$_.Extent.StartLineNumber;endLine=$_.Extent.EndLineNumber;text=$_.Extent.Text} })
$passed = $errors.Count -eq 0 -and $matches
$receipt = [ordered]@{
  observedAt=[DateTimeOffset]::Now.ToString('o')
  hostExecutable=(Get-Process -Id $PID).Path
  psVersion=$PSVersionTable.PSVersion.ToString()
  defaultEncodingCodePage=[Text.Encoding]::Default.CodePage
  cultureAnsiCodePage=[Globalization.CultureInfo]::CurrentCulture.TextInfo.ANSICodePage
  sourcePath=$ScriptPath
  sourceSha256=$sha
  sourceBytes=$bytes.Length
  hasUtf8Bom=($bytes.Length -ge 3 -and $bytes[0] -eq 0xef -and $bytes[1] -eq 0xbb -and $bytes[2] -eq 0xbf)
  parserErrors=$errors
  literalCount=$literals.Count
  actualLiteral=$literal
  actualCodePoints=@($literal.ToCharArray() | ForEach-Object {'U+{0:X4}' -f [int]$_})
  expectedLiteral=$expected
  expectedCodePoints=@($expected.ToCharArray() | ForEach-Object {'U+{0:X4}' -f [int]$_})
  oracle='Exactly one executable path literal must equal the expected path by ordinal comparison, and parsing must have no errors.'
  literalMatches=$matches
  parsedOnly=$true
  topLevelExecuted=$false
  appRun=$false
  passed=$passed
}
[IO.File]::WriteAllText($ReceiptPath,($receipt | ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
Write-Output ('PS=' + $PSVersionTable.PSVersion.ToString() + '; BOM=' + $receipt.hasUtf8Bom + '; parserErrors=' + $errors.Count + '; literalMatches=' + $matches)
if (!$passed) { Write-Error 'EXECUTABLE_PATH_LITERAL_ORACLE_FAILED' -ErrorAction Continue; exit 1 }
exit 0