# Acceptance CMD encoding diagnosis

The actual CMD entry calls Windows PowerShell (`powershell.exe`). Its BOM-less UTF-8 PS1 contains a Chinese executable path. Windows PowerShell 5.1 parses the script without syntax errors but corrupts that string. The resulting path does not exist and hits the complete-ZIP guard before acceptance state creation or application launch.

| Parser host | Fixture | Literal oracle | Native exit |
|---|---|---|---|
| Windows PowerShell 5.1.26100.9818 | Original, no BOM | Failed | 1 |
| Windows PowerShell 5.1.26100.9818 | UTF-8 BOM only | Passed | 0 |
| PowerShell 7.6.9 | Original, no BOM | Passed | 0 |
| PowerShell 7.6.9 | UTF-8 BOM only | Passed | 0 |

The oracle requires exactly one executable-path string to equal the expected Unicode path, with no parser errors. The expected Chinese characters are constructed from Unicode code points in an ASCII-only helper, avoiding a common encoding error in the test itself. The helper only invokes Parser.ParseFile and inspects AST nodes; parsed script top-level code is never executed.

The original fixture is 2525 bytes (SHA256 d4adc34ba3eb2463a5c59e806d1cc8c89218eff96b5db3d488ae2a3a7efcedb4). The BOM fixture is 2528 bytes (SHA256 abc8c09d9200fe291e17549d5c46270479dfbe7cad3b156b395e3f91f7243502). Its first bytes are EF BB BF; every remaining byte is identical to the original.

The read-only path probe confirms the correct executable exists, the PS5-decoded filename does not exist, and .acceptance-data is absent. The original real-CMD failure JSON/logs are archived unchanged beside this report. The latest exact-marker cmd.exe probe found no matching process. No process was terminated.

Microsoft's archived about_Character_Encoding source explains the Windows PowerShell ANSI interpretation for BOM-less source files (lines 68-70 and 147-149). See official-sources.json for source URL and hash.

The minimal repair is BOM-only on scripts/acceptance/Start-Acceptance.ps1. Do not change logic or timeout budgets. Parser/path checks establish the encoding repair; they do not establish successful CMD/app acceptance. Root owns the repository repair, repackaging, and actual CMD acceptance verification.

All writes in this diagnostic task are in the external headroom cache. No repository changes or app launches were performed.