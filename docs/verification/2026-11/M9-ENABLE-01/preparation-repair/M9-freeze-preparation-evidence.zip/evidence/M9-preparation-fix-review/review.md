# M9 preparation fix: independent read-only review

裁决：可合入本次三文件准备修复。Critical=0 / Important=0 / Minor=0。此裁决不代表M9完整候选、生产ZIP、真实CMD启动或用户验收通过。

审查基线：f70137182ac75635b006d567b34616cc9a9f1bd4；当前HEAD仍为该提交，审查对象是三文件未提交增量。没有写仓库、运行应用/测试或结束进程；仅执行静态绑定检查并写外部cache。

## 五维核验

1. 计划对齐：任务卡allowed_paths明确增加e2e/formula-chart.spec.ts和scripts/acceptance/Start-Acceptance.ps1，新增准备修复说明与真实缺陷相符；没有扩展公式语义或发布权限。manifest base为58ba0ffc13458fb136c7d885b62ee0c898d4bab8，确为当前HEAD祖先（git merge-base原生0）。锚点A1第28项为server/test/formula-seed.test.ts；A2为前述base及祖先关系；A3的既有docs_impact清单保留，当前增量没有新增产品规格变化。

2. 质量：formula-chart.spec.ts:18-42保留pageerror断言，通过finally保证断言失败后仍尝试清理；GET精确要求200、DELETE精确要求204，失败不再静默return；随后重新GET并断言五个夹具名均不存在。删除范围仍受非builtin与固定夹具名双重限制，不扩大到其他公式。清理失败会使测试失败。未发现需修问题。

3. 架构与集成：使用现有真实/api/formulas API，不引入产品代码或额外测试基础设施。API的DELETE仅在deleteFormulaRow成功后返回204（server/src/formulas/api.ts:142-145），存储层实际执行DELETE（storage.ts:141-146）。单worker、同run独立数据库模型与现有e2e约束一致。PS1仅增加UTF-8 BOM，无逻辑、参数、超时或预算改变。

4. 断言真实性：相对f701，四个test正文从首个test声明至文件末尾在规范化换行后完全一致；无skip、无预期放宽。RED run-b59a8e37-e4c7-4550-878c-d7949aec6fe5的真实journey.log显示无残留断言收到CHART_MAIN、CHART_SUB，1 failed，外部原生退出码1；属于正确失败原因。恢复原清理缺口会再次触发该断言。GREEN在审查期间已结束：run-917219e4-b91e-4dec-8ead-d9169ae71748真实日志8 passed，外部原生0；含4公式、3KDJ、D28，单worker、零重试。D28通过不能反推旧D28超时已被此修复直接解释。

5. harness证据：本次独立check-binding --strict原生0，formula-chart矩阵4行covered/open0/RED0，绑定用例名与实际源码和日志一致。未运行vitest list或应用测试；已有真实执行日志直接列出被审查的四个Playwright用例。原始RED/GREEN命令、完整日志、原生退出码及日志SHA已核验并归档。源文件当前哈希与完整diff一起固定。本次green是相关范围回归，不替代提交后全量候选验证。台账写入由root负责，本审查未写台账。

## BOM独立证据

当前Start-Acceptance.ps1为2528字节，SHA256 abc8c09d9200fe291e17549d5c46270479dfbe7cad3b156b395e3f91f7243502，与此前独立BOM fixture一致。前三字节EF BB BF，其余逐字节等于原2525字节d4adc34ba3eb2463a5c59e806d1cc8c89218eff96b5db3d488ae2a3a7efcedb4。此前真实PS5解析原版路径失败/native1，BOM版通过/native0；PS7两版native0。此处未重新运行应用或CMD。

## 搁置不判

- 未提交增量尚无新提交SHA；RED/GREEN运行manifest及外部receipt记录HEAD=f701。当前文件快照和哈希明确审查对象，但不能据此声称已完成同一冻结提交的正式整批验收。
- 待root提交后执行所需完整门禁、生产构建/包装与全新ZIP实际CMD启动；本次未核验它们，也没有将parser成功写成应用成功。
- 未复核完整视觉验收、生产录像回放或用户验收。没有以8项局部GREEN替代这些项目。

报告范围外的既有问题不在此三文件裁决内；无需为本次准备修复增加产品语义或放宽断言。