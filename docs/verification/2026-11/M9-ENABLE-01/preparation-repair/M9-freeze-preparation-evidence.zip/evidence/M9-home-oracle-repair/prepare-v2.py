from pathlib import Path
import hashlib
import json
import difflib

cache = Path(r'C:/Users/Stark_Du666/.codex/headroom-cache/M9-home-oracle-repair')
original = cache / 'm9-packaged-acceptance.original.cjs'
source = original.read_text(encoding='utf-8')
expected_sha = 'e809b3a2dee64e1d09f92a7961da1a7afe6cd4010e866019cda0587bc8763def'
assert hashlib.sha256(original.read_bytes()).hexdigest() == expected_sha
updated = source
changes = []

def replace_once(before, after, reason):
    global updated
    assert updated.count(before) == 1, (reason, updated.count(before))
    updated = updated.replace(before, after, 1)
    changes.append({'reason': reason, 'before': before, 'after': after})

replace_once(
    "const inside = (actual, parent) => path.resolve(actual).toLowerCase().startsWith(path.resolve(parent).toLowerCase() + path.sep)\n",
    "const inside = (actual, parent) => path.resolve(actual).toLowerCase().startsWith(path.resolve(parent).toLowerCase() + path.sep)\n"
    "// Capture Windows KnownFolder before constructing or overriding the child environment.\n"
    "const expectedNativeHome = execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', \"[Environment]::GetFolderPath('UserProfile')\"], { encoding: 'utf8', windowsHide: true }).trim()\n"
    "const expectedNativeHomeCapturedAt = new Date().toISOString()\n"
    "assert.ok(path.isAbsolute(expectedNativeHome), 'Windows native UserProfile oracle must be absolute')\n",
    'Independent native KnownFolder oracle captured before child environment overrides')

replace_once(
    'receipt.visualFrames = []\n',
    'receipt.visualFrames = []\n'
    "receipt.nativeHomeOracle = { expectedNativeHome, capturedAt: expectedNativeHomeCapturedAt, command: \"[Environment]::GetFolderPath('UserProfile')\", environment: 'inherited operator environment, before child overrides' }\n"
    'receipt.observedIdentities = []\n'
    'receipt.migrationPromptChecks = []\n',
    'Retain native oracle and early observed identities in receipt')

helpers = """// BEGIN CACHE-ONLY ISOLATION ORACLES (pure path assertions; no application hooks).
function readProcessIdentity(pid) {
  assert.ok(Number.isSafeInteger(pid) && pid > 0, 'Observed product PID must be a positive safe integer')
  const command = `[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false); $m9ObservedProcess = Get-Process -Id ${pid} -ErrorAction Stop; [pscustomobject]@{ pid = $m9ObservedProcess.Id; exe = $m9ObservedProcess.Path; startedAt = $m9ObservedProcess.StartTime.ToUniversalTime().ToString('o') } | ConvertTo-Json -Compress`
  const observed = JSON.parse(execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', command], { encoding: 'utf8', windowsHide: true, timeout: 5000 }).trim())
  assert.equal(observed.pid, pid, 'OS process PID mismatch')
  assert.ok(path.isAbsolute(observed.exe), 'OS process executable path must be absolute')
  assert.ok(typeof observed.startedAt === 'string' && Number.isFinite(Date.parse(observed.startedAt)), 'OS process creation time missing or invalid')
  return observed
}
function assertAdditionalBootPaths(identity) {
  for (const [actual, expected, name] of [[identity.nodeHome, home, 'Node home'], [identity.sessionData, profile, 'Electron sessionData'], [identity.temp, temp, 'Electron temp'], [identity.logs, path.join(profile, 'logs'), 'Electron logs']]) assert.ok(samePath(actual, expected), `${name} isolation mismatch ${actual} != ${expected}`)
}
function assertStorageArtifact(actual, expected, name) {
  assert.ok(samePath(actual, expected), `${name} actual path mismatch ${actual} != ${expected}`)
  assert.ok(inside(actual, data), `${name} escaped isolated data directory`)
}
function inspectProductStorage(requireExitFiles) {
  const observed = {}
  for (const [name, file, required] of [['mainLog', path.join(data, 'logs', 'main.log'), true], ['operationLog', path.join(data, 'logs', 'operations.log'), requireExitFiles], ['windowState', path.join(data, 'window-state.json'), requireExitFiles]]) {
    if (!fs.existsSync(file)) {
      assert.equal(required, false, `${name} missing at expected product data path: ${file}`)
      observed[name] = { expected: file, exists: false }
      continue
    }
    const realPath = fs.realpathSync.native(file)
    assertStorageArtifact(realPath, file, name)
    const info = fs.statSync(file)
    assert.ok(info.isFile(), `${name} path must be a file`)
    observed[name] = { expected: file, exists: true, realPath, bytes: info.size, sha256: hashFile(file) }
  }
  return observed
}
// END CACHE-ONLY ISOLATION ORACLES.
"""
replace_once('async function boot(label) {\n', helpers + 'async function boot(label) {\n', 'Add explicit Node/session/temp/log and physical product storage path oracles')

old_identity = "  const identity = await app.evaluate(({ app, BrowserWindow }) => ({ packaged: app.isPackaged, version: app.getVersion(), exe: app.getPath('exe'), userData: app.getPath('userData'), appData: app.getPath('appData'), home: app.getPath('home'), pid: process.pid, windows: BrowserWindow.getAllWindows().map(w => ({ visible: w.isVisible(), minimized: w.isMinimized(), destroyed: w.isDestroyed(), title: w.getTitle() })) }))\n"
replace_once(old_identity, "  identity.windows = await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows().map(w => ({ visible: w.isVisible(), minimized: w.isMinimized(), destroyed: w.isDestroyed(), title: w.getTitle() })))\n", 'Refresh visible-window observation at original assertion position')

early_identity = """  const identity = await app.evaluate(({ app, BrowserWindow }) => ({ packaged: app.isPackaged, version: app.getVersion(), exe: app.getPath('exe'), userData: app.getPath('userData'), appData: app.getPath('appData'), home: app.getPath('home'), nodeHome: process.getBuiltinModule('node:os').homedir(), sessionData: app.getPath('sessionData'), temp: app.getPath('temp'), logs: app.getPath('logs'), pid: process.pid, windows: BrowserWindow.getAllWindows().map(w => ({ visible: w.isVisible(), minimized: w.isMinimized(), destroyed: w.isDestroyed(), title: w.getTitle() })) }))
  assert.ok(Number.isSafeInteger(identity.pid) && identity.pid > 0, 'Observed product PID must be a positive safe integer')
  const observedProcess = readProcessIdentity(identity.pid)
  assert.ok(samePath(identity.exe, exe), 'Observed Electron executable identity mismatch')
  assert.ok(samePath(observedProcess.exe, exe), 'Observed OS process executable identity mismatch')
  identity.osProcess = observedProcess
  lastVerifiedIdentity = identity
  receipt.observedIdentities.push({ label, observedAt: new Date().toISOString(), launcherPid: child.pid, identity })
  await saveReceipt()
"""
replace_once("  page = await app.firstWindow({ timeout: 60000 })\n", early_identity + "  page = await app.firstWindow({ timeout: 60000 })\n", 'Persist OS-verified executable and valid product PID before subsequent waits/assertions')

old_isolation = "  for (const [actual, expected] of [[identity.exe, exe], [identity.userData, profile], [identity.appData, roaming], [identity.home, home]]) assert.ok(samePath(actual, expected), `Isolation mismatch ${actual} != ${expected}`)\n"
new_isolation = "  for (const [actual, expected] of [[identity.exe, exe], [identity.userData, profile], [identity.appData, roaming], [identity.home, expectedNativeHome]]) assert.ok(samePath(actual, expected), `Isolation mismatch ${actual} != ${expected}`)\n  assertAdditionalBootPaths(identity)\n"
replace_once(old_isolation, new_isolation, 'Correct only native home expected path; retain original exe/userData/appData assertions and add strict isolated Node/session/temp/log checks')

migration_step = """  const migrationDialog = page.getByRole('dialog', { name: '从 v1.2.7 迁移', exact: true })
  const migrationCheck = { label, preferenceKey: 'mig-inline-dismissed', observedBefore: await page.evaluate(() => localStorage.getItem('mig-inline-dismissed')), action: null }
  receipt.migrationPromptChecks.push(migrationCheck)
  await saveReceipt()
  if (label === 'boot-one') {
    assert.equal(migrationCheck.observedBefore, null, 'Fresh profile must not pre-dismiss the migration prompt')
    await expect(migrationDialog).toBeVisible()
    await migrationDialog.getByRole('button', { name: '我不用 v1.2.7，不再提示', exact: true }).click()
    migrationCheck.action = 'real DOM click: 我不用 v1.2.7，不再提示'
    await expect(migrationDialog).toBeHidden()
  } else {
    assert.equal(migrationCheck.observedBefore, '1', 'Migration dismissal preference did not survive restart')
    await expect(migrationDialog).toBeHidden()
    migrationCheck.action = 'verified persisted dismissal; no DOM write or repeated click'
  }
  migrationCheck.observedAfter = await page.evaluate(() => localStorage.getItem('mig-inline-dismissed'))
  assert.equal(migrationCheck.observedAfter, '1', 'Real migration dismissal must persist its preference')
  migrationCheck.hidden = true
  await saveReceipt()
"""
replace_once("  await expect(page.getByRole('tab', { name: '经典模式', exact: true })).toBeVisible({ timeout: 60000 })\n", "  await expect(page.getByRole('tab', { name: '经典模式', exact: true })).toBeVisible({ timeout: 60000 })\n" + migration_step, 'Dismiss the fresh-profile migration modal through its exact real DOM button; verify persistence without storage writes on restart')

replace_once("  receipt.boots.push({ label, identity, state, health, recordingNamespace: environment.recordingNamespace })\n", "  receipt.boots.push({ label, identity, state, health, recordingNamespace: environment.recordingNamespace, storagePaths: inspectProductStorage(false) })\n", 'Record and verify physical main log plus any existing operations/window-state paths at boot')
replace_once("  assert.ok(fs.existsSync(path.join(profile, 'Local State')), 'Isolated Chromium profile missing')\n", "  assert.ok(fs.existsSync(path.join(profile, 'Local State')), 'Isolated Chromium profile missing')\n  receipt.boots.at(-1).closedStoragePaths = inspectProductStorage(true)\n", 'Verify physical main/operations logs and window-state files after existing clean process exit, without adding waits')

replace_once("          const actualExe = execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `(Get-Process -Id ${ownedPid} -ErrorAction Stop).Path`], { encoding: 'utf8', windowsHide: true, timeout: 5000 }).trim()\n", "          const actualProcess = readProcessIdentity(ownedPid)\n          const actualExe = actualProcess.exe\n", 'Retain bounded 5000ms OS process probe, now including creation time')
replace_once("          assert.ok(samePath(actualExe, exe), 'Cleanup PID executable identity changed')\n", "          assert.ok(samePath(actualExe, exe), 'Cleanup PID executable identity changed')\n          assert.equal(actualProcess.startedAt, lastVerifiedIdentity.osProcess.startedAt, 'Cleanup PID creation time changed; refusing to kill a reused PID')\n", 'Require identical OS creation time before forced PID-tree cleanup')
replace_once("          receipt.failureCleanup.verifiedExecutable = actualExe\n", "          receipt.failureCleanup.verifiedExecutable = actualExe\n          receipt.failureCleanup.verifiedProcessStartedAt = actualProcess.startedAt\n", 'Preserve cleanup OS creation-time proof in receipt')

output = cache / 'm9-packaged-acceptance.v2.cjs'
output.write_bytes(updated.encode('utf-8'))
(cache / 'v2.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True), updated.splitlines(True), fromfile=original.name, tofile=output.name)), encoding='utf-8')
(cache / 'change-map.json').write_text(json.dumps(changes, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'output': str(output), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(), 'bytes':output.stat().st_size, 'changes':len(changes)}))
