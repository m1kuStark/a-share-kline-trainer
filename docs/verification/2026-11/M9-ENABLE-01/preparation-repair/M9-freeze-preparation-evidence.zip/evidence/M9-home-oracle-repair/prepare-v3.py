from pathlib import Path
import hashlib, json, difflib

cache=Path(r'C:/Users/Stark_Du666/.codex/headroom-cache/M9-home-oracle-repair')
v2=cache/'m9-packaged-acceptance.v2.cjs'
source=v2.read_text(encoding='utf-8')
assert hashlib.sha256(v2.read_bytes()).hexdigest()=='91b5003fb8881854472958150cd3d1c73ebfdb5b5cfb9792e46c5c2e38cf759f'
updated=source
changes=[]
def replace_once(before,after,reason):
 global updated
 assert updated.count(before)==1,(reason,updated.count(before))
 updated=updated.replace(before,after,1)
 changes.append({'reason':reason,'before':before,'after':after})

helper="""// BEGIN CACHE-ONLY SPAWN ENVIRONMENT ORACLE.
function assertSpawnIsolation(spawnEnv) {
  assert.ok(Number.isInteger(port) && port > 0 && port <= 65535, 'Spawn port must be the valid sampled loopback port')
  assert.ok(samePath(data, path.join(packageRoot, '.acceptance-data')) && inside(data, packageRoot), 'Spawn data root must belong to the fresh package')
  assert.ok(inside(profile, data), 'Chromium profile must belong to the isolated data root')
  assert.ok(samePath(market, path.join(packageRoot, 'sample-market')) && inside(market, packageRoot), 'Spawn market root must be the fresh package sample-market')
  const expected = { TRAINER_DATA_DIR: data, TRAINER_DB: path.join(data, 'trainer.sqlite'), TDX_ROOT: market, USERPROFILE: home, HOME: home, APPDATA: roaming, LOCALAPPDATA: local, TEMP: temp, TMP: temp, PORT: String(port), OPEN_BROWSER: '0', HOMEDRIVE: path.parse(home).root.replace(/[\\\\/]$/, ''), HOMEPATH: home.slice(path.parse(home).root.length - 1) }
  for (const [name, value] of Object.entries(expected)) assert.equal(spawnEnv[name], value, `Spawn environment ${name} does not match the prepared isolation value`)
  for (const name of ['TRAINER_DATA_DIR', 'TRAINER_DB', 'USERPROFILE', 'HOME', 'APPDATA', 'LOCALAPPDATA', 'TEMP', 'TMP']) assert.ok(samePath(spawnEnv[name], data) || inside(spawnEnv[name], data), `Spawn environment ${name} escaped the isolated data root`)
  assert.ok(inside(spawnEnv.TDX_ROOT, packageRoot) && samePath(spawnEnv.TDX_ROOT, market), 'Spawn TDX root escaped the package sample-market')
  const trainerKeys = Object.keys(spawnEnv).filter(name => /^TRAINER_/i.test(name)).sort()
  assert.deepEqual(trainerKeys, ['TRAINER_DATA_DIR', 'TRAINER_DB'], 'Unexpected inherited TRAINER_* runtime/control/manifest variable')
  const forbidden = Object.keys(spawnEnv).filter(name => /^PORTABLE_EXECUTABLE/i.test(name) || ['NODE_OPTIONS', 'ELECTRON_RUN_AS_NODE', 'DESKTOP_DEV_URL', 'TDX_DIR', 'HOST'].includes(name.toUpperCase()))
  assert.deepEqual(forbidden, [], 'Unexpected inherited launch/runtime variable')
  return { expected, trainerKeys, forbidden, dataRoot: data, sampleMarket: market, sampledPort: port }
}
// END CACHE-ONLY SPAWN ENVIRONMENT ORACLE.
"""
replace_once('async function boot(label) {\n',helper+'async function boot(label) {\n','Add pure fail-closed spawn environment oracle')
replace_once("  app = await electron.launch({ executablePath: exe, args: [`--user-data-dir=${profile}`], env, cwd: packageRoot, timeout: 60000 })\n", "  const spawnPreflight = assertSpawnIsolation(env)\n  receipt.spawnPreflightChecks ??= []\n  receipt.spawnPreflightChecks.push({ label, checkedAt: new Date().toISOString(), ...spawnPreflight })\n  await saveReceipt()\n  app = await electron.launch({ executablePath: exe, args: [`--user-data-dir=${profile}`], env, cwd: packageRoot, timeout: 60000 })\n",'Validate and persist every spawn environment before each launch')
old="  const identity = await app.evaluate(({ app, BrowserWindow }) => ({ packaged: app.isPackaged, version: app.getVersion(), exe: app.getPath('exe'), userData: app.getPath('userData'), appData: app.getPath('appData'), home: app.getPath('home'), nodeHome: process.getBuiltinModule('node:os').homedir(), sessionData: app.getPath('sessionData'), temp: app.getPath('temp'), logs: app.getPath('logs'), pid: process.pid, windows: BrowserWindow.getAllWindows().map(w => ({ visible: w.isVisible(), minimized: w.isMinimized(), destroyed: w.isDestroyed(), title: w.getTitle() })) }))\n"
replace_once(old,"  const identity = await app.evaluate(({ app }) => ({ exe: app.getPath('exe'), pid: process.pid }))\n",'Bootstrap observes only executable and PID before app readiness')
later="  identity.windows = await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows().map(w => ({ visible: w.isVisible(), minimized: w.isMinimized(), destroyed: w.isDestroyed(), title: w.getTitle() })))\n"
full="""  const readyIdentity = await app.evaluate(({ app, BrowserWindow }) => {
    if (!app.isReady()) throw new Error('Electron app must be ready before observing sessionData/logs and other full identity paths')
    return { packaged: app.isPackaged, version: app.getVersion(), exe: app.getPath('exe'), userData: app.getPath('userData'), appData: app.getPath('appData'), home: app.getPath('home'), nodeHome: process.getBuiltinModule('node:os').homedir(), sessionData: app.getPath('sessionData'), temp: app.getPath('temp'), logs: app.getPath('logs'), pid: process.pid, windows: BrowserWindow.getAllWindows().map(w => ({ visible: w.isVisible(), minimized: w.isMinimized(), destroyed: w.isDestroyed(), title: w.getTitle() })) }
  })
  assert.equal(readyIdentity.pid, identity.osProcess.pid, 'Product PID changed between bootstrap and ready identity')
  assert.ok(samePath(readyIdentity.exe, identity.osProcess.exe), 'Product executable changed between bootstrap and ready identity')
  Object.assign(identity, readyIdentity)
"""
replace_once(later,full,'Observe logs/sessionData only after existing UI readiness, fail closed without waiting or overriding paths')
out=cache/'m9-packaged-acceptance.v3.cjs'
out.write_bytes(updated.encode('utf-8'))
(cache/'v3-from-v2.diff').write_bytes(''.join(difflib.unified_diff(source.splitlines(True),updated.splitlines(True),fromfile=v2.name,tofile=out.name)).encode('utf-8'))
(cache/'v3-change-map.json').write_bytes((json.dumps(changes,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size,'changes':len(changes)}))
