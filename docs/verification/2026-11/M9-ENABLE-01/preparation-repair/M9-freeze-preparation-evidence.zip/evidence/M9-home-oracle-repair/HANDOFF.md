# M9 Windows home oracle repair — review handoff

This is cache-only acceptance preparation. No tracked repository file, control state, product code, acceptance extraction, Electron application, or packaged executable was modified or run by this agent. Root must review v2 before any production acceptance run.

## Files and identity

- Original snapshot: `m9-packaged-acceptance.original.cjs`, SHA256 `e809b3a2dee64e1d09f92a7961da1a7afe6cd4010e866019cda0587bc8763def`.
- Proposed script: `m9-packaged-acceptance.v2.cjs`, SHA256 `91b5003fb8881854472958150cd3d1c73ebfdb5b5cfb9792e46c5c2e38cf759f`.
- Full review diff: `v2.diff`; exact replacements and rationale: `change-map.json`.
- Every original assertion: `assertion-comparison.json` includes source/revised line, full assertion call and preservation result. All 210 original assert/expect calls remain; 25 assertions are added.
- Fresh verification: `preparation-verification.json`, `verify-preparation.*`, `node-check.*`. Native exit codes for verifier and node --check are 0. The verifier is static/pure except read-only Get-Process of its own Node PID, a Node os.homedir child probe and Windows native-folder queries. It does not load the acceptance script as a module or launch the app.

## Assertion-level changes and preservation

1. Original exe/userData/appData entries and their path equality assertion remain. Only the fourth expected value changes from fake environment home to independently captured Windows native UserProfile. Capture occurs before constructing the child environment or overriding it.
2. Node home is collected via `process.getBuiltinModule('node:os').homedir()` and must exactly equal the fake home. Electron sessionData must equal the isolated profile; temp must equal fake temp; logs must equal profile/logs. Electron v44.10.2 source GetDefaultAppLogPath documents userData/logs for Windows; exact source evidence is already archived in M9-acceptance-brief.
3. Immediately after launch, identity acquisition precedes firstWindow and classic-mode waits. Only after positive safe PID, Electron exe and real Get-Process exe checks does the script set lastVerifiedIdentity, append observedIdentities and persist the receipt. Observed identity is process evidence; packaged/version/window/DB/service assertions still run in their original positions and must pass independently.
4. OS identity records Get-Process UTC creation time. The cleanup probe retains 5000ms and the existing executable equality assertion, and now rejects a different creation time before taskkill. All original cleanup assertions, taskkill timeout, PID-disappearance checks, health/TCP probes and limits remain.
5. Actual product main.log, operations.log and window-state.json are checked through native realpath and exact expected data paths; file metadata and hashes go into the receipt. main.log is required at boot. Operations/window-state files are recorded if already present at boot, then required after each existing clean exit. No new polling or sleep is added for these files. Electron logs path is kept distinct from product data/logs.
6. After the existing classic-tab visibility assertion, first boot requires a fresh missing `mig-inline-dismissed` preference, waits for exact dialog `从 v1.2.7 迁移`, clicks exact button `我不用 v1.2.7，不再提示` through real DOM, asserts the dialog hidden and reads preference `1`. Second boot requires preference still `1` and dialog hidden without another click. The script contains zero localStorage.setItem calls. The action and before/after values are recorded in migrationPromptChecks.
7. All unrelated original helper functions are byte-for-byte unchanged. Static comparison proves every original timeout property and timeout/setTimeout call has unchanged value and occurrence count. Product assertions for formulas, built-ins, training, native window matrix, timeframe scenes, real trade, export, settlement, recording replay, restart, namespace, source/version/hash/DB/health remain.
8. Wrapper hash is still read dynamically from the extracted Start-Acceptance.ps1. No wrapper expectation or wrapper invocation change was made. The separate PS5 UTF-8/BOM correction belongs to root.

## Pure-oracle results and limits

28 cases pass: the old oracle rejects the valid native/Node split; v2 accepts it; each exe/userData/appData/native-home/Node-home/sessionData/temp/logs drift rejects; exact physical log/window-state paths pass while escaped and wrong in-data paths reject; unsafe PID variants reject; cleanup creation-time mismatch rejects. Native-folder queries remain the same under fake USERPROFILE while Node home redirects. These are preparation tests, not product acceptance, visual acceptance, package/CMD acceptance or proof of zero writes outside the extraction. Runtime sessionData/temp/logs and the added file checks remain to be observed by root in a fresh extraction.

## Preparation errors retained

The first generator invocation failed on this host Python because Path.write_text does not accept newline. It produced no v2; the generator now writes UTF-8 bytes and the successful rerun is verified. The exact traceback is in preparation-errors.log. An existing Headroom search compressor emitted KeyError(files_represented) while printing stats; this affected diagnostic display only, not v2 or any assertion. Its traceback is also retained.
