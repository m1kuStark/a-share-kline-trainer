const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const vm = require('node:vm')
const crypto = require('node:crypto')
const { execFileSync, spawnSync } = require('node:child_process')
const { createRequire } = require('node:module')
const cache = __dirname
const originalPath = path.join(cache, 'm9-packaged-acceptance.v2.cjs')
const revisedPath = path.join(cache, 'm9-packaged-acceptance.v3.cjs')
const req = createRequire('C:/Users/Stark_Du666/.codex/worktrees/m9-enable-01/a-share-kline-trainer/package.json')
const ts = req('typescript')
const original = fs.readFileSync(originalPath, 'utf8')
const revised = fs.readFileSync(revisedPath, 'utf8')
const sha = text => crypto.createHash('sha256').update(text).digest('hex')
const parse = (filename, source) => ts.createSourceFile(filename, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS)
const originalAst = parse(originalPath, original)
const revisedAst = parse(revisedPath, revised)
const printed = node => ts.createPrinter({ removeComments: true }).printNode(ts.EmitHint.Unspecified, node, node.getSourceFile())
function allNodes(ast, predicate) {
  const result = []
  const visit = node => { if (predicate(node)) result.push(node); ts.forEachChild(node, visit) }
  visit(ast)
  return result
}
function assertions(ast) {
  return allNodes(ast, node => ts.isCallExpression(node) && (node.expression.getText(ast).startsWith('assert.') || node.expression.getText(ast) === 'expect' || node.expression.getText(ast) === 'expect.poll' || /^to[A-Z]/.test(node.expression.name?.text ?? '')))
    .map(node => ({ line: ast.getLineAndCharacterOfPosition(node.getStart(ast)).line + 1, text: printed(node), start: node.getStart(ast) }))
}
const oldAssertions = assertions(originalAst)
const newAssertions = assertions(revisedAst)
const remaining = [...newAssertions]
const assertionComparison = oldAssertions.map(before => {
  const found = remaining.findIndex(after => after.text === before.text)
  const after = found >= 0 ? remaining.splice(found, 1)[0] : null
  return { originalLine: before.line, revisedLine: after?.line ?? null, preserved: !!after, assertion: before.text }
})
assert.ok(assertionComparison.every(row => row.preserved), 'An original product assertion was lost or changed')
const originalBoot = originalAst.statements.find(node => ts.isFunctionDeclaration(node) && node.name.text === 'boot')
const revisedBoot = revisedAst.statements.find(node => ts.isFunctionDeclaration(node) && node.name.text === 'boot')
const identityLoop = boot => boot.body.statements.find(node => ts.isForOfStatement(node) && node.expression.getText().includes('identity.home'))
const originalLoop = identityLoop(originalBoot)
const revisedLoop = identityLoop(revisedBoot)
assert.equal(originalLoop.expression.getText().replace('[identity.home, home]', '[identity.home, expectedNativeHome]'), revisedLoop.expression.getText())
const unchangedFunctions = originalAst.statements.filter(node => ts.isFunctionDeclaration(node) && !['boot', 'closeThroughUi'].includes(node.name.text)).map(before => {
  const after = revisedAst.statements.find(node => ts.isFunctionDeclaration(node) && node.name.text === before.name.text)
  assert.equal(after?.getText(), before.getText(), 'Unrelated helper changed: ' + before.name.text)
  return before.name.text
})
const oldTimeouts = allNodes(originalAst, node => (ts.isPropertyAssignment(node) && ['timeout', 'connectTimeoutMs', 'waitLimitMs'].includes(node.name.getText())) || (ts.isCallExpression(node) && /(?:setTimeout|AbortSignal\.timeout)$/.test(node.expression.getText()))).map(printed)
const newTimeouts = allNodes(revisedAst, node => (ts.isPropertyAssignment(node) && ['timeout', 'connectTimeoutMs', 'waitLimitMs'].includes(node.name.getText())) || (ts.isCallExpression(node) && /(?:setTimeout|AbortSignal\.timeout)$/.test(node.expression.getText()))).map(printed)
const counts = entries => entries.reduce((all, entry) => (all[entry] = (all[entry] ?? 0) + 1, all), {})
assert.deepEqual(counts(newTimeouts), counts(oldTimeouts), 'Existing timeout/wait values or counts changed')
assert.equal((revised.match(/localStorage\.setItem/g) ?? []).length, 0, 'Acceptance script must not prewrite migration preferences')
assert.ok(revised.includes("getByRole('dialog', { name: '从 v1.2.7 迁移', exact: true })"))
assert.ok(revised.includes("migrationDialog.getByRole('button', { name: '我不用 v1.2.7，不再提示', exact: true }).click()"))
assert.ok(revised.indexOf('lastVerifiedIdentity = identity') < revised.indexOf('page = await app.firstWindow'))
assert.ok(revised.indexOf('await saveReceipt()', revised.indexOf('receipt.observedIdentities.push')) < revised.indexOf('page = await app.firstWindow'))
assert.ok(revised.indexOf('const expectedNativeHome =') < revised.indexOf('const env ='))
assert.ok(revised.indexOf('const expectedNativeHome =') < revised.indexOf('Object.assign(env,'))

const result = {mode:'static AST comparison only; no app execution', v2Sha256:sha(original),v3Sha256:sha(revised),v2Assertions:oldAssertions.length,v3Assertions:newAssertions.length,allV2AssertionsPreserved:true,added:remaining.length,originalTimeoutEntries:oldTimeouts.length,revisedTimeoutEntries:newTimeouts.length,timeoutValuesAndCountsUnchanged:true,comparison:assertionComparison}; fs.writeFileSync(path.join(cache,'v3-v2-preservation.json'),JSON.stringify(result,null,2)+'\n'); console.log(JSON.stringify({passed:true,v2Assertions:result.v2Assertions,v3Assertions:result.v3Assertions,allPreserved:true,timeouts:oldTimeouts.length}));
