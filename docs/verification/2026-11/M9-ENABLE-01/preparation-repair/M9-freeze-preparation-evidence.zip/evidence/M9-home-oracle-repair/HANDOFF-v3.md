# v3 spawn environment preflight — root review

Proposed script: m9-packaged-acceptance.v3.cjs
SHA256: 98ca551098463324dcddace1a4952b4a7fd4a253604a5782588bbe058aca7eb1
V2 remains unchanged: 91b5003fb8881854472958150cd3d1c73ebfdb5b5cfb9792e46c5c2e38cf759f.

The pure assertSpawnIsolation helper runs and persists a preflight receipt immediately before every electron.launch. It checks all prepared explicit paths, valid sampled PORT and OPEN_BROWSER/HOMEDRIVE/HOMEPATH. TRAINER_* names must be exactly TRAINER_DATA_DIR and TRAINER_DB; extra runtime/control/manifest names and portable or node launch variables fail closed. Data/home/roaming/local/temp/profile paths must belong to the fresh package data root; TDX_ROOT must be the same package sample-market. It changes no environment values.

Bootstrap collects only exe/PID, verifies real OS exe and creation time, and saves the trusted process identity before firstWindow. Full identity, including sessionData and logs, is collected after the existing firstWindow/classic-tab/migration handling and guarded by app.isReady(). Paths are read unchanged. No ready wait, path override, product monkey-patch or new timeout is added.

Fresh receipts:
- v3-node-check.native-exit.txt = 0.
- v3-preparation-verification.json: 72 pure/static/read-only Node helper cases pass; wrong/missing explicit env and inherited forbidden variables reject. No packaged app/Electron application was launched.
- v3-assertion-comparison.json: all original 210 assertions remain, 38 added across v2/v3.
- v3-v2-preservation.json: all v2 235 assertions remain, v3 adds 13. Original 32 timeout values/counts remain unchanged.
- v3-from-v2.diff and v3-change-map.json show the four exact edits.

No repository/control files or wrapper expectations were modified. Root must review v3 before a fresh acceptance run. Static and pure tests do not establish production/package/visual/CMD/user acceptance.
