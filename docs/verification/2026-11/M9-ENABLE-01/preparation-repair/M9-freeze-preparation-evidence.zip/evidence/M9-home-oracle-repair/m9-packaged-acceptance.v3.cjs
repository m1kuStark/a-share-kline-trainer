// Cache-only, operator-run production Electron acceptance. No product hooks or API mutations.
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const net = require('node:net')
const crypto = require('node:crypto')
const zlib = require('node:zlib')
const { createRequire } = require('node:module')
const { execFileSync } = require('node:child_process')
const argv = process.argv.slice(2)
const options = Object.fromEntries(argv.reduce((rows, token, i) => token.startsWith('--') ? [...rows, [token.slice(2), argv[i + 1]]] : rows, []))
for (const name of ['package', 'repo', 'evidence', 'source-sha', 'exe-sha', 'asar-sha', 'code', 'start-date']) assert.ok(options[name] && !options[name].startsWith('--'), `Missing --${name}`)
for (const name of ['package', 'repo', 'evidence']) assert.ok(path.isAbsolute(options[name]), `--${name} must be absolute`)
assert.match(options['source-sha'], /^[a-f0-9]{40}$/i)
for (const name of ['exe-sha', 'asar-sha']) assert.match(options[name], /^[a-f0-9]{64}$/i)
assert.match(options.code, /^\d{6}$/)
assert.match(options['start-date'], /^\d{4}-\d{2}-\d{2}$/)
const packageRoot = path.resolve(options.package)
const repo = path.resolve(options.repo)
const evidence = path.resolve(options.evidence)
const data = path.join(packageRoot, '.acceptance-data')
const profile = path.join(data, 'profile')
const home = path.join(data, 'home')
const roaming = path.join(home, 'AppData', 'Roaming')
const local = path.join(home, 'AppData', 'Local')
const temp = path.join(local, 'Temp')
const market = path.join(packageRoot, 'sample-market')
const exe = path.join(packageRoot, 'app', 'K线训练器.exe')
const asar = path.join(packageRoot, 'app', 'resources', 'app.asar')
const digest = bytes => crypto.createHash('sha256').update(bytes).digest('hex')
const hashFile = file => digest(fs.readFileSync(file))
const samePath = (actual, expected) => path.resolve(actual).toLowerCase() === path.resolve(expected).toLowerCase()
const inside = (actual, parent) => path.resolve(actual).toLowerCase().startsWith(path.resolve(parent).toLowerCase() + path.sep)
// Capture Windows KnownFolder before constructing or overriding the child environment.
const expectedNativeHome = execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', "[Environment]::GetFolderPath('UserProfile')"], { encoding: 'utf8', windowsHide: true }).trim()
const expectedNativeHomeCapturedAt = new Date().toISOString()
assert.ok(path.isAbsolute(expectedNativeHome), 'Windows native UserProfile oracle must be absolute')
assert.ok(!inside(evidence, repo) && !samePath(evidence, repo), 'Evidence must stay outside the repository')
assert.ok(!fs.existsSync(data), 'Fresh extraction required: .acceptance-data already exists')
assert.ok(!fs.existsSync(path.join(evidence, 'acceptance-result.json')), 'Use a fresh evidence directory')
for (const entry of [exe, asar, market, path.join(packageRoot, 'Start-Acceptance.ps1'), path.join(packageRoot, 'Start-Acceptance.cmd')]) assert.ok(fs.existsSync(entry), `Incomplete acceptance extraction: ${entry}`)
assert.equal(hashFile(exe), options['exe-sha'].toLowerCase(), 'Executable identity')
assert.equal(hashFile(asar), options['asar-sha'].toLowerCase(), 'ASAR identity')
const sourceHead = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: repo, encoding: 'utf8' }).trim()
assert.equal(sourceHead, options['source-sha'].toLowerCase(), 'Source checkout must match declared build commit')
const sourcePackagePath = path.join(repo, 'package.json')
const sourcePackageSha256 = hashFile(sourcePackagePath)
const sourceVersion = JSON.parse(fs.readFileSync(sourcePackagePath, 'utf8')).version
assert.equal(typeof sourceVersion, 'string', 'Source package version must be a string')
assert.ok(sourceVersion.length > 0, 'Source package version must be nonempty')
const marketId = options.code.startsWith('6') ? 'sh' : options.code.startsWith('8') || options.code.startsWith('4') || options.code.startsWith('9') ? 'bj' : 'sz'
const dayFile = path.join(market, 'vipdoc', marketId, 'lday', `${marketId}${options.code}.day`)
assert.ok(fs.existsSync(dayFile), `Sample market lacks selected stock: ${dayFile}`)
const day = fs.readFileSync(dayFile)
assert.equal(day.length % 32, 0, 'TDX day record alignment')
const dates = Array.from({ length: day.length / 32 }, (_, i) => String(day.readUInt32LE(i * 32)))
const dateKey = options['start-date'].replaceAll('-', '')
const at = dates.indexOf(dateKey)
assert.ok(at >= 20 && dates.length - at >= 10, 'Selected date requires >=20 historical and >=10 following bars')
const req = createRequire(path.join(repo, 'package.json'))
const { _electron: electron, expect } = req('@playwright/test')
fs.mkdirSync(evidence, { recursive: true })
for (const folder of [data, profile, roaming, local, temp]) fs.mkdirSync(folder, { recursive: true })
const receipt = { startedAt: new Date().toISOString(), scriptSha256: hashFile(__filename), sourceCommit: sourceHead, packageRoot, evidence, data, profile, sampleMarket: { path: market, dayFile, sha256: hashFile(dayFile), bars: dates.length }, executableSha256: hashFile(exe), asarSha256: hashFile(asar), wrapperSha256: hashFile(path.join(packageRoot, 'Start-Acceptance.ps1')), launchRoute: 'Playwright electron.launch of packaged exe; isolation mirrors Start-Acceptance.ps1; this does not prove the CMD entry', stages: [], boots: [], pageErrors: [], unexpectedJsDialogs: [], writeApiRequests: [], passed: false, visualAcceptance: 'pending operator screenshot/window review', limitations: ['Production build has no journey chart hook. DOM canvas/pane changes and screenshots do not automatically prove formula curve correctness.', 'No installer, upgrade, macOS, remote release or user acceptance is claimed.'] }
let app, page, port, originalNamespace, trainingId, firstCanvasCount, subFormulaId, lastVerifiedIdentity
receipt.sourceVersion = sourceVersion
receipt.sourcePackageSha256 = sourcePackageSha256
receipt.builtinChecks = []
receipt.resizeChecks = []
receipt.visualFrames = []
receipt.nativeHomeOracle = { expectedNativeHome, capturedAt: expectedNativeHomeCapturedAt, command: "[Environment]::GetFolderPath('UserProfile')", environment: 'inherited operator environment, before child overrides' }
receipt.observedIdentities = []
receipt.migrationPromptChecks = []
const env = { ...process.env }
for (const key of Object.keys(env)) if (/^TRAINER_/i.test(key) || /^PORTABLE_EXECUTABLE/i.test(key) || ['NODE_OPTIONS', 'ELECTRON_RUN_AS_NODE', 'DESKTOP_DEV_URL', 'TDX_ROOT', 'TDX_DIR', 'PORT', 'HOST', 'OPEN_BROWSER'].includes(key.toUpperCase())) delete env[key]
async function availablePort() { const server = net.createServer(); await new Promise((yes, no) => { server.once('error', no); server.listen(0, '127.0.0.1', yes) }); const value = server.address().port; await new Promise((yes, no) => server.close(error => error ? no(error) : yes())); return value }
async function json(url) { const response = await page.request.get(new URL(url, `http://127.0.0.1:${port}`).href); assert.equal(response.status(), 200, `GET ${url}`); return response.json() }
async function saveReceipt() { fs.writeFileSync(path.join(evidence, 'acceptance-result.json'), JSON.stringify(receipt, null, 2) + '\n') }
async function snapshot(name) {
  await page.screenshot({ path: path.join(evidence, `${name}.png`), fullPage: false })
  fs.writeFileSync(path.join(evidence, `${name}.dom.txt`), await page.locator('body').innerText())
  const canvas = await page.locator('.chart-host canvas').evaluateAll(elements => elements.map(el => { const r = el.getBoundingClientRect(); return { width: el.width, height: el.height, x: r.x, y: r.y, renderedWidth: r.width, renderedHeight: r.height } }))
  receipt.stages.push({ name, at: new Date().toISOString(), canvas })
  const viewport = await page.evaluate(() => ({ width: window.innerWidth, height: window.innerHeight, devicePixelRatio: window.devicePixelRatio, bodyScrollWidth: document.body.scrollWidth, bodyScrollHeight: document.body.scrollHeight, theme: document.body.classList.contains('dark') ? 'dark' : 'light' }))
  let nativeWindow
  try { nativeWindow = await nativeWindowGeometry() } catch (error) { nativeWindow = { readError: String(error) } }
  Object.assign(receipt.stages.at(-1), { viewport, nativeWindow, screenshot: name + '.png' })
  await saveReceipt()
}
async function run(name, action) {
  console.log(`START ${name}`)
  await action()
  assert.deepEqual(receipt.unexpectedJsDialogs, [], 'Unexpected JavaScript dialog was dismissed and must be investigated')
  assert.deepEqual(receipt.pageErrors, [], 'Renderer page errors')
  console.log(`PASS ${name}`)
  await saveReceipt()
}
// BEGIN CACHE-ONLY ISOLATION ORACLES (pure path assertions; no application hooks).
function readProcessIdentity(pid) {
  assert.ok(Number.isSafeInteger(pid) && pid > 0, 'Observed product PID must be a positive safe integer')
  const command = `[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false); $m9ObservedProcess = Get-Process -Id ${pid} -ErrorAction Stop; [pscustomobject]@{ pid = $m9ObservedProcess.Id; exe = $m9ObservedProcess.Path; startedAt = $m9ObservedProcess.StartTime.ToUniversalTime().ToString('o') } | ConvertTo-Json -Compress`
  const observed = JSON.parse(execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', command], { encoding: 'utf8', windowsHide: true, timeout: 5000 }).trim())
  assert.equal(observed.pid, pid, 'OS process PID mismatch')
  assert.ok(path.isAbsolute(observed.exe), 'OS process executable path must be absolute')
  assert.ok(typeof observed.startedAt === 'string' && Number.isFinite(Date.parse(observed.startedAt)), 'OS process creation time missing or invalid')
  return observed
}
function assertAdditionalBootPaths(identity) {
  for (const [actual, expected, name] of [[identity.nodeHome, home, 'Node home'], [identity.sessionData, profile, 'Electron sessionData'], [identity.temp, temp, 'Electron temp'], [identity.logs, path.join(profile, 'logs'), 'Electron logs']]) assert.ok(samePath(actual, expected), `${name} isolation mismatch ${actual} != ${expected}`)
}
function assertStorageArtifact(actual, expected, name) {
  assert.ok(samePath(actual, expected), `${name} actual path mismatch ${actual} != ${expected}`)
  assert.ok(inside(actual, data), `${name} escaped isolated data directory`)
}
function inspectProductStorage(requireExitFiles) {
  const observed = {}
  for (const [name, file, required] of [['mainLog', path.join(data, 'logs', 'main.log'), true], ['operationLog', path.join(data, 'logs', 'operations.log'), requireExitFiles], ['windowState', path.join(data, 'window-state.json'), requireExitFiles]]) {
    if (!fs.existsSync(file)) {
      assert.equal(required, false, `${name} missing at expected product data path: ${file}`)
      observed[name] = { expected: file, exists: false }
      continue
    }
    const realPath = fs.realpathSync.native(file)
    assertStorageArtifact(realPath, file, name)
    const info = fs.statSync(file)
    assert.ok(info.isFile(), `${name} path must be a file`)
    observed[name] = { expected: file, exists: true, realPath, bytes: info.size, sha256: hashFile(file) }
  }
  return observed
}
// END CACHE-ONLY ISOLATION ORACLES.
// BEGIN CACHE-ONLY SPAWN ENVIRONMENT ORACLE.
function assertSpawnIsolation(spawnEnv) {
  assert.ok(Number.isInteger(port) && port > 0 && port <= 65535, 'Spawn port must be the valid sampled loopback port')
  assert.ok(samePath(data, path.join(packageRoot, '.acceptance-data')) && inside(data, packageRoot), 'Spawn data root must belong to the fresh package')
  assert.ok(inside(profile, data), 'Chromium profile must belong to the isolated data root')
  assert.ok(samePath(market, path.join(packageRoot, 'sample-market')) && inside(market, packageRoot), 'Spawn market root must be the fresh package sample-market')
  const expected = { TRAINER_DATA_DIR: data, TRAINER_DB: path.join(data, 'trainer.sqlite'), TDX_ROOT: market, USERPROFILE: home, HOME: home, APPDATA: roaming, LOCALAPPDATA: local, TEMP: temp, TMP: temp, PORT: String(port), OPEN_BROWSER: '0', HOMEDRIVE: path.parse(home).root.replace(/[\\/]$/, ''), HOMEPATH: home.slice(path.parse(home).root.length - 1) }
  for (const [name, value] of Object.entries(expected)) assert.equal(spawnEnv[name], value, `Spawn environment ${name} does not match the prepared isolation value`)
  for (const name of ['TRAINER_DATA_DIR', 'TRAINER_DB', 'USERPROFILE', 'HOME', 'APPDATA', 'LOCALAPPDATA', 'TEMP', 'TMP']) assert.ok(samePath(spawnEnv[name], data) || inside(spawnEnv[name], data), `Spawn environment ${name} escaped the isolated data root`)
  assert.ok(inside(spawnEnv.TDX_ROOT, packageRoot) && samePath(spawnEnv.TDX_ROOT, market), 'Spawn TDX root escaped the package sample-market')
  const trainerKeys = Object.keys(spawnEnv).filter(name => /^TRAINER_/i.test(name)).sort()
  assert.deepEqual(trainerKeys, ['TRAINER_DATA_DIR', 'TRAINER_DB'], 'Unexpected inherited TRAINER_* runtime/control/manifest variable')
  const forbidden = Object.keys(spawnEnv).filter(name => /^PORTABLE_EXECUTABLE/i.test(name) || ['NODE_OPTIONS', 'ELECTRON_RUN_AS_NODE', 'DESKTOP_DEV_URL', 'TDX_DIR', 'HOST'].includes(name.toUpperCase()))
  assert.deepEqual(forbidden, [], 'Unexpected inherited launch/runtime variable')
  return { expected, trainerKeys, forbidden, dataRoot: data, sampleMarket: market, sampledPort: port }
}
// END CACHE-ONLY SPAWN ENVIRONMENT ORACLE.
async function boot(label) {
  lastVerifiedIdentity = null
  assert.equal(hashFile(exe), receipt.executableSha256)
  assert.equal(hashFile(asar), receipt.asarSha256)
  const spawnPreflight = assertSpawnIsolation(env)
  receipt.spawnPreflightChecks ??= []
  receipt.spawnPreflightChecks.push({ label, checkedAt: new Date().toISOString(), ...spawnPreflight })
  await saveReceipt()
  app = await electron.launch({ executablePath: exe, args: [`--user-data-dir=${profile}`], env, cwd: packageRoot, timeout: 60000 })
  const child = app.process()
  child.stderr?.on('data', bytes => fs.appendFileSync(path.join(evidence, `${label}.stderr.log`), bytes))
  const identity = await app.evaluate(({ app }) => ({ exe: app.getPath('exe'), pid: process.pid }))
  assert.ok(Number.isSafeInteger(identity.pid) && identity.pid > 0, 'Observed product PID must be a positive safe integer')
  const observedProcess = readProcessIdentity(identity.pid)
  assert.ok(samePath(identity.exe, exe), 'Observed Electron executable identity mismatch')
  assert.ok(samePath(observedProcess.exe, exe), 'Observed OS process executable identity mismatch')
  identity.osProcess = observedProcess
  lastVerifiedIdentity = identity
  receipt.observedIdentities.push({ label, observedAt: new Date().toISOString(), launcherPid: child.pid, identity })
  await saveReceipt()
  page = await app.firstWindow({ timeout: 60000 })
  page.setDefaultTimeout(30000)
  page.on('pageerror', error => receipt.pageErrors.push({ boot: label, error: error.stack || error.message }))
  page.on('dialog', async dialog => { receipt.unexpectedJsDialogs.push({ boot: label, type: dialog.type(), message: dialog.message() }); await dialog.dismiss() })
  page.on('request', request => { if (new URL(request.url()).pathname.startsWith('/api/') && !['GET', 'HEAD', 'OPTIONS'].includes(request.method())) receipt.writeApiRequests.push({ method: request.method(), url: new URL(request.url()).pathname, initiator: 'real DOM application interaction' }) })
  await app.context().tracing.start({ screenshots: true, snapshots: true, sources: false })
  await expect(page.getByRole('tab', { name: '经典模式', exact: true })).toBeVisible({ timeout: 60000 })
  const migrationDialog = page.getByRole('dialog', { name: '从 v1.2.7 迁移', exact: true })
  const migrationCheck = { label, preferenceKey: 'mig-inline-dismissed', observedBefore: await page.evaluate(() => localStorage.getItem('mig-inline-dismissed')), action: null }
  receipt.migrationPromptChecks.push(migrationCheck)
  await saveReceipt()
  if (label === 'boot-one') {
    assert.equal(migrationCheck.observedBefore, null, 'Fresh profile must not pre-dismiss the migration prompt')
    await expect(migrationDialog).toBeVisible()
    await migrationDialog.getByRole('button', { name: '我不用 v1.2.7，不再提示', exact: true }).click()
    migrationCheck.action = 'real DOM click: 我不用 v1.2.7，不再提示'
    await expect(migrationDialog).toBeHidden()
  } else {
    assert.equal(migrationCheck.observedBefore, '1', 'Migration dismissal preference did not survive restart')
    await expect(migrationDialog).toBeHidden()
    migrationCheck.action = 'verified persisted dismissal; no DOM write or repeated click'
  }
  migrationCheck.observedAfter = await page.evaluate(() => localStorage.getItem('mig-inline-dismissed'))
  assert.equal(migrationCheck.observedAfter, '1', 'Real migration dismissal must persist its preference')
  migrationCheck.hidden = true
  await saveReceipt()
  const readyIdentity = await app.evaluate(({ app, BrowserWindow }) => {
    if (!app.isReady()) throw new Error('Electron app must be ready before observing sessionData/logs and other full identity paths')
    return { packaged: app.isPackaged, version: app.getVersion(), exe: app.getPath('exe'), userData: app.getPath('userData'), appData: app.getPath('appData'), home: app.getPath('home'), nodeHome: process.getBuiltinModule('node:os').homedir(), sessionData: app.getPath('sessionData'), temp: app.getPath('temp'), logs: app.getPath('logs'), pid: process.pid, windows: BrowserWindow.getAllWindows().map(w => ({ visible: w.isVisible(), minimized: w.isMinimized(), destroyed: w.isDestroyed(), title: w.getTitle() })) }
  })
  assert.equal(readyIdentity.pid, identity.osProcess.pid, 'Product PID changed between bootstrap and ready identity')
  assert.ok(samePath(readyIdentity.exe, identity.osProcess.exe), 'Product executable changed between bootstrap and ready identity')
  Object.assign(identity, readyIdentity)
  assert.equal(identity.packaged, true)
  for (const [actual, expected] of [[identity.exe, exe], [identity.userData, profile], [identity.appData, roaming], [identity.home, expectedNativeHome]]) assert.ok(samePath(actual, expected), `Isolation mismatch ${actual} != ${expected}`)
  assertAdditionalBootPaths(identity)
  assert.ok(identity.windows.some(w => w.visible && !w.minimized && !w.destroyed), 'No visible Electron window')
  lastVerifiedIdentity = identity
  assert.equal(identity.version, sourceVersion, 'Packaged app version differs from source package.json')
  assert.equal(hashFile(sourcePackagePath), receipt.sourcePackageSha256, 'Source package.json changed during acceptance')
  const statePath = path.join(data, 'trainer-state.json')
  await expect.poll(() => fs.existsSync(statePath)).toBe(true)
  const state = JSON.parse(fs.readFileSync(statePath, 'utf8'))
  assert.ok(samePath(state.databasePath, path.join(data, 'trainer.sqlite')), 'SQLite escaped extraction')
  assert.equal(state.pid, identity.pid)
  assert.equal(new URL(state.baseURL).hostname, '127.0.0.1')
  assert.equal(Number(new URL(state.baseURL).port), port)
  assert.equal(new URL(page.url()).origin, `http://127.0.0.1:${port}`)
  const health = await json('/api/health')
  assert.equal(health.status, 'ok'); assert.equal(health.runId, state.runId); assert.equal(health.pid, state.pid)
  const environment = await json('/api/env')
  assert.equal(environment.tdx.connected, true)
  if (originalNamespace) assert.equal(environment.recordingNamespace, originalNamespace, 'Recording namespace changed across restart')
  else originalNamespace = environment.recordingNamespace
  assert.ok(originalNamespace)
  receipt.boots.push({ label, identity, state, health, recordingNamespace: environment.recordingNamespace, storagePaths: inspectProductStorage(false) })
  await snapshot(label)
}
async function formulaSection() {
  await page.getByRole('button', { name: '训练默认设置', exact: true }).click()
  const dialog = page.getByRole('dialog', { name: '训练默认设置', exact: true })
  await expect(dialog).toBeVisible()
  await dialog.getByRole('button', { name: '公式指标', exact: true }).click()
  const section = dialog.getByRole('region', { name: '公式指标', exact: true })
  await expect(section).toBeVisible()
  await expect(section.locator('.formula-list-pane')).not.toContainText('读取中')
  await expect(section.getByLabel('公式列表', { exact: true })).toBeVisible()
  await expect(section.getByRole('button', { name: '新建', exact: true })).toBeEnabled()
  await expect(section.getByRole('alert')).toHaveCount(0)
  return { dialog, section }
}
async function formulaByName(name) { const payload = await json('/api/formulas'); const found = payload.formulas.find(f => f.name === name); assert.ok(found, `Formula ${name} was not persisted`); return found }
async function chooseAndToggle(name, enabled) {
  const { dialog, section } = await formulaSection()
  const item = section.locator('.formula-item').filter({ hasText: name })
  await expect(item).toHaveCount(1); await item.click()
  await section.getByRole('checkbox', { name: '在图表启用', exact: true }).setChecked(enabled)
  await section.getByRole('button', { name: '保存修改', exact: true }).click()
  await expect(section.locator('.settings-saved')).toContainText('已保存')
  await expect.poll(async () => (await formulaByName(name)).enabled).toBe(enabled)
  const chartRefreshRequest = await page.locator('.training-topbar').isVisible()
    ? page.waitForRequest(request => new URL(request.url()).pathname === '/api/formulas' && request.method() === 'GET')
    : null
  await dialog.getByRole('button', { name: '关闭', exact: true }).click()
  await expect(dialog).toBeHidden()
  if (chartRefreshRequest) {
    const response = await (await chartRefreshRequest).response()
    assert.ok(response, 'Closing formula settings must refresh the training formula library')
    assert.equal(response.status(), 200, 'Training formula refresh failed')
    await renderedFrames()
  }
}
async function createFormula(name, source, placement) {
  const { dialog, section } = await formulaSection()
  await section.getByRole('button', { name: '新建', exact: true }).click()
  await section.getByLabel('公式名称', { exact: true }).fill(name)
  await section.getByLabel('公式源码', { exact: true }).fill(source)
  await section.getByLabel('显示位置', { exact: true }).selectOption(placement)
  await section.getByLabel('在图表启用', { exact: true }).check()
  await section.getByRole('button', { name: '校验', exact: true }).click()
  await expect(section.locator('.formula-status')).toContainText('校验通过')
  await section.getByLabel('预览证券代码', { exact: true }).fill(options.code)
  await section.getByRole('button', { name: '预览', exact: true }).click()
  await expect(section.getByRole('img', { name: /公式预览曲线/ })).toBeVisible({ timeout: 60000 })
  await expect(section.locator('.formula-preview-svg polyline').first()).toHaveAttribute('points', /[0-9]/)
  await section.getByRole('button', { name: '保存新公式', exact: true }).click()
  await expect(section.locator('.settings-saved')).toContainText('已保存')
  const saved = await formulaByName(name); assert.equal(saved.enabled, true); assert.equal(saved.placement, placement)
  await snapshot(`formula-create-${placement}`)
  await dialog.getByRole('button', { name: '关闭', exact: true }).click()
  return saved
}
async function chartReady() { await expect(page.locator('.chart-host')).toBeVisible({ timeout: 60000 }); await expect.poll(() => page.locator('.chart-host canvas').count(), { timeout: 30000 }).toBeGreaterThan(0) }
async function renderedFrames() {
  await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))))
}
async function nativeWindowGeometry() {
  return app.evaluate(({ BrowserWindow }) => {
    const windows = BrowserWindow.getAllWindows().filter(window => !window.isDestroyed())
    if (windows.length !== 1) throw new Error('Expected exactly one live product BrowserWindow, found ' + windows.length)
    const window = windows[0]
    return { id: window.id, bounds: window.getBounds(), contentBounds: window.getContentBounds(), contentSize: window.getContentSize(), minimumSize: window.getMinimumSize(), maximized: window.isMaximized(), minimized: window.isMinimized(), fullscreen: window.isFullScreen(), zoomFactor: window.webContents.getZoomFactor() }
  })
}
async function resizeProductionWindow(width, height) {
  const requestedContentSize = { width, height }
  const attempt = { requestedContentSize, at: new Date().toISOString(), before: await nativeWindowGeometry(), matched: false }
  receipt.resizeChecks.push(attempt)
  await saveReceipt()
  try {
    await app.evaluate(({ BrowserWindow }) => {
      const windows = BrowserWindow.getAllWindows().filter(window => !window.isDestroyed())
      if (windows.length !== 1) throw new Error('Resize requires one live product BrowserWindow')
      const window = windows[0]
      if (window.isMinimized()) window.restore()
      if (window.isFullScreen()) window.setFullScreen(false)
      if (window.isMaximized()) window.unmaximize()
    })
    await expect.poll(async () => { const geometry = await nativeWindowGeometry(); return { maximized: geometry.maximized, minimized: geometry.minimized, fullscreen: geometry.fullscreen } }, { timeout: 10000 }).toEqual({ maximized: false, minimized: false, fullscreen: false })
    await app.evaluate(({ BrowserWindow }, size) => {
      const windows = BrowserWindow.getAllWindows().filter(window => !window.isDestroyed())
      if (windows.length !== 1) throw new Error('Resize requires one live product BrowserWindow')
      windows[0].setContentSize(size.width, size.height)
    }, requestedContentSize)
    await expect.poll(async () => { attempt.actualWindow = await nativeWindowGeometry(); return attempt.actualWindow.contentSize }, { timeout: 10000 }).toEqual([width, height])
    await expect.poll(async () => { attempt.actualViewport = await page.evaluate(() => ({ width: window.innerWidth, height: window.innerHeight })); return attempt.actualViewport }, { timeout: 10000 }).toEqual(requestedContentSize)
    assert.deepEqual(attempt.actualWindow.minimumSize, attempt.before.minimumSize, 'Window minimum constraints were changed')
    await chartReady()
    await renderedFrames()
    attempt.matched = true
  } finally {
    attempt.finishedAt = new Date().toISOString()
    await saveReceipt()
  }
}
async function selectThemeThroughDom(target) {
  assert.ok(['dark', 'light'].includes(target))
  const current = await page.locator('body').evaluate(body => body.classList.contains('dark') ? 'dark' : 'light')
  if (current === target) {
    const opposite = target === 'dark' ? 'light' : 'dark'
    await page.getByRole('button', { name: opposite === 'dark' ? '切换到深色主题' : '切换到浅色主题', exact: true }).click()
    await expect.poll(() => page.locator('body').evaluate(body => body.classList.contains('dark') ? 'dark' : 'light')).toBe(opposite)
  }
  await page.getByRole('button', { name: target === 'dark' ? '切换到深色主题' : '切换到浅色主题', exact: true }).click()
  await expect.poll(() => page.locator('body').evaluate(body => body.classList.contains('dark') ? 'dark' : 'light')).toBe(target)
  assert.equal(await page.evaluate(() => localStorage.getItem('trainer_theme')), target, 'Theme DOM interaction was not persisted')
  await renderedFrames()
}
const builtinPresets = Object.freeze([
  { name: 'MA_BULL_MAIN', placement: 'main', lineCount: 4 },
  { name: 'WEEK_MACD_SUB', placement: 'sub', lineCount: 3 },
  { name: 'QINIU_B1_SUB', placement: 'sub', lineCount: 3 },
])
function assertBuiltinState(actual, preset, enabled, initial) {
  assert.equal(actual.name, preset.name, 'Builtin name differs from fixed preset')
  assert.equal(actual.builtin, true, 'Builtin flag lost')
  assert.equal(actual.placement, preset.placement, 'Builtin placement differs from approved fixed preset')
  assert.equal(actual.enabled, enabled, 'Builtin enabled state was not persisted')
  if (initial) { assert.equal(actual.id, initial.id); assert.equal(actual.source, initial.source, 'Builtin source changed during enable/disable') }
}
async function exercisePackagedBuiltin(preset) {
  const initial = await formulaByName(preset.name)
  assertBuiltinState(initial, preset, false)
  const check = { preset, initial, scope: preset.placement === 'main' ? 'Real UI plus fixed API state and chart screenshots; root must judge the main curve' : 'Real UI plus fixed API state, added/removed canvas and chart screenshots; no formula numeric correctness claim' }
  receipt.builtinChecks.push(check)
  const baselineCanvases = await page.locator('.chart-host canvas').count()
  await chooseAndToggle(preset.name, true)
  check.enabled = await formulaByName(preset.name)
  assertBuiltinState(check.enabled, preset, true, initial)
  if (preset.placement === 'sub') await expect.poll(() => page.locator('.chart-host canvas').count(), { timeout: 30000 }).toBeGreaterThan(baselineCanvases)
  await chartReady()
  await renderedFrames()
  await snapshot('builtin-' + preset.name + '-enabled-chart')
  check.enabledSnapshot = receipt.stages.at(-1)
  await chooseAndToggle(preset.name, false)
  check.disabled = await formulaByName(preset.name)
  assertBuiltinState(check.disabled, preset, false, initial)
  if (preset.placement === 'sub') await expect.poll(() => page.locator('.chart-host canvas').count(), { timeout: 30000 }).toBe(baselineCanvases)
  await renderedFrames()
  await snapshot('builtin-' + preset.name + '-disabled-chart')
  check.disabledSnapshot = receipt.stages.at(-1)
  check.visualAcceptance = 'pending root screenshot review'
  await saveReceipt()
}
async function captureProductionVisualMatrix() {
  const initialViewport = await page.evaluate(() => ({ width: window.innerWidth, height: window.innerHeight }))
  const initialTheme = await page.locator('body').evaluate(body => body.classList.contains('dark') ? 'dark' : 'light')
  for (const preset of builtinPresets) { await chooseAndToggle(preset.name, true); assertBuiltinState(await formulaByName(preset.name), preset, true) }
  for (const size of [{ width: 1440, height: 900 }, { width: 1366, height: 768 }, { width: 1024, height: 768 }]) {
    await resizeProductionWindow(size.width, size.height)
    for (const target of ['dark', 'light']) {
      await selectThemeThroughDom(target)
      await chartReady()
      const name = 'training-all-builtins-' + size.width + 'x' + size.height + '-' + target
      await snapshot(name)
      const frame = receipt.stages.at(-1)
      assert.deepEqual({ width: frame.viewport.width, height: frame.viewport.height }, size, 'Screenshot viewport differs from requested content size')
      assert.equal(frame.viewport.theme, target, 'Screenshot theme differs from requested theme')
      assert.deepEqual(frame.nativeWindow.contentSize, [size.width, size.height], 'Screenshot native content size differs from request')
      receipt.visualFrames.push({ name, requestedContentSize: size, theme: target, actualViewport: frame.viewport, actualWindow: frame.nativeWindow, screenshot: frame.screenshot, review: 'pending root screenshot review' })
      await saveReceipt()
    }
  }
  await selectThemeThroughDom(initialTheme)
  await resizeProductionWindow(initialViewport.width, initialViewport.height)
  for (const preset of builtinPresets) { await chooseAndToggle(preset.name, false); assertBuiltinState(await formulaByName(preset.name), preset, false) }
  await expect.poll(() => page.locator('.chart-host canvas').count(), { timeout: 30000 }).toBe(firstCanvasCount)
  await snapshot('visual-matrix-restored-training-baseline')
}

async function openLibraryAndReplay(label) {
  await page.getByRole('button', { name: '训练录像', exact: true }).click()
  await expect(page.getByRole('heading', { name: '训练录像', exact: true })).toBeVisible()
  const localItems = page.locator('[data-recording-source="local"] .recording-history-item')
  await expect(localItems).toHaveCount(1, { timeout: 60000 })
  const text = await localItems.first().innerText()
  if (receipt.recordingLibraryText) assert.equal(text, receipt.recordingLibraryText, 'Saved recording row changed across restart')
  else receipt.recordingLibraryText = text
  await localItems.first().locator('.recording-history-open').click()
  await expect(page.getByRole('button', { name: '关闭回放', exact: true })).toBeVisible()
  await chartReady()
  await expect(page.locator('.replay-chart-empty')).toHaveCount(0)
  await snapshot(`${label}-replay-first`)
  const next = page.getByRole('button', { name: '下一日', exact: true })
  await expect(next).toBeEnabled()
  const before = await page.locator('.replay-day').innerText()
  await next.click()
  await expect(page.locator('.replay-day')).not.toHaveText(before)
  await page.getByRole('button', { name: '回到第一天', exact: true }).click()
  await page.getByRole('button', { name: '播放录制', exact: true }).click()
  await expect(page.locator('.replay-day')).not.toHaveText(before, { timeout: 15000 })
  const pause = page.getByRole('button', { name: '暂停回放', exact: true })
  if (await pause.isVisible()) await pause.click()
  await snapshot(`${label}-replay-progress`)
  await page.getByRole('button', { name: '关闭回放', exact: true }).click()
  await page.getByRole('button', { name: '返回训练', exact: true }).click()
}
async function closeThroughUi(label) {
  const child = app.process()
  const exited = new Promise((yes, no) => { const timer = setTimeout(() => no(new Error('Electron did not exit within 40s')), 40000); child.once('exit', (code, signal) => { clearTimeout(timer); yes({ code, signal }) }) })
  exited.catch(() => {})
  await page.getByRole('button', { name: '保存并退出训练器', exact: true }).click()
  const dialog = page.getByRole('dialog', { name: '退出训练器', exact: true })
  await expect(dialog).toBeVisible()
  await dialog.getByRole('button', { name: '保存并退出', exact: true }).click()
  await expect(page.getByText('训练器已退出', { exact: true })).toBeVisible({ timeout: 30000 })
  await app.context().tracing.stop({ path: path.join(evidence, `${label}.trace.zip`) })
  await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows()[0].close())
  const exit = await exited
  assert.equal(exit.code, 0); assert.equal(exit.signal, null)
  receipt.boots.at(-1).exit = exit
  app = null
  await assert.rejects(fetch(`http://127.0.0.1:${port}/api/health`, { signal: AbortSignal.timeout(2000) }), 'Owned service still responds after exit')
  assert.ok(fs.existsSync(path.join(profile, 'Local State')), 'Isolated Chromium profile missing')
  receipt.boots.at(-1).closedStoragePaths = inspectProductStorage(true)
  await saveReceipt()
}
;(async () => {
  try {
    port = await availablePort()
    fs.writeFileSync(path.join(data, 'port.txt'), String(port))
    Object.assign(env, { TRAINER_DATA_DIR: data, TRAINER_DB: path.join(data, 'trainer.sqlite'), TDX_ROOT: market, PORT: String(port), OPEN_BROWSER: '0', USERPROFILE: home, HOME: home, HOMEDRIVE: path.parse(home).root.replace(/[\\/]$/, ''), HOMEPATH: home.slice(path.parse(home).root.length - 1), APPDATA: roaming, LOCALAPPDATA: local, TEMP: temp, TMP: temp })
    receipt.port = port
    await run('boot-isolation', () => boot('boot-one'))
    await run('builtin-defaults-and-real-toggle', async () => {
      const { dialog, section } = await formulaSection()
      const list = section.getByLabel('公式列表', { exact: true })
      await expect(list).toContainText('MA_BULL_MAIN')
      await list.locator('.formula-item').filter({ hasText: 'MA_BULL_MAIN' }).click()
      await expect(section.getByLabel('在图表启用', { exact: true })).not.toBeChecked()
      await expect(section.getByLabel('公式名称', { exact: true })).toBeDisabled()
      await expect(section.getByLabel('公式源码', { exact: true })).toBeDisabled()
      await expect(section.getByRole('button', { name: '删除', exact: true })).toHaveCount(0)
      await snapshot('builtin-disabled-default')
      await dialog.getByRole('button', { name: '关闭', exact: true }).click()
      await chooseAndToggle('MA_BULL_MAIN', true)
      await chooseAndToggle('MA_BULL_MAIN', false)
    })
    await run('create-and-preview-through-dom', async () => { await createFormula('M9_ACCEPT_MAIN', 'ACCEPTMA:MA(CLOSE,5);', 'main'); subFormulaId = (await createFormula('M9_ACCEPT_SUB', 'SUB5:MA(CLOSE,5);\nSUB10:MA(CLOSE,10);', 'sub')).id })
    await run('start-training-and-recording', async () => {
      await page.getByRole('tab', { name: '经典模式', exact: true }).click()
      await page.getByLabel('股票代码', { exact: true }).fill(options.code)
      const suggestion = page.locator('.suggestions button').filter({ hasText: options.code }).first()
      await expect(suggestion).toBeVisible(); await suggestion.click()
      await page.locator('.launcher-form input[type="date"]').first().fill(options['start-date'])
      await page.getByRole('button', { name: '开始训练', exact: true }).click()
      const guard = page.getByRole('dialog', { name: '建议先更新日线数据', exact: true })
      await expect(guard.or(page.locator('.training-topbar'))).toBeVisible({ timeout: 60000 })
      if (await guard.isVisible()) { await snapshot('freshness-confirmation'); await guard.getByRole('button', { name: '仍要开始训练', exact: true }).click() }
      await expect(page.locator('.training-topbar')).toBeVisible({ timeout: 60000 })
      await expect(page.getByRole('status').filter({ hasText: '正在记录' })).toBeVisible({ timeout: 60000 })
      await chartReady()
      await expect(page.locator('.drawing-save-status')).toHaveText('已保存')
      const active = await json('/api/trainings/active'); trainingId = active.training.id
      firstCanvasCount = await page.locator('.chart-host canvas').count()
      await snapshot('training-formulas-on')
    })
    await run('builtin-real-training-presets-and-scenes', async () => {
      for (const preset of builtinPresets) await exercisePackagedBuiltin(preset)
      await expect.poll(() => page.locator('.chart-host canvas').count(), { timeout: 30000 }).toBe(firstCanvasCount)
    })
    await run('production-window-themes-and-sizes', () => captureProductionVisualMatrix())
    await run('formula-off-on-scene-change', async () => {
      await chooseAndToggle('M9_ACCEPT_SUB', false)
      await expect.poll(() => page.locator('.chart-host canvas').count(), { timeout: 30000 }).toBeLessThan(firstCanvasCount)
      await snapshot('training-subformula-off')
      await chooseAndToggle('M9_ACCEPT_SUB', true)
      await expect.poll(() => page.locator('.chart-host canvas').count(), { timeout: 30000 }).toBe(firstCanvasCount)
      await snapshot('training-subformula-on')
      await page.getByRole('tab', { name: '周K', exact: true }).click()
      await expect(page.getByRole('button', { name: '刷新图表', exact: true })).toBeEnabled()
      await snapshot('training-weekly')
      const monthlyBarsResponse = page.waitForResponse(response => { const url = new URL(response.url()); return response.request().method() === 'GET' && url.pathname === '/api/trainings/' + trainingId + '/bars' && url.searchParams.get('tf') === '1M' })
      await page.getByRole('tab', { name: '月K', exact: true }).click()
      assert.equal((await monthlyBarsResponse).status(), 200, 'Monthly bars load failed')
      await expect(page.getByRole('tab', { name: '月K', exact: true })).toHaveAttribute('aria-selected', 'true')
      await expect(page.getByRole('button', { name: '刷新图表', exact: true })).toBeEnabled()
      await chartReady()
      await renderedFrames()
      await snapshot('training-monthly')
      const dailyBarsResponse = page.waitForResponse(response => { const url = new URL(response.url()); return response.request().method() === 'GET' && url.pathname === '/api/trainings/' + trainingId + '/bars' && url.searchParams.get('tf') === '1D' })
      await page.getByRole('tab', { name: '日K', exact: true }).click()
      assert.equal((await dailyBarsResponse).status(), 200, 'Daily bars restore failed')
      await expect(page.getByRole('tab', { name: '日K', exact: true })).toHaveAttribute('aria-selected', 'true')
      await expect(page.getByRole('button', { name: '刷新图表', exact: true })).toBeEnabled()
      await renderedFrames()
    })
    await run('trade-advance-and-export-recording', async () => {
      await page.getByRole('button', { name: '买入', exact: true }).click()
      await expect(page.locator('.status-message')).toContainText('成交')
      for (let i = 0; i < 3; i++) { const before = await page.locator('.training-current-date').innerText(); await page.getByRole('button', { name: '推进下一日', exact: true }).click(); await expect(page.locator('.training-current-date')).not.toHaveText(before); await expect(page.getByRole('button', { name: '刷新图表', exact: true })).toBeEnabled() }
      await snapshot('training-after-advance')
      const pending = page.waitForEvent('download')
      await page.getByRole('button', { name: '导出录制', exact: true }).click()
      const download = await pending
      const output = path.join(evidence, 'actual-ui-recording.json.gz')
      await download.saveAs(output)
      const bytes = fs.readFileSync(output); assert.deepEqual([...bytes.subarray(0, 2)], [31, 139])
      const recording = JSON.parse(zlib.gunzipSync(bytes).toString('utf8'))
      assert.equal(recording.format, 'trainer-session'); assert.deepEqual(recording.gaps, [])
      assert.ok(recording.checkpoints.length > 0)
      assert.ok(recording.events.some(e => e.action === 'training.trade' && e.outcome === 'accepted'))
      if (recording.app.gitCommit !== 'unknown') assert.equal(recording.app.gitCommit, receipt.sourceCommit)
      receipt.recording = { output, sha256: hashFile(output), sessionId: recording.sessionId, app: recording.app, eventCount: recording.events.length, checkpointCount: recording.checkpoints.length, gaps: recording.gaps }
    })
    await run('settle-preserve-and-replay', async () => {
      await page.getByRole('button', { name: '提前结算', exact: true }).click()
      const end = page.getByRole('dialog', { name: '结束训练', exact: true })
      await expect(end).toBeVisible(); await expect(end.getByLabel('保留到本机训练历史', { exact: true })).toBeChecked()
      await snapshot('settlement-confirmation')
      await end.getByRole('button', { name: '确认结算', exact: true }).click()
      const results = page.getByRole('dialog', { name: '训练结算', exact: true })
      await expect(results).toBeVisible(); await expect(results.getByLabel('保留到本机训练历史', { exact: true })).toBeChecked()
      await results.getByRole('button', { name: '完成，返回首页', exact: true }).click()
      await openLibraryAndReplay('first-boot')
    })
    await run('exit-and-restart-same-origin', async () => {
      const beforeRunId = receipt.boots[0].state.runId
      await closeThroughUi('first-exit')
      assert.equal(Number(fs.readFileSync(path.join(data, 'port.txt'), 'utf8')), port)
      await boot('boot-two')
      assert.notEqual(receipt.boots[1].state.runId, beforeRunId)
      assert.equal((await formulaByName('M9_ACCEPT_SUB')).id, subFormulaId)
      assert.equal((await formulaByName('M9_ACCEPT_SUB')).enabled, true)
      const { dialog, section } = await formulaSection()
      await section.locator('.formula-item').filter({ hasText: 'M9_ACCEPT_SUB' }).click()
      await expect(section.getByLabel('在图表启用', { exact: true })).toBeChecked()
      await snapshot('restart-persisted-formula')
      await dialog.getByRole('button', { name: '关闭', exact: true }).click()
      await openLibraryAndReplay('second-boot')
      await closeThroughUi('second-exit')
    })
    receipt.trainingId = trainingId
    receipt.passed = true
    receipt.finishedAt = new Date().toISOString()
    console.log(JSON.stringify({ passed: true, sourceCommit: receipt.sourceCommit, trainingId, boots: receipt.boots.length, evidence }))
  } catch (error) {
    receipt.failure = error.stack || String(error)
    console.error(receipt.failure)
    if (page && !page.isClosed()) { try { await snapshot('failure') } catch {} }
    if (app) {
      const child = app.process()
      const ownedPid = lastVerifiedIdentity?.pid
      receipt.failureCleanup = { launcherPid: child.pid, verifiedProductPid: ownedPid, errors: [], forced: false }
      try { await app.context().tracing.stop({ path: path.join(evidence, 'failure.trace.zip') }) } catch (traceError) { receipt.failureCleanup.errors.push(String(traceError)) }
      let timer
      try { await Promise.race([app.close(), new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('Cleanup app.close timed out after 15s')), 15000) })]) }
      catch (closeError) { receipt.failureCleanup.errors.push(String(closeError)) }
      finally { clearTimeout(timer) }
      let productAlive = false
      if (Number.isSafeInteger(ownedPid)) { try { process.kill(ownedPid, 0); productAlive = true } catch (probeError) { if (probeError.code !== 'ESRCH') receipt.failureCleanup.errors.push(String(probeError)) } }
      if (productAlive) {
        try {
          const actualProcess = readProcessIdentity(ownedPid)
          const actualExe = actualProcess.exe
          assert.ok(samePath(actualExe, exe), 'Cleanup PID executable identity changed')
          assert.equal(actualProcess.startedAt, lastVerifiedIdentity.osProcess.startedAt, 'Cleanup PID creation time changed; refusing to kill a reused PID')
          receipt.failureCleanup.verifiedExecutable = actualExe
          receipt.failureCleanup.verifiedProcessStartedAt = actualProcess.startedAt
          receipt.failureCleanup.taskkill = execFileSync('taskkill.exe', ['/PID', String(ownedPid), '/T', '/F'], { encoding: 'utf8', windowsHide: true, timeout: 20000 })
          receipt.failureCleanup.forced = true
        } catch (killError) { receipt.failureCleanup.errors.push(String(killError)) }
      }
      receipt.failureCleanup.productProcessGone = null
      if (Number.isSafeInteger(ownedPid)) {
        const exitDeadline = Date.now() + 10000
        while (true) {
          try { process.kill(ownedPid, 0); receipt.failureCleanup.productProcessGone = false }
          catch (probeError) {
            if (probeError.code === 'ESRCH') receipt.failureCleanup.productProcessGone = true
            else { receipt.failureCleanup.productProcessGone = null; receipt.failureCleanup.errors.push(`Cleanup product PID verification failed: ${String(probeError)}`) }
            break
          }
          if (Date.now() >= exitDeadline) break
          await new Promise(resolve => setTimeout(resolve, 250))
        }
        if (receipt.failureCleanup.productProcessGone === false) receipt.failureCleanup.errors.push('Cleanup verified product PID still exists after 10s')
      } else receipt.failureCleanup.errors.push('Cleanup has no verified product PID to check for disappearance')
      try { await fetch(`http://127.0.0.1:${port}/api/health`, { signal: AbortSignal.timeout(2000) }); receipt.failureCleanup.portStillResponds = true }
      catch { receipt.failureCleanup.portStillResponds = false }
      receipt.failureCleanup.tcpPortReleased = null
      if (Number.isInteger(port) && port > 0 && port <= 65535) {
        const probeTcp = () => new Promise(resolve => {
          const socket = net.createConnection({ host: '127.0.0.1', port })
          let settled = false
          const finish = (status, error = null) => { if (settled) return; settled = true; socket.destroy(); resolve({ status, error }) }
          socket.setTimeout(750)
          socket.once('connect', () => finish('open'))
          socket.once('timeout', () => finish('unknown', 'TCP connect timed out after 750ms'))
          socket.once('error', error => finish(error.code === 'ECONNREFUSED' ? 'closed' : 'unknown', String(error)))
        })
        const tcpDeadline = Date.now() + 10000
        let attempts = 0
        let tcpResult
        do {
          tcpResult = await probeTcp(); attempts++
          if (tcpResult.status !== 'open' || Date.now() >= tcpDeadline) break
          await new Promise(resolve => setTimeout(resolve, 250))
        } while (true)
        receipt.failureCleanup.tcpProbe = { host: '127.0.0.1', port, attempts, connectTimeoutMs: 750, waitLimitMs: 10000, ...tcpResult }
        receipt.failureCleanup.tcpPortReleased = tcpResult.status === 'closed' ? true : tcpResult.status === 'open' ? false : null
        if (tcpResult.status === 'open') receipt.failureCleanup.errors.push('Cleanup loopback port still accepts TCP connections after 10s')
        if (tcpResult.status === 'unknown') receipt.failureCleanup.errors.push(`Cleanup TCP port release could not be verified: ${tcpResult.error}`)
      } else receipt.failureCleanup.errors.push('Cleanup has no valid owned loopback port to probe')
      receipt.failureCleanup.launcherExitCode = child.exitCode
      receipt.failureCleanup.launcherSignalCode = child.signalCode
    }
    process.exitCode = 1
  } finally { await saveReceipt() }
})()
