const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const vm = require('node:vm')
const crypto = require('node:crypto')
const { execFileSync, spawnSync } = require('node:child_process')
const { createRequire } = require('node:module')
const cache = __dirname
const originalPath = path.join(cache, 'm9-packaged-acceptance.original.cjs')
const revisedPath = path.join(cache, 'm9-packaged-acceptance.v2.cjs')
const req = createRequire('C:/Users/Stark_Du666/.codex/worktrees/m9-enable-01/a-share-kline-trainer/package.json')
const ts = req('typescript')
const original = fs.readFileSync(originalPath, 'utf8')
const revised = fs.readFileSync(revisedPath, 'utf8')
const sha = text => crypto.createHash('sha256').update(text).digest('hex')
const parse = (filename, source) => ts.createSourceFile(filename, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS)
const originalAst = parse(originalPath, original)
const revisedAst = parse(revisedPath, revised)
const printed = node => ts.createPrinter({ removeComments: true }).printNode(ts.EmitHint.Unspecified, node, node.getSourceFile())
function allNodes(ast, predicate) {
  const result = []
  const visit = node => { if (predicate(node)) result.push(node); ts.forEachChild(node, visit) }
  visit(ast)
  return result
}
function assertions(ast) {
  return allNodes(ast, node => ts.isCallExpression(node) && (node.expression.getText(ast).startsWith('assert.') || node.expression.getText(ast) === 'expect' || node.expression.getText(ast) === 'expect.poll' || /^to[A-Z]/.test(node.expression.name?.text ?? '')))
    .map(node => ({ line: ast.getLineAndCharacterOfPosition(node.getStart(ast)).line + 1, text: printed(node), start: node.getStart(ast) }))
}
const oldAssertions = assertions(originalAst)
const newAssertions = assertions(revisedAst)
const remaining = [...newAssertions]
const assertionComparison = oldAssertions.map(before => {
  const found = remaining.findIndex(after => after.text === before.text)
  const after = found >= 0 ? remaining.splice(found, 1)[0] : null
  return { originalLine: before.line, revisedLine: after?.line ?? null, preserved: !!after, assertion: before.text }
})
assert.ok(assertionComparison.every(row => row.preserved), 'An original product assertion was lost or changed')
const originalBoot = originalAst.statements.find(node => ts.isFunctionDeclaration(node) && node.name.text === 'boot')
const revisedBoot = revisedAst.statements.find(node => ts.isFunctionDeclaration(node) && node.name.text === 'boot')
const identityLoop = boot => boot.body.statements.find(node => ts.isForOfStatement(node) && node.expression.getText().includes('identity.home'))
const originalLoop = identityLoop(originalBoot)
const revisedLoop = identityLoop(revisedBoot)
assert.equal(originalLoop.expression.getText().replace('[identity.home, home]', '[identity.home, expectedNativeHome]'), revisedLoop.expression.getText())
const unchangedFunctions = originalAst.statements.filter(node => ts.isFunctionDeclaration(node) && !['boot', 'closeThroughUi'].includes(node.name.text)).map(before => {
  const after = revisedAst.statements.find(node => ts.isFunctionDeclaration(node) && node.name.text === before.name.text)
  assert.equal(after?.getText(), before.getText(), 'Unrelated helper changed: ' + before.name.text)
  return before.name.text
})
const oldTimeouts = allNodes(originalAst, node => (ts.isPropertyAssignment(node) && ['timeout', 'connectTimeoutMs', 'waitLimitMs'].includes(node.name.getText())) || (ts.isCallExpression(node) && /(?:setTimeout|AbortSignal\.timeout)$/.test(node.expression.getText()))).map(printed)
const newTimeouts = allNodes(revisedAst, node => (ts.isPropertyAssignment(node) && ['timeout', 'connectTimeoutMs', 'waitLimitMs'].includes(node.name.getText())) || (ts.isCallExpression(node) && /(?:setTimeout|AbortSignal\.timeout)$/.test(node.expression.getText()))).map(printed)
const counts = entries => entries.reduce((all, entry) => (all[entry] = (all[entry] ?? 0) + 1, all), {})
assert.deepEqual(counts(newTimeouts), counts(oldTimeouts), 'Existing timeout/wait values or counts changed')
assert.equal((revised.match(/localStorage\.setItem/g) ?? []).length, 0, 'Acceptance script must not prewrite migration preferences')
assert.ok(revised.includes("getByRole('dialog', { name: '从 v1.2.7 迁移', exact: true })"))
assert.ok(revised.includes("migrationDialog.getByRole('button', { name: '我不用 v1.2.7，不再提示', exact: true }).click()"))
assert.ok(revised.indexOf('lastVerifiedIdentity = identity') < revised.indexOf('page = await app.firstWindow'))
assert.ok(revised.indexOf('await saveReceipt()', revised.indexOf('receipt.observedIdentities.push')) < revised.indexOf('page = await app.firstWindow'))
assert.ok(revised.indexOf('const expectedNativeHome =') < revised.indexOf('const env ='))
assert.ok(revised.indexOf('const expectedNativeHome =') < revised.indexOf('Object.assign(env,'))
const scenarios = []
const expectedNativeHome = execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', "[Environment]::GetFolderPath('UserProfile')"], { encoding: 'utf8', windowsHide: true }).trim()
const data = path.join(cache, 'pure-fixture', '.acceptance-data')
const profile = path.join(data, 'profile')
const home = path.join(data, 'home')
const roaming = path.join(home, 'AppData', 'Roaming')
const temp = path.join(home, 'AppData', 'Local', 'Temp')
const exe = path.join(cache, 'pure-fixture', 'app', 'K线训练器.exe')
const samePath = (actual, expected) => path.resolve(actual).toLowerCase() === path.resolve(expected).toLowerCase()
const inside = (actual, parent) => path.resolve(actual).toLowerCase().startsWith(path.resolve(parent).toLowerCase() + path.sep)
const fixtureIdentity = { exe, userData: profile, appData: roaming, home: expectedNativeHome, nodeHome: home, sessionData: profile, temp, logs: path.join(profile, 'logs'), pid: 4242 }
const functions = revised.slice(revised.indexOf('// BEGIN CACHE-ONLY ISOLATION ORACLES'), revised.indexOf('// END CACHE-ONLY ISOLATION ORACLES'))
const ctx = vm.createContext({ assert, path, samePath, inside, data, profile, home, roaming, temp, exe, expectedNativeHome, execFileSync, fs, hashFile: file => sha(fs.readFileSync(file)) })
vm.runInContext(functions, ctx)
function check(name, action, shouldPass) {
  let error = null
  try { action() } catch (caught) { error = caught }
  assert.equal(error === null, shouldPass, name + ': ' + (error?.stack ?? 'unexpected pass'))
  scenarios.push({ name, expected: shouldPass ? 'pass' : 'reject', actual: error ? 'reject' : 'pass', error: error ? String(error) : null })
}
function runIdentity(identity, loop) {
  ctx.identity = identity
  vm.runInContext(loop.getText(), ctx)
  if (loop === revisedLoop) vm.runInContext('assertAdditionalBootPaths(identity)', ctx)
}
check('original oracle rejects valid native-home/isolated-Node split', () => runIdentity({ ...fixtureIdentity }, originalLoop), false)
check('v2 accepts valid native-home/isolated-Node split', () => runIdentity({ ...fixtureIdentity }, revisedLoop), true)
for (const field of ['exe', 'userData', 'appData', 'home', 'nodeHome', 'sessionData', 'temp', 'logs']) {
  check('v2 rejects path drift: ' + field, () => runIdentity({ ...fixtureIdentity, [field]: path.join(cache, 'wrong', field) }, revisedLoop), false)
}
for (const name of ['mainLog', 'operationLog', 'windowState']) {
  const file = name === 'windowState' ? path.join(data, 'window-state.json') : path.join(data, 'logs', name === 'mainLog' ? 'main.log' : 'operations.log')
  check('v2 accepts exact physical ' + name + ' path', () => ctx.assertStorageArtifact(file, file, name), true)
  check('v2 rejects escaped physical ' + name + ' path', () => ctx.assertStorageArtifact(path.join(cache, 'outside', path.basename(file)), file, name), false)
  check('v2 rejects wrong in-data ' + name + ' path', () => ctx.assertStorageArtifact(path.join(data, 'unexpected', path.basename(file)), file, name), false)
}
const validProcess = ctx.readProcessIdentity(process.pid)
assert.equal(validProcess.pid, process.pid)
assert.ok(samePath(validProcess.exe, process.execPath))
scenarios.push({ name: 'OS process identity helper reads this Node verifier PID/path/creation time', expected: 'pass', actual: 'pass', processIdentity: validProcess })
for (const pid of [0, -1, 1.5, Number.MAX_SAFE_INTEGER + 1, '4242']) check('reject unsafe PID ' + String(pid), () => ctx.readProcessIdentity(pid), false)
const childEnv = { ...process.env, USERPROFILE: home, HOME: home, TEMP: temp, TMP: temp }
const nodeHome = execFileSync(process.execPath, ['-p', "process.getBuiltinModule('node:os').homedir()"], { encoding: 'utf8', env: childEnv, windowsHide: true }).trim()
assert.ok(samePath(nodeHome, home))
const nativeHomeWithOverride = execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', "[Environment]::GetFolderPath('UserProfile')"], { encoding: 'utf8', env: childEnv, windowsHide: true }).trim()
assert.ok(samePath(nativeHomeWithOverride, expectedNativeHome))
scenarios.push({ name: 'child env override redirects Node home but preserves native KnownFolder', expected: 'pass', actual: 'pass', nodeHome, nativeHomeWithOverride, expectedNativeHome })
const cleanupGuard = allNodes(revisedAst, node => ts.isCallExpression(node) && node.expression.getText() === 'assert.equal' && node.getText().includes('Cleanup PID creation time changed'))[0]
ctx.actualProcess = { startedAt: validProcess.startedAt }
ctx.lastVerifiedIdentity = { osProcess: { startedAt: validProcess.startedAt } }
check('cleanup guard accepts original creation time', () => vm.runInContext(cleanupGuard.getText(), ctx), true)
ctx.actualProcess = { startedAt: '2000-01-01T00:00:00.0000000Z' }
check('cleanup guard rejects reused PID creation time', () => vm.runInContext(cleanupGuard.getText(), ctx), false)
const syntax = spawnSync(process.execPath, ['--check', revisedPath], { encoding: 'utf8', windowsHide: true })
fs.writeFileSync(path.join(cache, 'node-check.stdout.log'), syntax.stdout)
fs.writeFileSync(path.join(cache, 'node-check.stderr.log'), syntax.stderr)
fs.writeFileSync(path.join(cache, 'node-check.native-exit.txt'), String(syntax.status))
assert.equal(syntax.status, 0, syntax.stderr)
const result = { mode: 'cache-only preparation verification; no Electron/application/package process launched', checkedAt: new Date().toISOString(), original: { path: originalPath, sha256: sha(original) }, revised: { path: revisedPath, sha256: sha(revised) }, assertions: { originalCount: oldAssertions.length, revisedCount: newAssertions.length, preservedOriginal: assertionComparison.length, missing: 0, added: remaining.length }, timeoutChecks: { originalCount: oldTimeouts.length, revisedCount: newTimeouts.length, valuesAndCountsUnchanged: true }, unchangedFunctions, scenarioCount: scenarios.length, scenarios, syntax: { command: [process.execPath, '--check', revisedPath], nativeExit: syntax.status }, passed: true }
fs.writeFileSync(path.join(cache, 'assertion-comparison.json'), JSON.stringify({ comparison: assertionComparison, added: remaining }, null, 2) + '\n')
fs.writeFileSync(path.join(cache, 'preparation-verification.json'), JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify({ passed: true, originalAssertions: oldAssertions.length, allPreserved: true, addedAssertions: remaining.length, scenarios: scenarios.length, syntaxNativeExit: syntax.status, sha256: sha(revised) }))
