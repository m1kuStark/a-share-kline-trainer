"""Select and hash existing f945 evidence. Does not run the app or its checks."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import zipfile
from datetime import datetime, timezone

BASE = Path(r'C:/Users/Stark_Du666/.codex/headroom-cache')
OUT = BASE / 'M9-f945-evidence-archive'
BUNDLE = OUT / 'bundle'
REPO = Path(r'C:/Users/Stark_Du666/.codex/worktrees/m9-enable-01/a-share-kline-trainer')
RUN = REPO / '.runs/run-89c83849-aaae-4f07-a5cd-7cd58edf29f8'
FINAL = BASE / 'M9-final-run-f9454fe'
COMMIT = 'f9454fec92017eba74de2904abf9982deb685ab4'
TREE = 'abf268769e4bdce02e488ba96ea4234ffb0ef8d3'
ZIP = OUT / 'M9-f9454fe-evidence.zip'
entries = []
aliases = []
omissions = []


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for part in iter(lambda: f.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def copy(source, relative, role='original evidence', expected=None):
    source = Path(source)
    assert source.is_file(), source
    assert not source.is_symlink(), source
    assert not any(p.lower() in {'node_modules', 'profile', 'browser-profile', 'tdx-snapshot'} for p in source.parts), source
    assert source.suffix.lower() not in {'.exe', '.dll', '.asar', '.db', '.sqlite', '.sqlite3'}, source
    assert not source.name.lower().startswith(('trainer.sqlite', 'cookies', 'login data')), source
    assert 'f701371' not in source.name, source
    sha = digest(source)
    if expected:
        assert sha == expected, (source, sha, expected)
    target = BUNDLE / relative
    assert target.resolve().is_relative_to(BUNDLE.resolve())
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    assert digest(target) == sha
    entries.append({'path': relative, 'bytes': target.stat().st_size, 'sha256': sha,
                    'source': str(source), 'role': role})


def copy_tree(source, relative, exclusions=None, role='original evidence'):
    exclusions = exclusions or {}
    for root, ds, fs in os.walk(source):
        ds[:] = sorted(d for d in ds if d not in {'node_modules', 'profile', 'data', 'tdx-snapshot', '__pycache__'})
        for name in sorted(fs):
            p = Path(root) / name
            rel = p.relative_to(source).as_posix()
            if rel in exclusions:
                omit(p, exclusions[rel])
            else:
                copy(p, f'{relative}/{rel}', role)


def omit(path, reason, members=False):
    row = {'source': str(path), 'bytes': path.stat().st_size,
           'sha256': digest(path), 'reason': reason, 'originalRetained': True}
    if members:
        with zipfile.ZipFile(path) as z:
            row['zipMembers'] = [
                {'path': x.filename, 'bytes': x.file_size, 'compressedBytes': x.compress_size,
                 'crc32': f'{x.CRC:08x}'} for x in z.infolist()
            ]
    omissions.append(row)


def alias(source, target):
    p = BUNDLE / target
    assert p.is_file() and digest(source) == digest(p), (source, target)
    aliases.append({'source': str(source), 'canonicalArchivePath': target,
                    'bytes': source.stat().st_size, 'sha256': digest(source),
                    'reason': 'byte-identical duplicate of included original evidence'})


def generated(relative, role):
    p = BUNDLE / relative
    entries.append({'path': relative, 'bytes': p.stat().st_size, 'sha256': digest(p),
                    'source': None, 'role': role})


def main():
    assert OUT.resolve().parent == BASE.resolve()
    if BUNDLE.exists():
        raise SystemExit('bundle already exists; inspect it before a deliberate rebuild')
    BUNDLE.mkdir(parents=True)

    # Original complete candidate outcome; do not copy DBs, market files or build output.
    copy(RUN / 'manifest.json', 'payload/full-candidate/manifest.json')
    for p in sorted((RUN / 'artifacts').iterdir()):
        if p.is_file():
            if p.suffix.lower() in {'.db', '.sqlite', '.sqlite3'} or '.sqlite-' in p.name.lower():
                continue
            copy(p, f'payload/full-candidate/artifacts/{p.name}')
    copy_tree(RUN / 'artifacts/test-results', 'payload/full-candidate/artifacts/test-results')
    copy(RUN / 'artifacts/html/index.html', 'payload/full-candidate/artifacts/html/index.html')
    # Candidate success screenshots are not necessary to preserve the two failures.
    # Their inventory remains independently auditable without copying their content.
    for p in sorted((RUN / 'artifacts/screenshots').iterdir()):
        if p.is_file():
            omit(p, 'complete-candidate auxiliary screenshot/export; original retained; failure contexts, logs and browser report included')
    copy_tree(FINAL / 'candidate', 'payload/candidate-isolation')

    # CI API snapshots/log archive are historical observations, not current GitHub state.
    copy_tree(BASE / 'M9-ci-f9454fe', 'payload/ci-source')
    copy_tree(FINAL / 'production-build', 'payload/production-build')
    copy_tree(FINAL / 'assembly/zip-assembly-f9454fec-20261117T205215986Z', 'payload/production-assembly')
    copy(FINAL / 'assembly.log', 'payload/production-assembly/assembly.log')
    copy(FINAL / 'asar-verification.log', 'payload/asar-identity/asar-verification.log')
    copy(FINAL / 'asar/asar-identity-v2.receipt.json', 'payload/asar-identity/asar-identity-v2.receipt.json')

    # Keep both package attempts. Large original Playwright traces remain outside Git.
    for source_dir, target in [('packaged-real', 'packaged-v3-failure'), ('packaged-real-v4', 'packaged-v4')]:
        for p in sorted((FINAL / source_dir).iterdir()):
            assert p.is_file(), p
            if p.name.endswith('.trace.zip'):
                omit(p, 'large original Playwright trace; external original retained; this is a selected evidence archive, not a complete trace archive', members=True)
            else:
                copy(p, f'payload/{target}/{p.name}')
        copy(FINAL / f'{source_dir}.log', f'payload/{target}/script-output.log')
    copy_tree(BASE / 'M9-packaged-v4-review', 'payload/packaged-v4-review')

    copy_tree(FINAL / 'cmd-smoke', 'payload/cmd-v1-failure')
    copy_tree(FINAL / 'cmd-smoke-v2', 'payload/cmd-v2')
    copy_tree(BASE / 'M9-cmd-port-probe-f9454fe', 'payload/cmd-probe-diagnosis')

    # Preserve the earlier native crash and the subsequent same-freeze rerun.
    for p in sorted((BASE / 'M9-desktop-crash-f9454fe').iterdir()):
        if p.is_file() and 'f701371' not in p.name:
            copy(p, f'payload/desktop-native/diagnosis/{p.name}')
    for name in ['desktop-full-f9454fe.log', 'desktop-full-f9454fe.receipt.json',
                 'desktop-full-f9454fe-rerun.log', 'desktop-full-f9454fe-rerun.receipt.json']:
        p = FINAL / name
        possible = BUNDLE / 'payload/desktop-native/diagnosis' / name
        if possible.exists() and digest(possible) == digest(p):
            alias(p, f'payload/desktop-native/diagnosis/{name}')
        else:
            copy(p, f'payload/desktop-native/{name}')

    copy_tree(BASE / 'M9-final-f945-recording-diagnosis', 'payload/recording-diagnosis')
    origin = BASE / 'M9-final-f945-origin-diagnosis'
    duplicate_names = {'browser-results.json', 'journey.log', 'manifest.json', 'unit.log', 'verification.json'}
    for root, ds, fs in os.walk(origin):
        ds[:] = sorted(ds)
        for name in sorted(fs):
            p = Path(root) / name
            rel = p.relative_to(origin).as_posix()
            if rel.startswith('evidence/') and name in duplicate_names:
                canonical = ('payload/full-candidate/manifest.json' if name == 'manifest.json'
                             else f'payload/full-candidate/artifacts/{name}')
                alias(p, canonical)
            else:
                role = ('proposed repair only; not frozen executed source or a passing rerun'
                        if name.endswith('.patch') or '.proposed.' in name else 'original evidence')
                copy(p, f'payload/origin-diagnosis/{rel}', role)

    # These exact script bytes are bound to the retained original receipts.
    scripts = [
        (BASE / 'M9-acceptance-brief/run-candidate-isolated.ps1', '23b31db48eda00ce67353a9a1e8a2d3e728f73cdcdfd92b2b24b0e4865f9f62a'),
        (BASE / 'M9-final-run-20261118/build-m9-production.ps1', '21c815309bb15d56f0d8f7bfb0c97f7a2cd97590de56b2f4302dc52c6331e2c1'),
        (BASE / 'M9-resumed-context/assemble-f9454fe.ps1', '6749cd0f33321ba5a1deda09444ec93a87c88955db65563418998b7cbc00e24d'),
        (BASE / 'M9-home-oracle-repair/m9-packaged-acceptance.v4.cjs', '902970cc9d8e8cd60378e332b9f77010d9f1ff5b1a7a71ad40861d88bc4a704f'),
        (BASE / 'M9-acceptance-brief/m9-zip-smoke.v2.ps1', '2792b8b945ab097f2504acf19d20959636ca6d34900bf1ac7899391f311083f0'),
    ]
    for p, sha in scripts:
        copy(p, f'payload/scripts/{p.name}', 'exact original executed script; SHA matches retained receipt', sha)
    v3 = load(FINAL / 'packaged-real/acceptance-result.json')
    copy(BASE / 'M9-home-oracle-repair/m9-packaged-acceptance.v3.cjs',
         'payload/scripts/m9-packaged-acceptance.v3.cjs',
         'exact earlier failed package script; SHA matches retained receipt', v3['scriptSha256'])
    copy(BASE / 'M9-acceptance-brief/m9-zip-smoke.ps1', 'payload/scripts/m9-zip-smoke.ps1',
         'original CMD v1 script retained for probe-only diff comparison')
    copy(BASE / 'M9-final-run-20261118/verify-m9-asar-v2.cjs', 'payload/scripts/verify-m9-asar-v2.cjs')

    # This is an offline extraction of original v4 geometry, not another app run.
    a = load(FINAL / 'packaged-real-v4/acceptance-result.json')
    frames = []
    for s in a['stages']:
        if s['name'].startswith('training-all-builtins-'):
            frames.append({'name': s['name'], 'viewport': s['viewport'],
                           'firstCanvas': s['canvas'][0], 'allCanvasGeometry': s['canvas'],
                           'screenshotArchivePath': f"payload/packaged-v4/{s['name']}.png"})
    write(BUNDLE / 'derived/v4-main-pane-geometry.json', {
        'kind': 'offline extraction of original receipt; no application run',
        'sourceReceiptArchivePath': 'payload/packaged-v4/acceptance-result.json',
        'sourceReceiptSha256': digest(FINAL / 'packaged-real-v4/acceptance-result.json'),
        'firstCanvasInterpretation': 'main K pane, identified in root screenshot review; geometry is copied verbatim from original stages',
        'frames': frames,
        'finding': '1440x900: first canvas height68; 1366x768 and1024x768: first canvas height0, both themes. Script passed=true does not establish visual acceptance.'
    })
    generated('derived/v4-main-pane-geometry.json', 'offline derived evidence index')

    write(BUNDLE / 'aliases.json', {'aliases': aliases})
    generated('aliases.json', 'byte-identical source aliases')
    write(BUNDLE / 'omissions.json', {
        'policy': [
            'No database, database journal, browser profile, cookies, installed binary, ASAR contents, market snapshot, or node_modules copied.',
            'No previously archived f701371 log/receipt files copied. Comparison text in f945 diagnoses is retained as context.',
            'Post-f945 layout repair source/tests and later GREEN runs are outside this frozen archive.',
            'Originals are retained unchanged. Omitted trace containers have SHA256 and ZIP member inventories; member payloads were not extracted.',
        ], 'omissions': omissions,
        'notRearchived': [str(BASE / 'M9-desktop-crash-f9454fe' / n) for n in
                         ['desktop-full-f701371.log', 'desktop-full-f701371.receipt.json']]
    })
    generated('omissions.json', 'explicit selected-archive exclusions')

    readme = '''# M9 f9454fe evidence archive

Frozen source: `f9454fec92017eba74de2904abf9982deb685ab4`; tree `abf268769e4bdce02e488ba96ea4234ffb0ef8d3`; base `58ba0ffc13458fb136c7d885b62ee0c898d4bab8`; package version `1.3.8`.

This selected archive preserves original outcomes and their limits. It is not a passing candidate receipt or release approval. Existing files were copied byte for byte; the archive operation ran no application, test, build, or GitHub command and made no repository/control/matrix changes.

| Evidence | Observed result | Scope and unresolved boundary |
| --- | --- | --- |
| Complete candidate `run-89c83849-aaae-4f07-a5cd-7cd58edf29f8` | native **1**; **259 passed / 2 failed / 0 skipped**, workers1/retry0 | docs, impact, unit, types, build, snapshot and m2 passed; journey failed. Original report/log/context is retained. This failure cannot be replaced by targeted GREEN results. |
| Candidate isolation | source revision **236**, source/snapshot SHA unchanged; shared status before/after0 | Source and both snapshot hashes are `3daf82f34b6161ce771f842ba09e3b51330c3d1fb80358a78de2a951db1692d5`; temporary local snapshot removed. |
| Source CI run `44173225929`, attempt1 | docs/verify/pr-policy successful; **222 files / 3033 tests** | Synthetic merge `67677d19ef1eb86672b58d193b39e097c50ebba1` has the same tree as f945. This is source CI only, not local complete candidate/corpus/Journey/package/visual/human acceptance. API captures are historical; they do not assert current PR state. |
| Production build and assembly | build/build:desktop:main/release:desktop native0; assembly passed and every extracted ZIP file matched | Assembly before/after head f945 and porcelain empty. Binary payloads remain external; their hashes and receipts are retained. |
| Earlier packaged v3 attempt | **failed** waiting 30s for DOM download event | Original failure receipt, screenshot/DOM, output and exact v3 script retained. This is not a successful export attempt. |
| Packaged v4 | script reported `passed=true`; outer native0 was observed by root in the original execution; both product exits0 | There is no standalone outer-node exit receipt in this selected source set. Do not relabel the JSON passed field as such a receipt. Geometry/screenshots show main K pane failure: 1440x900 height68; **1366x768 and1024x768 height0**, both themes. **Visual acceptance failed/pending repair**, despite script success. |
| v4 recording export and restart | real DOM export/save/gunzip; offline51 checks passed; same-origin library replay and two real process boots | Exported gzip has schema2, 8 events, 11 checkpoints. The library replay used the later10-event post-settlement row. **The exported8-event gzip was not imported or replayed.** Numeric/curve fidelity, all replay frames, installer, upgrade, macOS, and human acceptance are not established. |
| CMD v2 real launcher smoke | outer PowerShell native **0**, product `app_exit=0`, **`launcher_exit=null`** | Visible window, health/sample/profile identity, native close, process gone and port release observed. The original contract allowed the launcher exit to remain null. It must never be rewritten as0. |
| Desktop native test first attempt | **-1073740791 /0xC0000409**, no Vitest summary | Original crash remains unexplained. Duplicate `maxTries` warning appears, but it does not establish the crash cause; exact WER/Application window queries found no events. |
| Desktop same-freeze rerun | native **0**;34 files /369 tests passed | Original failure and rerun are both retained. A successful rerun does not diagnose the earlier crash. |

The two complete-candidate failures are diagnosed as follows. The foreign-origin fixture selected ephemeral port3659, blocked by Edge with `ERR_UNSAFE_PORT`. Same-origin GET/PUT succeeded, but foreign-request and blocked-response assertions were not reached. The owned app used port12953; this does not prove a guard breach or a full guard pass. The included Chromium/Fetch snapshots corroborate the port restriction but do not identify the exact executing Edge build.

For recording-long, the previous settings case persisted cash123456. The launcher mounted before the direct API reset to1000000, so its already-loaded form submitted explicit cash123456. Price1304.13 made one100-share lot cost130413, while the50% budget was61728. Both buys were correctly rejected; `initialBuyFilled=false` failed the test. The initial gzip export succeeded with cash123456. This is fixture ordering, not an export failure. Proposed patches/source candidates inside diagnosis folders are proposals only; they were not the frozen executed source and do not turn the original full run GREEN. No failure trace/screenshot was generated for these two cases beyond the retained error contexts and legitimate-origin screenshot.

CMD v1's loopback probe treated an incomplete `.Wait(750)` as open, including after its owned listener stopped. The retained v2 probe-only repair uses Node TCP: connected=true, ECONNREFUSED=false, all other failures/timeout throw. Positive/negative controls and the intermediate PowerShell5.1 quoting failure are retained. Other assertions/deadlines were preserved.

Package identity: executable SHA256 `16323422757e2ee5d2f9c238c67e393cb3e9517ffd83f361a3ff02310d56e7eb`; ASAR `bc1ecac5e917d0407590fff1900078ad480324ff2d516031516b441ffb10a5a1`; acceptance ZIP `c74a53bf5f4c3a036c2c23a88ff24bbbe7d63ef43f38ff5d88734a636e23629c`. The binaries themselves are excluded.

The exact candidate/build/assembly/v3/v4/CMD scripts are under `payload/scripts`; per-file SHA256 and original paths are in `archive-manifest.json`. `derived/v4-main-pane-geometry.json` selects the six original stage geometry records and points to screenshots. `aliases.json` resolves byte-identical originals to canonical included files. `omissions.json` records omitted complete-candidate auxiliary images/exports and three large original browser trace containers with paths, sizes, SHA256 and ZIP member inventories. The original traces are retained externally. This ZIP is therefore a selected evidence archive, not a complete browser trace archive. Database/profile/market/binary content and already archived f701 files are excluded. Post-f945 layout changes and later GREEN runs are also excluded.

Run `python tools/verify-archive.py .` inside this directory to verify the included file manifest offline. The external archive verification receipt binds the finished ZIP's CRC, member SHA256, byte count and SHA256. These checks establish archive integrity, not product acceptance.
'''
    (BUNDLE / 'README.md').write_text(readme, encoding='utf-8')
    generated('README.md', 'archive explanation and explicit acceptance limits')

    verify = '''"""Offline integrity check only. Does not execute evidence scripts."""
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
manifest=json.loads((root/'archive-manifest.json').read_text(encoding='utf-8'))
errors=[]
for item in manifest['files']:
 p=(root/item['path']).resolve()
 if not p.is_relative_to(root) or not p.is_file():
  errors.append({'path':item['path'],'error':'missing or unsafe path'});continue
 raw=p.read_bytes()
 if len(raw)!=item['bytes'] or hashlib.sha256(raw).hexdigest()!=item['sha256']:
  errors.append({'path':item['path'],'error':'size or SHA256 mismatch'})
expected={x['path'] for x in manifest['files']}|{'archive-manifest.json'}
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
if expected!=actual:errors.append({'error':'file set mismatch','extra':sorted(actual-expected),'missing':sorted(expected-actual)})
print(json.dumps({'passed':not errors,'filesChecked':len(manifest['files']),'errors':errors},ensure_ascii=False))
sys.exit(1 if errors else 0)
'''
    (BUNDLE / 'tools').mkdir(exist_ok=True)
    (BUNDLE / 'tools/verify-archive.py').write_text(verify, encoding='utf-8')
    generated('tools/verify-archive.py', 'archive-only offline hash verifier')
    copy(Path(__file__), 'tools/build-archive.py', 'archive-only selection/copy/hash script; not a product execution')
    write(BUNDLE / 'archive-manifest.json', {
        'schemaVersion': 1, 'sourceCommit': COMMIT, 'sourceTree': TREE,
        'createdAt': datetime.now(timezone.utc).isoformat(),
        'selectionScope': 'frozen failed f945 candidate and related CI/package/CMD/desktop evidence',
        'selfHashPolicy': 'manifest excludes itself to avoid a circular hash; finished ZIP binds all members',
        'files': sorted(entries, key=lambda x: x['path'])
    })

    # ZIP deterministic member order/timestamps; preserve unmodified file bytes.
    prefix = 'M9-f9454fe-evidence/'
    with zipfile.ZipFile(ZIP, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(BUNDLE.rglob('*')):
            if p.is_file():
                zi = zipfile.ZipInfo(prefix + p.relative_to(BUNDLE).as_posix(), (2026, 11, 18, 0, 0, 0))
                zi.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(zi, p.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)

    verification = {'sourceCommit': COMMIT, 'applicationTestBuildOrGitHubCommandsRun': False,
                    'repoControlMatrixWrites': False, 'archivePath': str(ZIP),
                    'archiveBytes': ZIP.stat().st_size, 'archiveSha256': digest(ZIP),
                    'sourceCopyFilesVerified': 0, 'zipMembersVerified': 0, 'errors': []}
    for x in entries:
        p = BUNDLE / x['path']
        assert digest(p) == x['sha256'] and p.stat().st_size == x['bytes']
        if x['source']:
            assert digest(Path(x['source'])) == x['sha256']
            verification['sourceCopyFilesVerified'] += 1
    members = []
    with zipfile.ZipFile(ZIP) as z:
        assert z.testzip() is None
        for zi in z.infolist():
            raw = z.read(zi)
            rel = zi.filename.removeprefix(prefix)
            assert hashlib.sha256(raw).hexdigest() == digest(BUNDLE / rel)
            members.append({'path': zi.filename, 'bytes': len(raw),
                            'sha256': hashlib.sha256(raw).hexdigest(), 'crc32': f'{zi.CRC:08x}'})
            verification['zipMembersVerified'] += 1
    write(OUT / 'zip-members.json', {'members': members})
    verification.update({'passed': True, 'bundle': str(BUNDLE), 'includedOriginalFiles': verification['sourceCopyFilesVerified'],
                         'omittedFiles': len(omissions), 'identicalAliases': len(aliases),
                         'largeTraceCount': sum('zipMembers' in x for x in omissions),
                         'largeTraceBytes': sum(x['bytes'] for x in omissions if 'zipMembers' in x),
                         'finishedAt': datetime.now(timezone.utc).isoformat()})
    write(OUT / 'archive-verification.receipt.json', verification)
    print(json.dumps(verification, ensure_ascii=False))


if __name__ == '__main__':
    main()
