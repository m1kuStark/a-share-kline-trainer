"""Offline integrity check only. Does not execute evidence scripts."""
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
manifest=json.loads((root/'archive-manifest.json').read_text(encoding='utf-8'))
errors=[]
for item in manifest['files']:
 p=(root/item['path']).resolve()
 if not p.is_relative_to(root) or not p.is_file():
  errors.append({'path':item['path'],'error':'missing or unsafe path'});continue
 raw=p.read_bytes()
 if len(raw)!=item['bytes'] or hashlib.sha256(raw).hexdigest()!=item['sha256']:
  errors.append({'path':item['path'],'error':'size or SHA256 mismatch'})
expected={x['path'] for x in manifest['files']}|{'archive-manifest.json'}
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
if expected!=actual:errors.append({'error':'file set mismatch','extra':sorted(actual-expected),'missing':sorted(expected-actual)})
print(json.dumps({'passed':not errors,'filesChecked':len(manifest['files']),'errors':errors},ensure_ascii=False))
sys.exit(1 if errors else 0)
