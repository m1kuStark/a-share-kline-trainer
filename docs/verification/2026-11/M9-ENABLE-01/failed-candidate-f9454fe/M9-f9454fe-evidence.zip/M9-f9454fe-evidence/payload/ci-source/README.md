# PR55 source CI: f9454fe

Source freeze: f9454fec92017eba74de2904abf9982deb685ab4. Run44173225929, attempt1, pull_request Source checks, completed/success.
PR55 head matched before and after capture; docs/verify/pr-policy were all required and all successful. PR remained draft/open.
CI actually checked out synthetic merge 67677d19ef1eb86672b58d193b39e097c50ebba1; its parents are58ba0ffc13458fb136c7d885b62ee0c898d4bab8 and f9454fec92017eba74de2904abf9982deb685ab4. Its tree abf268769e4bdce02e488ba96ea4234ffb0ef8d3 equals the source commit tree.
Test summaries:188 files/2664 tests plus34 files/369 tests =222 files/3033 tests. Job and per-step logs repeat these summaries; repeated occurrences are not added.

Original ZIP logs-44173225929.zip:102259 bytes, SHA256 eb51115d9a74f787cae2f37effb0a3aabe99eaec973b685706e416a463b0419b,32 members; CRC and each member SHA256 checked in memory, no extracted logs written.
Original API bodies, required checks, main rules, source commit, attempt-specific jobs, native command receipts and observation snapshots are preserved.
Source checks do not establish local full candidate, package, visual or human acceptance. No GitHub or repository mutation was performed.
