param(
  [Parameter(Mandatory = $true)][string]$RepoRoot,
  [Parameter(Mandatory = $true)][string]$ExtractedPackage,
  [Parameter(Mandatory = $true)][string]$ReceiptRoot,
  [Parameter(Mandatory = $true)][ValidatePattern('^[0-9a-fA-F]{64}$')][string]$ExpectedExeSha256
)
$ErrorActionPreference = 'Stop'

function Assert-NoReparseAncestor([string]$Path) {
  $cursor = $Path
  while ($cursor) {
    if (Test-Path -LiteralPath $cursor) {
      $item = Get-Item -LiteralPath $cursor -Force
      if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Reparse path is outside smoke ownership: $cursor" }
    }
    $parent = [IO.Directory]::GetParent($cursor)
    $cursor = if ($null -eq $parent) { $null } else { $parent.FullName }
  }
}

function Resolve-AbsoluteDirectory([string]$Path) {
  if (![IO.Path]::IsPathRooted($Path)) { throw "An explicit absolute directory is required: $Path" }
  $full = [IO.Path]::GetFullPath($Path)
  Assert-NoReparseAncestor $full
  if (!(Test-Path -LiteralPath $full -PathType Container)) { throw "Directory does not exist: $full" }
  return (Resolve-Path -LiteralPath $full).Path.TrimEnd([IO.Path]::DirectorySeparatorChar)
}

function Test-LoopbackPort([int]$Port) {
  # Match the v3 TCP evidence semantics: successful connect=open, ECONNREFUSED=closed,
  # timeout/other errors=unknown. Unknown must fail rather than become a closed port.
  $nodeExe = (Get-Command node.exe -ErrorAction Stop).Source
  $probeCode = 'const net=require("node:net");const port=Number(process.argv[1]);const socket=net.createConnection({host:"127.0.0.1",port});let done=false;const finish=(status,error)=>{if(done)return;done=true;socket.destroy();console.log(JSON.stringify({status,error,port,connectTimeoutMs:750}));};socket.setTimeout(750,()=>finish("unknown","timeout"));socket.once("connect",()=>finish("open",null));socket.once("error",e=>finish(e.code==="ECONNREFUSED"?"closed":"unknown",String(e)));'
  $nativeOutput = & $nodeExe --eval $probeCode -- ([string]$Port) 2>&1
  $nativeExit = $LASTEXITCODE
  $probeText = ($nativeOutput | Out-String).Trim()
  if ($nativeExit -ne 0) { throw "Loopback TCP probe command failed (${nativeExit}): $probeText" }
  $probe = $probeText | ConvertFrom-Json
  if ([int]$probe.port -ne $Port -or [int]$probe.connectTimeoutMs -ne 750) { throw 'Loopback TCP probe identity/budget mismatch.' }
  if ($probe.status -eq 'open') { return $true }
  if ($probe.status -eq 'closed') { return $false }
  throw "Loopback TCP port release is unknown: $probeText"
}

$repoRoot = Resolve-AbsoluteDirectory $RepoRoot
$ownedRuns = [IO.Path]::GetFullPath((Join-Path $repoRoot '.runs')) + [IO.Path]::DirectorySeparatorChar
$packageRoot = Resolve-AbsoluteDirectory $ExtractedPackage
if (!$packageRoot.StartsWith($ownedRuns, [StringComparison]::OrdinalIgnoreCase)) { throw 'Smoke package must be an owned extraction under .runs.' }
if (@(Get-ChildItem -LiteralPath $packageRoot -Recurse -Force | Where-Object { ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 }).Count -ne 0) { throw 'Extraction contains reparse entries.' }
$dataRoot = Join-Path $packageRoot '.acceptance-data'
if (Test-Path -LiteralPath $dataRoot) { throw 'Fresh extraction required; do not reuse a user profile.' }
$executables = @(Get-ChildItem -LiteralPath (Join-Path $packageRoot 'app') -Filter '*.exe' -File)
if ($executables.Count -ne 1) { throw 'Expected exactly one application executable.' }
$exePath = $executables[0].FullName
$exeSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $exePath).Hash.ToLowerInvariant()
if ($exeSha256 -ne $ExpectedExeSha256.ToLowerInvariant()) { throw 'Executable SHA256 does not match the frozen ZIP identity.' }

if (![IO.Path]::IsPathRooted($ReceiptRoot)) { throw 'ReceiptRoot must be an explicit absolute directory.' }
$receiptRoot = [IO.Path]::GetFullPath($ReceiptRoot).TrimEnd([IO.Path]::DirectorySeparatorChar)
Assert-NoReparseAncestor $receiptRoot
if ([StringComparer]::OrdinalIgnoreCase.Equals($receiptRoot, $packageRoot) -or $receiptRoot.StartsWith($packageRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'ReceiptRoot must be outside the extraction.' }
$stdout = Join-Path $receiptRoot 'zip-launcher-stdout.log'
$stderr = Join-Path $receiptRoot 'zip-launcher-stderr.log'
$receiptPath = Join-Path $receiptRoot 'zip-launcher-smoke.json'
$failurePath = Join-Path $receiptRoot 'zip-launcher-failure.json'
foreach ($output in @($stdout, $stderr, $receiptPath, $failurePath)) {
  if (Test-Path -LiteralPath $output) { throw "Receipt already exists; choose a fresh ReceiptRoot: $output" }
}
New-Item -ItemType Directory -Path $receiptRoot -Force | Out-Null

# Bind the real CMD/PowerShell route to the repository's reviewed isolation wrapper.
# Its verified source sets TDX_ROOT=sample-market and clears inherited trainer paths.
$wrapperIdentity = @()
foreach ($name in @('Start-Acceptance.cmd', 'Start-Acceptance.ps1')) {
  $source = Join-Path $repoRoot ('scripts\acceptance\' + $name)
  $copy = Join-Path $packageRoot $name
  $sourceHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $source).Hash.ToLowerInvariant()
  $copyHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $copy).Hash.ToLowerInvariant()
  if ($sourceHash -ne $copyHash) { throw "ZIP wrapper differs from reviewed repository source: $name" }
  $wrapperIdentity += [ordered]@{ name = $name; source = $source; sourceSha256 = $sourceHash; extracted = $copy; extractedSha256 = $copyHash }
}

$sampleRoot = Resolve-AbsoluteDirectory (Join-Path $packageRoot 'sample-market')
$sampleFiles = @(Get-ChildItem -LiteralPath $sampleRoot -Recurse -File | Sort-Object FullName | ForEach-Object {
  [ordered]@{ path = $_.FullName.Substring($sampleRoot.Length + 1).Replace('\', '/'); bytes = $_.Length; sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName).Hash.ToLowerInvariant() }
})
$sampleCatalog = @()
foreach ($market in @('sh', 'sz', 'bj')) {
  $directory = Join-Path $sampleRoot ('vipdoc\' + $market + '\lday')
  if (!(Test-Path -LiteralPath $directory -PathType Container)) { continue }
  foreach ($file in @(Get-ChildItem -LiteralPath $directory -Filter '*.day' -File)) {
    if ($file.BaseName -notmatch ('^' + $market + '(\d{6})$')) { continue }
    $code = $Matches[1]
    $isShare = if ($market -eq 'sh') { $code -match '^(600|601|603|605|688|689)\d{3}$' } elseif ($market -eq 'sz') { $code -match '^(000|001|002|003|300|301)\d{3}$' } else { $code -match '^(4|8|92)\d{4}$' }
    if (!$isShare) { continue }
    if ($file.Length -eq 0 -or $file.Length % 32 -ne 0) { throw "Sample A-share day file must contain complete records: $($file.FullName)" }
    $bytes = [IO.File]::ReadAllBytes($file.FullName)
    $lastDay = [BitConverter]::ToUInt32($bytes, $bytes.Length - 32).ToString('D8')
    $lastDate = [DateTime]::ParseExact($lastDay, 'yyyyMMdd', [Globalization.CultureInfo]::InvariantCulture).ToString('yyyy-MM-dd')
    $sampleCatalog += [ordered]@{ market = $market; code = $code; bars = [long]($file.Length / 32); lastDate = $lastDate }
  }
}
if ($sampleCatalog.Count -eq 0) { throw 'Sample market has no readable A-share day files.' }
$sampleCutoff = @($sampleCatalog | ForEach-Object { $_.lastDate } | Sort-Object)[-1]
$state = $null
$application = $null
$launcherExit = $null
try {
  $launcherPath = Join-Path $packageRoot 'Start-Acceptance.cmd'
  $launcher = Start-Process -FilePath $env:ComSpec -ArgumentList @('/d', '/c', ('""' + $launcherPath + '""')) -WorkingDirectory $packageRoot -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru
  if (!$launcher.WaitForExit(45000)) { throw 'Acceptance CMD did not finish starting the application within 45 seconds.' }
  $launcher.Refresh()
  $launcherExit = $launcher.ExitCode
  if ($null -ne $launcherExit -and $launcherExit -ne 0) { throw "Acceptance CMD failed: $launcherExit" }
  $deadline = [DateTime]::UtcNow.AddSeconds(45)
  $statePath = Join-Path $dataRoot 'trainer-state.json'
  while ([DateTime]::UtcNow -lt $deadline) {
    if (Test-Path -LiteralPath $statePath) {
      $state = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
      $application = Get-Process -Id $state.pid -ErrorAction SilentlyContinue
      if ($application) {
        if (![StringComparer]::OrdinalIgnoreCase.Equals($application.Path, $exePath)) { throw 'State belongs to an unexpected executable.' }
        $application.Refresh()
        if ($application.MainWindowHandle -ne 0) { break }
      }
    }
    Start-Sleep -Milliseconds 400
  }
  if (!$application -or $application.MainWindowHandle -eq 0) { throw 'No visible application window appeared.' }
  if (![StringComparer]::OrdinalIgnoreCase.Equals($state.databasePath, (Join-Path $dataRoot 'trainer.sqlite'))) { throw 'Database escaped acceptance directory.' }
  if (!(Test-Path -LiteralPath $state.databasePath -PathType Leaf)) { throw 'Isolated SQLite database was not created.' }
  $processHandle = $application.Handle
  $window = @{ handle = [string]$application.MainWindowHandle; title = $application.MainWindowTitle }
  $commandLine = (Get-CimInstance Win32_Process -Filter "ProcessId = $($application.Id)").CommandLine
  $profile = Join-Path $dataRoot 'profile'
  if (!$commandLine.Contains($profile)) { throw 'Chromium profile is not inside the extraction.' }
  $baseUri = [Uri]$state.baseURL
  if ($baseUri.Scheme -ne 'http' -or $baseUri.Host -ne '127.0.0.1' -or $baseUri.Port -ne [int]$state.port -or $baseUri.AbsolutePath -ne '/') { throw 'State baseURL is not the owned loopback port.' }
  $health = Invoke-RestMethod -Uri ($state.baseURL + '/api/health') -TimeoutSec 10
  if ($health.runId -ne $state.runId -or $health.pid -ne $state.pid -or $health.status -ne 'ok') { throw 'Health identity does not match the owned state.' }
  $environment = Invoke-RestMethod -Uri ($state.baseURL + '/api/env') -TimeoutSec 30
  if ($environment.status -ne 'ok' -or !$environment.tdx.connected -or $environment.tdx.source -ne 'env') { throw 'Sample market was not connected through the verified environment wrapper.' }
  if ($environment.stockCount -ne $sampleCatalog.Count -or $environment.dataCutoff -ne $sampleCutoff) { throw 'Runtime sample catalog count/cutoff differs from extraction.' }
  foreach ($expected in $sampleCatalog) {
    $query = '/api/stocks?market=' + $expected.market + '&q=' + [Uri]::EscapeDataString($expected.code)
    $catalog = Invoke-RestMethod -Uri ($state.baseURL + $query) -TimeoutSec 10
    $matching = @($catalog.items | Where-Object { $_.market -eq $expected.market -and $_.code -eq $expected.code })
    if ($matching.Count -ne 1 -or $matching[0].bars -ne $expected.bars -or $matching[0].lastDate -ne $expected.lastDate) { throw "Runtime stock differs from sample data: $($expected.market)$($expected.code)" }
  }
  # Chromium may persist Local State shortly after visible window/health readiness.
  $profileFile = Join-Path $profile 'Local State'
  $profileDeadline = [DateTime]::UtcNow.AddSeconds(30)
  while (!(Test-Path -LiteralPath $profileFile) -and [DateTime]::UtcNow -lt $profileDeadline) { Start-Sleep -Milliseconds 250 }
  if (!(Test-Path -LiteralPath $profileFile)) { throw 'Chromium profile was not created at the isolated path.' }
  if (!$application.CloseMainWindow()) { throw 'Native window-close request was rejected.' }
  if (!$application.WaitForExit(30000)) { throw 'Owned Electron process did not stop after native window close.' }
  $application.Refresh()
  $appExit = $application.ExitCode
  if (Get-Process -Id $state.pid -ErrorAction SilentlyContinue) { throw 'Owned process still exists after close.' }
  if ($null -eq $appExit -or $appExit -ne 0) { throw "Native application exit was not successful: $appExit" }
  $portDeadline = [DateTime]::UtcNow.AddSeconds(10)
  while ((Test-LoopbackPort ([int]$state.port)) -and [DateTime]::UtcNow -lt $portDeadline) { Start-Sleep -Milliseconds 250 }
  if (Test-LoopbackPort ([int]$state.port)) { throw 'Owned loopback port still accepts connections after native close.' }
  if ((Get-FileHash -Algorithm SHA256 -LiteralPath $exePath).Hash.ToLowerInvariant() -ne $exeSha256) { throw 'Executable changed during CMD smoke.' }
  $receipt = [ordered]@{
    time = [DateTimeOffset]::Now.ToString('o')
    command = 'Start-Acceptance.cmd from a fresh extraction of the final ZIP'
    repoRoot = $repoRoot
    extraction = $packageRoot
    receiptRoot = $receiptRoot
    scriptSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $PSCommandPath).Hash.ToLowerInvariant()
    executable = @{ path = $exePath; expectedSha256 = $ExpectedExeSha256.ToLowerInvariant(); sha256 = $exeSha256 }
    wrappers = $wrapperIdentity
    launcher_exit = $launcherExit
    app_exit = $appExit
    window = $window
    health = $health
    state = $state
    profile = $profile
    commandLine = $commandLine
    sample = @{ root = $sampleRoot; files = $sampleFiles; catalog = $sampleCatalog; environment = $environment; proof = 'Byte-matched reviewed wrappers inject this sample root; runtime catalog matches sample files. /api/env intentionally omits private paths.' }
    nativeCloseProcessGone = $true
    nativeClosePortReleased = $true
    result = 'Final ZIP extraction: actual CMD displayed the app, matched executable identity, used isolated database/profile and verified sample catalog, served matching health, then exited and released its loopback port on native window close.'
  }
  $receipt | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $receiptPath -Encoding UTF8
  $receipt | ConvertTo-Json -Depth 12
} catch {
  $failure = [ordered]@{
    time = [DateTimeOffset]::Now.ToString('o')
    repoRoot = $repoRoot
    extraction = $packageRoot
    executable = @{ path = $exePath; sha256 = $exeSha256 }
    wrappers = $wrapperIdentity
    launcher_exit = $launcherExit
    state = $state
    error = $_.Exception.ToString()
    cleanup = 'No forced termination performed. Preserve evidence and inspect the recorded owned PID before any recovery.'
    passed = $false
  }
  $failure | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $failurePath -Encoding UTF8
  throw
}
