# local-origin failure diagnosis (f945)

结论：这是外站测试夹具的端口选择错误。测试用 `listen(0)` 得到 3659，Edge 在 `page.goto` 阶段返回 `net::ERR_UNSAFE_PORT`；跨站读取、写入和最终设置持久性断言均未执行。不能把这次失败归为产品来源守卫失效，也不能据此宣称浏览器安全检查通过。

## 身份与原始结果

- 工作树：`C:/Users/Stark_Du666/.codex/worktrees/m9-enable-01/a-share-kline-trainer`
- tested commit：`f9454fec92017eba74de2904abf9982deb685ab4`
- tree：`abf268769e4bdce02e488ba96ea4234ffb0ef8d3`
- run：`run-89c83849-aaae-4f07-a5cd-7cd58edf29f8`
- 原全量：native 1，259 passed / 2 failed；本报告只诊断 local-origin，另一项 recording-long 不在本次结论范围。
- owned 应用端口为 12953，失败端口为外站夹具的 3659；不是应用端口打不开。
- 本用例唯一一次 attempt：retry 0，3819 ms。`scripts/verify-candidate.ts:77` 显式 `--retries=0`，覆盖 config 的 retries 1。

## 精确失败与已执行范围

原始错误保存在 `evidence/journey.log:297-313`、`evidence/origin-error-context.md` 和 `origin-browser-result.json`：

```
Error: page.goto: net::ERR_UNSAFE_PORT at http://127.0.0.1:3659/
Call log:
  - navigating to "http://127.0.0.1:3659/", waiting until "load"
```

`e2e/local-origin.spec.ts:11-17` 已走完同源页面、历史 GET=200、设置 PUT=200，并生成合法页面截图；截图已静态查看，为创建训练页。`:19-27` 创建并监听外站夹具后，在导航时失败。`:28-36` 的两个 fetch、blocked 等式和最终 autoDataCheck=true 均未到达。

失败目录只有 error-context.md，没有 trace.zip 或失败截图。error-context 的浏览器快照是 Edge 的 ERR_UNSAFE_PORT 错误页。`playwright.config.ts:19` 默认 trace=off，且源码未配置 screenshot 字段；注释中的失败截图说法与此目录实际证据不一致。本次不声称检查了不存在的 trace。

## 根因链与产品边界

1. `e2e/local-origin.spec.ts:23` 直接使用 OS 随机端口，未验证其浏览器可访问性。
2. `:27` 打开随机端口，不涉及任何训练器 API 调用。
3. 保存的 Chromium 上游源码 `chromium-port_util.cc:37-106` 将 3659 放入 kRestrictedPorts；`:181-195` 对命中该列表的端口拒绝访问。保存的 Fetch 标准 `fetch-standard.html:5024` 同样列有 3659。两个上游快照的原始 URL、SHA256 在 receipt；它们是本次获取的上游 main/标准快照，不是原运行 Edge 精确版本的源码证明。
4. 原运行的 Edge 错误字符串及页面快照直接证明该次导航被 unsafe-port 检查挡住。源码和标准仅作机制交叉印证。

`server/src/index.ts:55-66` 的产品 onRequest 守卫依次校验 loopback Host、sec-fetch-site 和 Origin；本次失败发生在外站夹具导航，尚未执行浏览器跨站请求，故没有证据要求修改产品守卫。既有 `server/test/local-request-guard.test.ts:38,51,58,67,94,105` 覆盖外站/opaque Origin、跨站 metadata、Host、同源兼容、预检和真实 Vite 代理。原 unit.log 记录 188 文件/2664 测试通过，但未单独列出该文件；不得伪造单文件执行收据。四个关键文件及配置均和 f945 内容一致，逐文件比对记录在 receipt。

## 最小修复与复现计划（未执行）

建议只修外站夹具端口分配与就绪证明：

1. 外站 fixture 从浏览器允许的动态高端口池中选取端口并直接 bind；例如 49152..65535 随机选取并对 EADDRINUSE/EACCES 做有界重选。保存候选端口与最终端口。此范围避开已保存的标准 bad-port 集合；浏览器策略仍以实际导航为准。不要使用固定单一端口、预先探测再释放的竞争窗口，或 `--explicitly-allowed-ports` / disable-web-security。
2. 如使用 port=0 并按禁止端口表筛选，则把表来源、范围、被拒候选和关闭重绑流程显式写清；必须有有界失败，不能盲目无限重试。
3. page.goto 成功后，验证页面 title=隔离外站夹具且 location.origin 与 run.baseURL 不同，再执行原有两个 fetch 和设置不变断言；保留全部安全断言，不改成跳过或容错。
4. helper 单测覆盖被禁止的 3659、占用端口、关闭/重绑以及候选耗尽；为避免复现依赖 OS 碰巧给出 3659，分配策略应可注入候选序列。
5. 需要重现原 setup 错误时，独立 owned 诊断夹具显式 bind 3659（仅该临时复现）；若端口占用则记录前置不足，不换端口后冒称复现。执行 Edge 导航并保留错误/trace；不触碰产品配置。
6. 修复后先执行 guard 单测与 `TRAINER_TRACE=on npm run journey -- e2e/local-origin.spec.ts --retries=0` 的等价 PowerShell 环境写法；用 owned manifest / 临时 DB，检查合法读写、外站 blocked 和设置不变全部到达。失败原件不可覆盖。是否重跑正式 candidate 由主控结合最终变更和正式证据政策决定；原 full native1 不能改写成通过。

本诊断未运行应用、测试、构建或复现；未写 repo、control、matrix、GitHub，只在本外部目录写入证据副本、上游快照和报告。布局提案保持暂停。
