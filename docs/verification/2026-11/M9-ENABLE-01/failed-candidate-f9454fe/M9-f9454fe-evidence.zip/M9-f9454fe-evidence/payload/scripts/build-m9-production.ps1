param([Parameter(Mandatory)][string]$RepoRoot,[Parameter(Mandatory)][string]$SourceCommit,[Parameter(Mandatory)][string]$EvidenceRoot,[Parameter(Mandatory)][string]$OutputRelative)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
Set-Location -LiteralPath $RepoRoot
if((git rev-parse HEAD).Trim() -ne $SourceCommit -or @(git status --porcelain).Count){throw 'A clean declared source commit is required.'}
$taskOutput=[IO.Path]::GetFullPath((Join-Path $RepoRoot $OutputRelative))
if(!$taskOutput.StartsWith([IO.Path]::GetFullPath($RepoRoot)+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Output must stay in repository.'}
if(Test-Path -LiteralPath $taskOutput){throw 'Fresh production output required.'}
New-Item -ItemType Directory -Path $EvidenceRoot -Force | Out-Null
if(Test-Path -LiteralPath (Join-Path $EvidenceRoot 'production-build.receipt.json')){throw 'Fresh evidence required.'}
$taskReceipt=[ordered]@{sourceCommit=$SourceCommit;tree=(git rev-parse 'HEAD^{tree}');startedAt=(Get-Date).ToUniversalTime().ToString('o');scriptSha256=(Get-FileHash $PSCommandPath).Hash.ToLowerInvariant();version=(Get-Content package.json -Raw|ConvertFrom-Json).version;lockSha256=(Get-FileHash package-lock.json).Hash.ToLowerInvariant();output=$taskOutput;steps=@();trackedInputs=@();passed=$false}
foreach($taskFile in @('desktop/build-resources/migration-export-inline.html','desktop/build-resources/migration-import-recordings.js','tools/migrate-v127/dist/migrate-v127/export-v127.cjs')){
  if(!(Test-Path -LiteralPath $taskFile)){throw ('Missing existing migration input: '+$taskFile)}
  $taskReceipt.trackedInputs+=@{path=$taskFile;sha256=(Get-FileHash $taskFile).Hash.ToLowerInvariant();bytes=(Get-Item $taskFile).Length}
}
foreach($taskName in @('TRAINER_STATIC_DIR','TRAINER_RUN_MANIFEST','TRAINER_RUN_ID','TRAINER_READY_FILE','ELECTRON_RUN_AS_NODE','DESKTOP_DEV_URL','TRAINER_CONTROL_ROOT','NODE_OPTIONS')){Remove-Item -LiteralPath ('Env:'+$taskName) -ErrorAction SilentlyContinue}
$taskExit=1
try{
  foreach($taskStep in @('build','build:desktop:main','release:desktop')){
    if($taskStep -eq 'release:desktop'){$env:TRAINER_RELEASE_OUT_DIR=$OutputRelative}
    $taskLog=Join-Path $EvidenceRoot ($taskStep.Replace(':','-')+'.log')
    if(Test-Path $taskLog){throw 'Refusing to overwrite a build log.'}
    $taskStart=(Get-Date).ToUniversalTime().ToString('o')
    & npm.cmd run $taskStep > $taskLog 2>&1
    $taskNative=$LASTEXITCODE
    $taskReceipt.steps+=@{command=@('npm.cmd','run',$taskStep);nativeExitCode=$taskNative;startedAt=$taskStart;endedAt=(Get-Date).ToUniversalTime().ToString('o');log=$taskLog;sha256=(Get-FileHash $taskLog).Hash.ToLowerInvariant()}
    if($taskNative -ne 0){throw ('Build step failed: '+$taskStep+' nativeExit='+$taskNative)}
    if((git rev-parse HEAD).Trim() -ne $SourceCommit -or @(git status --porcelain).Count){throw 'Source changed during production build.'}
  }
  $taskReceipt.artifacts=@(Get-ChildItem -LiteralPath $taskOutput -File | Sort-Object Name | ForEach-Object {@{name=$_.Name;bytes=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant()}})
  $taskReceipt.executableSha256=(Get-FileHash -LiteralPath (Join-Path $taskOutput 'win-unpacked/K线训练器.exe')).Hash.ToLowerInvariant()
  $taskReceipt.asarSha256=(Get-FileHash -LiteralPath (Join-Path $taskOutput 'win-unpacked/resources/app.asar')).Hash.ToLowerInvariant()
  $taskReceipt.passed=$true
  $taskExit=0
}catch{$taskReceipt.failure=$_.Exception.ToString();Write-Error -Message $_ -ErrorAction Continue}
finally{
  $taskReceipt.finishedAt=(Get-Date).ToUniversalTime().ToString('o');$taskReceipt.nativeExitCode=$taskExit
  $taskReceipt|ConvertTo-Json -Depth 10|Set-Content -LiteralPath (Join-Path $EvidenceRoot 'production-build.receipt.json') -Encoding utf8NoBOM
  Write-Output ($taskReceipt|ConvertTo-Json -Depth 10 -Compress)
}
exit $taskExit
