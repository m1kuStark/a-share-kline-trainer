param(
  [Parameter(Mandatory)][string]$RepoRoot,
  [Parameter(Mandatory)][string]$TaskId,
  [Parameter(Mandatory)][string]$BaseSha,
  [Parameter(Mandatory)][string]$ControlRoot,
  [Parameter(Mandatory)][string]$EvidenceRoot
)
$ErrorActionPreference = 'Stop'
$PSNativeCommandUseErrorActionPreference = $false
$taskRepo = (Resolve-Path -LiteralPath $RepoRoot).Path
$taskControl = (Resolve-Path -LiteralPath $ControlRoot).Path
$taskEvidence = [IO.Path]::GetFullPath($EvidenceRoot)
New-Item -ItemType Directory -Path $taskEvidence -Force | Out-Null
foreach ($taskExistingName in @('candidate.log','candidate-isolation.receipt.json','shared-status-before.log','shared-status-after.log')) {
  if (Test-Path -LiteralPath (Join-Path $taskEvidence $taskExistingName)) { throw 'Fresh candidate evidence directory required.' }
}
$taskSource = Join-Path $taskControl 'trainer-state.json'
$taskLocalDir = Join-Path $taskRepo '.control'
$taskLocalFile = Join-Path $taskLocalDir 'trainer-state.json'
if (Test-Path -LiteralPath $taskLocalFile) { throw 'A local canonical-state file already exists; do not overwrite it.' }
$taskCreatedDir = !(Test-Path -LiteralPath $taskLocalDir)
if (!$taskCreatedDir -and ((Get-Item -LiteralPath $taskLocalDir).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Local control directory is a reparse point.' }
$taskOldControl = [Environment]::GetEnvironmentVariable('TRAINER_CONTROL_ROOT', 'Process')
$taskReceipt = [ordered]@{ task=$TaskId; repo=$taskRepo; base=$BaseSha; startedAt=(Get-Date).ToUniversalTime().ToString('o'); scriptSha256=(Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant(); sourceControl=$taskSource; localSnapshot=$taskLocalFile; gates=@{}; cleanup=@{} }
$taskExit = 1
try {
  Set-Location -LiteralPath $taskRepo
  $taskReceipt.commit = (git rev-parse HEAD)
  $env:TRAINER_CONTROL_ROOT = $taskControl
  & npm.cmd run docs:status -- --check > (Join-Path $taskEvidence 'shared-status-before.log') 2>&1
  $taskReceipt.gates.sharedStatusBefore = $LASTEXITCODE
  if ($taskReceipt.gates.sharedStatusBefore -ne 0) { throw 'Real shared status precheck failed.' }
  $taskReceipt.sourceSha256 = (Get-FileHash -LiteralPath $taskSource -Algorithm SHA256).Hash.ToLowerInvariant()
  $taskReceipt.sourceRevision = (Get-Content -LiteralPath $taskSource -Raw | ConvertFrom-Json).state_revision
  if ($taskCreatedDir) { New-Item -ItemType Directory -Path $taskLocalDir | Out-Null }
  Copy-Item -LiteralPath $taskSource -Destination $taskLocalFile -ErrorAction Stop
  $taskReceipt.snapshotBeforeSha256 = (Get-FileHash -LiteralPath $taskLocalFile -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($taskReceipt.snapshotBeforeSha256 -ne $taskReceipt.sourceSha256) { throw 'Canonical snapshot copy drifted.' }
  Remove-Item Env:TRAINER_CONTROL_ROOT -ErrorAction SilentlyContinue
  & npm.cmd run verify:candidate -- --base $BaseSha --task $TaskId > (Join-Path $taskEvidence 'candidate.log') 2>&1
  $taskExit = $LASTEXITCODE
  $taskReceipt.gates.candidate = $taskExit
} catch {
  $taskReceipt.failure = $_.Exception.ToString()
  $taskExit = 1
} finally {
  if (Test-Path -LiteralPath $taskLocalFile) {
    $taskReceipt.snapshotAfterSha256 = (Get-FileHash -LiteralPath $taskLocalFile -Algorithm SHA256).Hash.ToLowerInvariant()
    $taskReceipt.cleanup.snapshotUnchanged = $taskReceipt.snapshotAfterSha256 -eq $taskReceipt.snapshotBeforeSha256
    if (!$taskReceipt.cleanup.snapshotUnchanged) { $taskExit = 1 }
    Remove-Item -LiteralPath $taskLocalFile -ErrorAction Stop
  }
  if ($taskCreatedDir -and (Test-Path -LiteralPath $taskLocalDir) -and @(Get-ChildItem -LiteralPath $taskLocalDir -Force).Count -eq 0) { Remove-Item -LiteralPath $taskLocalDir -ErrorAction Stop }
  $taskReceipt.cleanup.localSnapshotRemoved = !(Test-Path -LiteralPath $taskLocalFile)
  $env:TRAINER_CONTROL_ROOT = $taskControl
  & npm.cmd run docs:status -- --check > (Join-Path $taskEvidence 'shared-status-after.log') 2>&1
  $taskReceipt.gates.sharedStatusAfter = $LASTEXITCODE
  if ($taskReceipt.gates.sharedStatusAfter -ne 0) { $taskExit = 1 }
  $taskReceipt.sourceAfterSha256 = (Get-FileHash -LiteralPath $taskSource -Algorithm SHA256).Hash.ToLowerInvariant()
  $taskReceipt.cleanup.sourceUnchanged = $taskReceipt.sourceAfterSha256 -eq $taskReceipt.sourceSha256
  if (!$taskReceipt.cleanup.sourceUnchanged) { $taskExit = 1 }
  if ($null -eq $taskOldControl) { Remove-Item Env:TRAINER_CONTROL_ROOT -ErrorAction SilentlyContinue } else { $env:TRAINER_CONTROL_ROOT = $taskOldControl }
  $taskReceipt.endedAt = (Get-Date).ToUniversalTime().ToString('o')
  $taskReceipt.nativeExitCode = $taskExit
  $taskReceipt.exitCodeCapture = '$LASTEXITCODE immediately after each native command; no pipeline'
  $taskReceipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $taskEvidence 'candidate-isolation.receipt.json') -Encoding utf8NoBOM
  Write-Output ($taskReceipt | ConvertTo-Json -Depth 8 -Compress)
}
exit $taskExit
