# f9454fec desktop 全套异常退出：只读初步诊断

范围：未写仓库，未改产品/测试/配置/预算，未启动程序、测试或浏览器。只读现有日志、当前配置、限定时间窗的Windows事件；所有材料保存在本外部目录。

## 已确认

- 冻结提交：f9454fec92017eba74de2904abf9982deb685ab4。
- 外层命令：npm.cmd run test:desktop，即 vitest run --config desktop/vitest.config.ts。
- 收据时间：2026-11-17T20:52:41.5810926Z 至20:53:13.8637005Z，对应2026-11-18 04:52:41.581至04:53:13.864 Asia/Shanghai。
- 外层原生退出码：-1073740791（按本轮提供的十六进制表示为0xC0000409）。完整日志566字节，SHA256 fd68eddf07413997d07e63311d1f736a4a6584b0eeb74ed2f8a260334f99390e。
- 日志只有Vitest v4.1.12启动及portable-updater-smoke.test.ts:152的重复maxTries键警告，没有Vitest失败汇总、断言失败、JS堆栈或明确测试超时诊断。日志不足以确认已经完成了哪些用例。
- desktop配置为environment=node、pool=threads、maxWorkers=2、testTimeout=30000。运行耗时约32秒与30秒预算接近，本身不能证明测试超时或预算不足。
- f701371原同命令收据native0，34个文件/369个测试通过，耗时22.88秒；同样出现完全相同的重复maxTries警告。该警告不是新现象，不能据此定为新崩溃根因。
- git diff --name-status f701371..f9454fec -- desktop package.json package-lock.json为空且原生0；当前相同路径git status无变化。这证明这些受Git管理的源/config/依赖声明未变化，不证明node_modules原生二进制或运行环境完全相同。

## Windows事件查询

机器时区确认为China Standard Time。只查询2026-11-18 04:52:41至04:53:14本地时间，并以UTC 2026-11-17T20:52:41.000Z至20:53:14.000Z的FilterXml再次核对，没有扩大时间窗。

Application日志的EventID1000/1001两次查询都返回：

    No events were found that match the specified selection criteria.

下列已启用WER通道在同一精确UTC时间窗也均无事件：

- Microsoft-Windows-WER-Diag/Operational
- Microsoft-Windows-WER-PayloadHealth/Operational
- Microsoft-Windows-WerKernel/Operational

查询原始ErrorRecord完整保存在event-query-error.log、event-query-utc-error.log及各通道.query-error.log；查询边界和结果见wer-exact-window-result.json、machine-timezone.json。没有对用户数据目录作扫描，也没有查时间窗之外的事件。

## 结论与证据边界

当前只能确认这次desktop全套命令异常退出，不能将它计为测试通过，也不能把缺失的Vitest汇总解释为某条断言失败。

具体崩溃进程/PID、异常模块、模块版本、调用栈、异常参数均未知；当前没有node.exe的匹配Application/WER事件可用于确认。外层npm.cmd的退出码不能单独证明究竟是Vitest主进程、线程worker、子进程、原生模块还是外部终止触发。

可能调查的边界包括Vitest/Node线程worker、测试启动/导入阶段、原生依赖或外部进程退出；它们只是未排除的类别，不是已有证据支持的根因。现有材料不支持修改产品、测试断言、并发、配置或预算。

本轮按要求未复现/重跑，因此尚不能判断偶发性。根因未知。后续若获准复跑，应保持冻结源码、配置与预算不变，完整保留退出和进程诊断；若需更广时间窗或崩溃dump，应另明确范围。