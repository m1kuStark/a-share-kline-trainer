const fs = require('node:fs')
const path = require('node:path')
const cp = require('node:child_process')
const crypto = require('node:crypto')
const assert = require('node:assert/strict')
const root = __dirname
const gh = 'D:/MySoftWares/gh/bin/gh.exe'
const cwd = 'C:/Users/Stark_Du666/.codex/worktrees/m9-enable-01/a-share-kline-trainer'
const repository = 'm1kuStark/a-share-kline-trainer'
const sourceFreeze = 'f9454fec92017eba74de2904abf9982deb685ab4'
const receipts = []
const sha = b => crypto.createHash('sha256').update(b).digest('hex')
const api = endpoint => ['api', '-H', 'X-GitHub-Api-Version: 2022-11-28', endpoint]
async function call(name, args, { binary = false, required = true } = {}) {
  const stdoutPath = path.join(root, name + (binary ? '.zip' : '.json'))
  assert.ok(!fs.existsSync(stdoutPath), 'Capture files must be new: ' + name)
  const startedAt = new Date().toISOString()
  const r = await new Promise((resolve, reject) => {
    const child = cp.spawn(gh, args, { cwd, shell: false, windowsHide: true })
    const stdout = [], stderr = []
    child.stdout.on('data', b => stdout.push(b))
    child.stderr.on('data', b => stderr.push(b))
    child.on('error', reject)
    child.on('close', (code, signal) => resolve({ code, signal, stdout: Buffer.concat(stdout), stderr: Buffer.concat(stderr) }))
  })
  fs.writeFileSync(stdoutPath, r.stdout)
  fs.writeFileSync(path.join(root, name + '.stderr.log'), r.stderr)
  const receipt = { name, startedAt, endedAt: new Date().toISOString(), program: gh, args, cwd, nativeExitCode: r.code, signal: r.signal, stdout: stdoutPath, bytes: r.stdout.length, sha256: sha(r.stdout), stderr: path.join(root, name + '.stderr.log'), stderrBytes: r.stderr.length, stderrSha256: sha(r.stderr), exitCapture: 'Direct child close event exit code; no shell or pipeline; binary stdout retained byte-for-byte.' }
  receipts.push(receipt)
  fs.writeFileSync(path.join(root, name + '.exit.json'), JSON.stringify(receipt, null, 2) + '\n')
  if (required) assert.equal(r.code, 0, name + ': GH read command must succeed')
  if (r.code !== 0) return null
  return binary ? r.stdout : JSON.parse(r.stdout.toString('utf8'))
}

async function main() {
  const independent = await Promise.allSettled([
    call('pr55', api('repos/' + repository + '/pulls/55')),
    call('pr55-view', ['pr', 'view', '55', '--repo', repository, '--json', 'number,title,url,state,isDraft,headRefName,headRefOid,baseRefName,baseRefOid,statusCheckRollup,mergeable,mergeStateStatus,updatedAt']),
    call('required-checks', ['pr', 'checks', '55', '--repo', repository, '--required', '--json', 'name,state,bucket,link,workflow,startedAt,completedAt']),
    call('main-active-rules', api('repos/' + repository + '/rules/branches/main')),
    call('source-freeze-check-runs', api('repos/' + repository + '/commits/' + sourceFreeze + '/check-runs?per_page=100')),
  ])
  for (const r of independent) if (r.status === 'rejected') throw r.reason
  const [pr, view, checks, rules, sourceChecks] = independent.map(r => r.value)
  const runIds = [...new Set(sourceChecks.check_runs.map(row => row.details_url?.match(/\/actions\/runs\/(\d+)/)?.[1]).filter(Boolean))]
  assert.ok(runIds.length > 0, 'Source-freeze checks must identify workflow run')
  const runs = []
  for (const id of runIds) {
    const results = await Promise.allSettled([
      call('run-' + id, api('repos/' + repository + '/actions/runs/' + id)),
      call('jobs-' + id, api('repos/' + repository + '/actions/runs/' + id + '/attempts/1/jobs?per_page=100')),
      call('logs-' + id, api('repos/' + repository + '/actions/runs/' + id + '/logs'), { binary: true }),
    ])
    for (const r of results) if (r.status === 'rejected') throw r.reason
    const [run, jobs, zip] = results.map(r => r.value)
    assert.equal(zip.readUInt32LE(0), 0x04034b50, 'Downloaded original run logs must be a ZIP')
    runs.push({ id, run, jobs, zipPath: path.join(root, 'logs-' + id + '.zip'), zipSha256: sha(zip) })
  }
  const merge = pr.merge_commit_sha ? await call('pr55-test-merge-git-commit', api('repos/' + repository + '/git/commits/' + pr.merge_commit_sha)) : null
  const after = await call('pr55-after', api('repos/' + repository + '/pulls/55'))
  const summary = {
    capturedAt: new Date().toISOString(), repository, prNumber: 55, sourceFreeze,
    pr: { url: pr.html_url, title: pr.title, state: pr.state, draft: pr.draft, sourceHead: pr.head.sha, baseHead: pr.base.sha, testMergeSHA: pr.merge_commit_sha, afterSourceHead: after.head.sha, stableSourceHeadDuringCapture: pr.head.sha === after.head.sha, matchesSourceFreeze: pr.head.sha === sourceFreeze, mergeable: pr.mergeable, mergeState: pr.mergeable_state },
    requiredChecks: checks, activeRules: rules,
    sourceCheckRuns: sourceChecks.check_runs.map(row => ({ id: row.id, name: row.name, head_sha: row.head_sha, status: row.status, conclusion: row.conclusion, details_url: row.details_url, check_suite: row.check_suite })),
    runs: runs.map(({id,run,jobs,zipPath,zipSha256}) => ({ id, url: run.html_url, name: run.name, event: run.event, status: run.status, conclusion: run.conclusion, runAttempt: run.run_attempt, headSHA: run.head_sha, headCommitId: run.head_commit?.id, sourcePullRequests: run.pull_requests, jobs: jobs.jobs.map(row => ({ id: row.id, name: row.name, headSHA: row.head_sha, status: row.status, conclusion: row.conclusion, startedAt: row.started_at, completedAt: row.completed_at, stepCount: row.steps.length, steps: row.steps.map(s => ({name:s.name,status:s.status,conclusion:s.conclusion})) })), jobTotalCount: jobs.total_count, zipPath, zipSha256 })),
    syntheticMerge: merge ? { sha: merge.sha, tree: merge.tree.sha, parents: merge.parents.map(p => p.sha), sourceIsParent: merge.parents.some(p => p.sha === sourceFreeze) } : null,
    receipts: receipts.map(({name,nativeExitCode,sha256,bytes,stdout})=>({name,nativeExitCode,sha256,bytes,stdout})),
    evidenceScope: 'Source-freeze PR CI snapshot only. Later final-documentation commits must have separate CI evidence. No comments, reviews, status changes, merges, or workflow dispatches.'
  }
  fs.writeFileSync(path.join(root, 'source-ci-summary.json'), JSON.stringify(summary, null, 2) + '\n')
  console.log(JSON.stringify({ pr: summary.pr, requiredChecks: checks.map(({name,state,bucket})=>({name,state,bucket})), runs: summary.runs.map(({id,status,conclusion,runAttempt,headSHA,jobs,zipPath,zipSha256})=>({id,status,conclusion,runAttempt,headSHA,jobs:jobs.map(({name,status,conclusion})=>({name,status,conclusion})),zipPath,zipSha256})), syntheticMerge: summary.syntheticMerge, commandCount: receipts.length, allNativeExit0: receipts.every(r=>r.nativeExitCode===0) }, null, 2))
}
main().catch(error => {
  fs.writeFileSync(path.join(root, 'capture-failure.json'), JSON.stringify({ capturedAt: new Date().toISOString(), error: error.stack, receipts }, null, 2) + '\n')
  console.error(error)
  process.exitCode = 1
})

