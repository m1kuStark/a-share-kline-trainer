﻿$ErrorActionPreference='Stop'
$source='C:/Users/Stark_Du666/.codex/headroom-cache/M9-acceptance-brief/m9-zip-smoke.v2.ps1'
$tokens=$null; $errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile($source,[ref]$tokens,[ref]$errors)
if($errors.Count){throw ($errors | Out-String)}
$function=$ast.Find({param($entry) $entry -is [Management.Automation.Language.FunctionDefinitionAst] -and $entry.Name -eq 'Test-LoopbackPort'},$true)
if(!$function){throw 'Original probe function not found'}
Invoke-Expression $function.Extent.Text
function Measure-Detailed([int]$Port){
 $client=[Net.Sockets.TcpClient]::new(); $watch=[Diagnostics.Stopwatch]::StartNew()
 try{
  $connect=$client.ConnectAsync('127.0.0.1',$Port)
  $completed=$connect.Wait(750)
  [pscustomobject]@{completedWithin750=$completed;connected=$client.Connected;taskStatus=[string]$connect.Status;originalResult=if(!$completed){$true}else{$client.Connected};exception=$null;elapsedMs=$watch.ElapsedMilliseconds}
 }catch{
  [pscustomobject]@{completedWithin750=$null;connected=$client.Connected;taskStatus=if($connect){[string]$connect.Status}else{$null};originalResult=$false;exception=$_.Exception.ToString();elapsedMs=$watch.ElapsedMilliseconds}
 }finally{$client.Dispose();$watch.Stop()}
}
$nodePath='C:/Users/Stark_Du666/.codex/headroom-cache/M9-cmd-port-probe-f9454fe/v3-equivalent-tcp-probe.cjs'
$listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0)
$listener.Start();$ownedPort=$listener.LocalEndpoint.Port
$rows=@()
try{
 for($index=0;$index -lt 3;$index++){$watch=[Diagnostics.Stopwatch]::StartNew();$value=Test-LoopbackPort $ownedPort;$rows += [ordered]@{phase='controlled-listener-open';sample=$index;originalResult=$value;elapsedMs=$watch.ElapsedMilliseconds}}
 $openDetail=Measure-Detailed $ownedPort
 $nodeOpen=(& node $nodePath $ownedPort | Out-String).Trim();$nodeOpenExit=$LASTEXITCODE
 $listener.Stop()
 for($index=0;$index -lt 3;$index++){$watch=[Diagnostics.Stopwatch]::StartNew();$value=Test-LoopbackPort $ownedPort;$rows += [ordered]@{phase='same-owned-port-after-listener-stop';sample=$index;originalResult=$value;elapsedMs=$watch.ElapsedMilliseconds}}
 $closedDetail=Measure-Detailed $ownedPort
 $nodeClosed=(& node $nodePath $ownedPort | Out-String).Trim();$nodeClosedExit=$LASTEXITCODE
 $result=[ordered]@{time=[DateTimeOffset]::Now.ToString('o');source=$source;sourceSha256=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash;ownedEphemeralPort=$ownedPort;samples=$rows;openDetailed=$openDetail;closedDetailed=$closedDetail;nodeV3Equivalent=@{open=$nodeOpen;openNativeExit=$nodeOpenExit;closed=$nodeClosed;closedNativeExit=$nodeClosedExit};scope='Controlled loopback listener only. No product process or application launched or terminated.'}
 $json=$result | ConvertTo-Json -Depth 8
 [IO.File]::WriteAllText('C:/Users/Stark_Du666/.codex/headroom-cache/M9-cmd-port-probe-f9454fe/v2-controlled-positive-negative.ps51.json',$json,[Text.UTF8Encoding]::new($false));$json
}finally{$listener.Stop()}
