# local-origin 外站夹具端口修复草案

外部补丁：`fixture-safe-port.patch`。仅适用于指定工作树 `e2e/local-origin.spec.ts`。

读取仓库：`C:\Users\Stark_Du666\.codex\worktrees\m9-enable-01\a-share-kline-trainer`；HEAD：`f9454fec92017eba74de2904abf9982deb685ab4`。
原文件 SHA256：`a282acf70f1ba16262bed1577b81c3a3c45c60d4634649df7d08b25ee31c83c4`。
原文件快照：`local-origin.original.ts`；补丁后草案：`local-origin.proposed.ts`。

## 修改范围

`foreign.listen(0)` 允许系统分配浏览器禁用端口。草案以 `randomInt(20_000, 60_001)` 在 20000–60000（含两端）直接 bind；只对 EADDRINUSE 重新抽取端口，总计最多 10 次。第 10 次失败及所有其他错误立即抛出。没有先探测再释放的端口竞争窗口。

导航后增加标题等于“隔离外站夹具”和页面 origin 不等于 `new URL(run.baseURL!).origin` 两项断言，确保跨源请求实际从夹具页面发起。

原有 5 处断言、合法页面读写、跨源读写 blocked 断言、设置保持 true 的断言和 finally 清理均保留；未添加、放宽或更改超时预算。

## 证据边界

只读源文件，在 Headroom 缓存生成补丁。未写仓库、control 或 matrix；未运行 App、测试、构建或浏览器；没有修复通过的动态结论。静态文本自检确认原断言逐行仍存在，并确认源文件字节未变。ERR_UNSAFE_PORT / 3659 来自根代理提供的诊断，本次未重新复现。

前两次外部生成错误均保留：CRLF 导致 AssertionError: Expected original ephemeral-port fixture exactly once；本机 Python 不支持 write_text(newline=...)，TypeError: write_text() got an unexpected keyword argument 'newline'。改为规范化读取换行、UTF-8 write_bytes 后生成成功，仓库字节未变。

由集成人审查并在任务范围内应用，再保留原失败安排定向 journey 验证。
