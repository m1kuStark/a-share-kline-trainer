# recording-long failure diagnosis: f9454fec

Diagnosis: test fixture resets persistent defaults AFTER Launcher has mounted and consumed the previous default. Launcher then explicitly submits its already loaded initial_cash=123456. The first two buy requests correctly fail with insufficient one-lot capital. This is a proven setup ordering defect, not evidence that a click was lost or that recording export/replay failed.

## Frozen failure and limits

- Run: run-89c83849-aaae-4f07-a5cd-7cd58edf29f8, manifest commit f9454fec92017eba74de2904abf9982deb685ab4.
- Full candidate: native1,259 passed /2 failed. Recording-long failed in28.2s at e2e/recording-long.spec.ts:66, expect(initialBuyFilled).toBe(true), receivedfalse.
- The other local-origin unsafe-port failure is independent and outside this diagnosis.
- recording-long explicitly turns trace off at line9. Its failure directory contains error-context.md only, no screenshot or trace. The saved DOM snapshot and initial gzip export are available and retained here. No trace has been invented or inferred.
- This read-only diagnosis did not execute app/tests/build or modify repo/control/matrix. Root's unrelated task-card/formula-chart edits were observed in git status and left intact.
- The prior f701 failure and a later targeted pass are reported history, not re-inspected evidence in this diagnosis. They do not establish a flake classification or a successful complete candidate.

## Evidence chain

1. e2e/uiux-settings.spec.ts:25-51 fills123456 and really clicks Save; test has no default reset after saving. It runs as case248 before long case261. operations.log records PUT default initialCash123456, status200, at2026-11-17T21:36:18.612Z.
2. Long spec mounts Launcher via page.goto at line32, selects stock/tier/date, then PUTs1000000 at lines39-53. server.log16664-16671 shows Launcher GET at21:38:10.033Z before later settings PUT at21:38:10.501Z. The API operation completes at21:38:10.534Z with1000000 persisted.
3. Launcher.vue:166-198 mounts loadDefaults and applies initialCash to the ref. Its settingsSavedVersion watcher only handles the client-side notifySettingsSaved broadcast. Direct page.request.put does not call TrainingSettings.vue:333 notifySettingsSaved or settingsPanel.ts:15-17. Launcher.vue:486-499 constructs create params from that ref as explicit initial_cash.
4. operations.log records POST /api/trainings status201 at21:38:13.799Z with initial_cash123456 despite preceding successful PUT1000000. Isolated trainer.sqlite opened with URI mode=ro confirms training185 initial_cash123456, current_close1304.13, fees disabled, current_date2024-09-13; settings.training_initial_cash is1000000; training185 has zero trades.
5. two-year-initial.json.gz independently records resources.trainingMeta[0].value.initialCash123456 and account.cash/equity123456. This export succeeds before the failed buys, so the error is not initial export failure.
6. Both buy requests reached the server, at21:38:14.423Z and21:38:24.455Z, payload sidebuy/weightPct50, status400. Error snapshot shows the exact insufficient-one-lot error, cash123456, position0. Independent arithmetic: one lot100 *1304.13 =130413 > all cash123456;50% budget61728 can buy zero lots. account.ts:87-90 returns that exact error when floor(equity*weightPct/100/price/100)<1.

The product behaved consistently with current form values and lot rules. No production change is justified by this failure. The long test's comment attributing the first click to startup load does not explain this captured failure; both real requests failed deterministically under an invalid cash fixture.

## Minimal proposed patch

recording-long-preload-defaults.patch moves the existing GET/PUT/default-status assertion block before page.goto. It changes only a comment explaining why pre-mount ordering is required. Every existing assertion, timeout, export, buy retry count and long-session behavior remains. No added trading retries, weakened assertions or extended wait budget.

The authoritative contract is docs/specs/training/rules.md TRAIN-RULE-SNAPSHOT/M5-DEFAULTS: form initial values come from settings; explicit create overrides are preserved. Launcher mounting before an out-of-band API update cannot be treated as an update notification. Existing production version/dirty safeguards must remain.

## RED and verification plan, not executed

Existing full-run failure is already semantic RED evidence: wrong created initialCash123456, two real HTTP400, line66false. Preserve it unchanged.

For a short deterministic reproduction, seed only the isolated run settings to123456 BEFORE the long test navigates, then execute the original setup through create and initial buy. Capture the create request/response, displayed or snapshot initialCash, trade request/response and status message. Expected independent fixture invariant is initialCash1000000 and first requested buy valid; old ordering yields123456/400. Never seed a personal database.

Then apply the minimal pre-mount ordering patch; validate the same pre-seeded low-default sequence creates1000000 and the first trade succeeds. First run a narrowly scoped setup/first-buy probe, then the unshortened long test and the original full candidate. A targeted green cannot replace259/2 full-run failure or establish candidate readiness.

Suggested authorized command after application: npm run journey -- e2e/uiux-settings.spec.ts e2e/recording-long.spec.ts --retries=0 (fresh isolated runtime manifest/TDX snapshot). This explicitly includes the real preceding low-cash setter. A final candidate run must still include the full suite.

## Retained evidence

- diagnosis.receipt.json: read-only DB facts, initial export identity, independent arithmetic and limits.
- settings-create-trade.operations.json: selected original API operations with payloads; includes prior123456 PUT, later1000000 PUT, actual123456 create and both400 buys.
- server-tail.excerpt.log / journey-failures.excerpt.log: line-numbered saved original logs.
- error-context.original.md / two-year-initial.original.json.gz / run-manifest.original.json: byte copies.
- source-and-oracle.excerpts.json: current unchanged recording setup and product flow excerpts.
- hashes.json: original files and external patch SHA256.

Preparation-only lookup errors: several initial guessed source/test filenames did not exist and rg ignored .runs until direct enumeration; those are inspection mistakes, not product failures. DB access was explicitly read-only; no SQLite/WAL mutations were requested.
