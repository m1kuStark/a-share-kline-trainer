﻿# Preparation artifact only. Root executes this after clean same-commit production build.
# ProductionRoot contains win-unpacked and release-manifest.json. No app/build invocation.
[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$RepoRoot,
  [Parameter(Mandatory=$true)][string]$ProductionRoot,
  [Parameter(Mandatory=$true)][ValidatePattern('^[a-fA-F0-9]{40}$')][string]$SourceCommit,
  [Parameter(Mandatory=$true)][string]$EvidenceRoot,
  [Parameter(Mandatory=$true)][string]$DeliveryRoot
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$scriptSelf = $PSCommandPath
$utf8 = [Text.UTF8Encoding]::new($false)
$expectedDelivery = 'D:/Superlinear_Academy/Stock_WorkSpace/a-share-kline-trainer/output/acceptance/M9-ENABLE-01-20261118-f9454fe'
$knownSnapshot = 'C:/Users/Stark_Du666/.codex/worktrees/m9-enable-01/a-share-kline-trainer/.runs/run-6eb1ecab-8032-4fac-a5bb-80aa2dc58a2b/tdx-snapshot'
$expectedSnapshotSha = '1149d6447ef3cf4e564691cbd0bfd75ce2a402c9f1d17a2062184e38ff08fba5'
$assemblyEvidence = $null
$receipt = [ordered]@{ mode='production-to-ZIP assembly only; no build or app run'; startedAt=[DateTime]::UtcNow.ToString('o'); passed=$false; appRun=$false; buildRun=$false }
function Full-Path([string]$Value) {
  if (![IO.Path]::IsPathRooted($Value)) { throw "Absolute path required: $Value" }
  return [IO.Path]::GetFullPath($Value).TrimEnd([char[]]'\/')
}
function Same-Path([string]$A,[string]$B) { return [StringComparer]::OrdinalIgnoreCase.Equals((Full-Path $A),(Full-Path $B)) }
function Inside([string]$Child,[string]$Parent) { return (Full-Path $Child).StartsWith((Full-Path $Parent)+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase) }
function Assert-NoReparseAncestors([string]$Path) {
  $cursor = [IO.Path]::GetFullPath($Path)
  while ($cursor) {
    if (Test-Path -LiteralPath $cursor) {
      $item = Get-Item -LiteralPath $cursor -Force
      if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Reparse point refused: $cursor" }
    }
    $parent = [IO.Directory]::GetParent($cursor)
    if ($null -eq $parent) { break }
    $cursor = $parent.FullName
  }
}
function Hash([string]$Path) { return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Write-Json([string]$Path,$Value) { [IO.File]::WriteAllText($Path,($Value | ConvertTo-Json -Depth 14)+[Environment]::NewLine,$utf8) }
function Git-Read([string[]]$Arguments) {
  $output = & git -C $RepoRoot @Arguments
  $nativeExit = $LASTEXITCODE
  if ($nativeExit -ne 0) { throw "git $($Arguments -join ' ') failed with native exit $nativeExit" }
  return ($output -join "`n")
}
function Assert-CleanSource([string]$Phase) {
  $top = Git-Read @('rev-parse','--show-toplevel')
  if (!(Same-Path $top $RepoRoot)) { throw 'RepoRoot must be the exact checkout root' }
  $head = Git-Read @('rev-parse','HEAD')
  if ($head.ToLowerInvariant() -ne $SourceCommit) { throw "$Phase HEAD $head differs from SourceCommit $SourceCommit" }
  $status = Git-Read @('status','--porcelain=v1','--untracked-files=all')
  if ($status) { throw "$Phase checkout is not clean:`n$status" }
  return [ordered]@{phase=$Phase;head=$head;porcelain=$status;nativeExit=0;at=[DateTime]::UtcNow.ToString('o')}
}
function Relative-Path([string]$Root,[string]$Path) {
  if (!(Inside $Path $Root)) { throw "Path escaped tree: $Path" }
  return (Full-Path $Path).Substring((Full-Path $Root).Length+1).Replace('\','/')
}
function Tree([string]$Root) {
  Assert-NoReparseAncestors $Root
  if (!(Test-Path -LiteralPath $Root -PathType Container)) { throw "Directory missing: $Root" }
  $files = [Collections.Generic.List[object]]::new()
  $dirs = [Collections.Generic.List[string]]::new()
  $pending = [Collections.Generic.Stack[string]]::new()
  $pending.Push($Root)
  while ($pending.Count -gt 0) {
    $current = $pending.Pop()
    foreach ($entry in @(Get-ChildItem -LiteralPath $current -Force)) {
      if (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Reparse point refused: $($entry.FullName)" }
      $relative = Relative-Path $Root $entry.FullName
      if ($entry.PSIsContainer) { $dirs.Add($relative); $pending.Push($entry.FullName) }
      else { $files.Add([pscustomobject]@{path=$relative;bytes=[long]$entry.Length;sha256=(Hash $entry.FullName)}) }
    }
  }
  return [pscustomobject]@{files=@($files.ToArray() | Sort-Object path);directories=@($dirs.ToArray() | Sort-Object)}
}
function Compare-Trees($Expected,$Actual,[string]$Label) {
  $wanted=@($Expected.files);$got=@($Actual.files)
  if ($wanted.Count -ne $got.Count) { throw "$Label file count differs: $($wanted.Count) / $($got.Count)" }
  $map=[Collections.Generic.Dictionary[string,object]]::new([StringComparer]::OrdinalIgnoreCase)
  foreach($row in $got) { if($map.ContainsKey($row.path)){throw "$Label duplicate path"};$map.Add($row.path,$row) }
  foreach($row in $wanted) {
    if(!$map.ContainsKey($row.path)){throw "$Label missing file: $($row.path)"}
    $actualRow=$map[$row.path]
    if([long]$actualRow.bytes -ne [long]$row.bytes -or $actualRow.sha256 -ne $row.sha256){throw "$Label byte/hash mismatch: $($row.path)"}
  }
  $wantedDirs=@($Expected.directories | Sort-Object);$gotDirs=@($Actual.directories | Sort-Object)
  if($wantedDirs.Count -ne $gotDirs.Count){throw "$Label directory count differs"}
  for($i=0;$i -lt $wantedDirs.Count;$i++){if(![StringComparer]::OrdinalIgnoreCase.Equals($wantedDirs[$i],$gotDirs[$i])){throw "$Label directory set differs"}}
}
function Copy-Tree([string]$Source,[string]$Destination,$Expected) {
  if(Test-Path -LiteralPath $Destination){throw "Copy destination already exists: $Destination"}
  Assert-NoReparseAncestors $Destination
  New-Item -ItemType Directory -Path $Destination | Out-Null
  foreach($dir in @($Expected.directories)){[IO.Directory]::CreateDirectory((Join-Path $Destination $dir)) | Out-Null}
  foreach($file in @($Expected.files)){
    $from=Join-Path $Source $file.path;$to=Join-Path $Destination $file.path
    if(!(Inside $from $Source) -or !(Inside $to $Destination)){throw 'Copy path escaped its root'}
    [IO.File]::Copy($from,$to,$false)
  }
  Compare-Trees $Expected (Tree $Destination) 'Copied tree'
}
function Validate-Snapshot([string]$Root) {
  $all=Tree $Root
  $manifestPath=Join-Path $Root 'snapshot.json'
  if((Hash $manifestPath) -ne $expectedSnapshotSha){throw 'Frozen run6eb snapshot manifest SHA mismatch'}
  $manifest=Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
  if($manifest.schemaVersion -ne 1 -or $manifest.kind -ne 'tdx-browser-sample' -or $manifest.cutoff -ne '2026-09-16' -or @($manifest.files).Count -ne 6){throw 'Frozen snapshot schema/kind/cutoff/file count mismatch'}
  $allowed=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
  [void]$allowed.Add('snapshot.json')
  foreach($row in $manifest.files){
    $rel=[string]$row.path
    if($rel -match '(^[\\/]|:|(^|[\\/])\.\.?([\\/]|$))' -or !$allowed.Add($rel)){throw "Unsafe/duplicate snapshot path: $rel"}
    if([string]$row.sha256 -notmatch '^[a-f0-9]{64}$'){throw 'Invalid snapshot file SHA'}
    $file=Join-Path $Root $rel
    if(!(Inside $file $Root) -or !(Test-Path -LiteralPath $file -PathType Leaf)){throw "Snapshot file missing/escaped: $rel"}
    if((Get-Item -LiteralPath $file).Length -ne [long]$row.bytes -or (Hash $file) -ne $row.sha256){throw "Frozen snapshot data mismatch: $rel"}
  }
  if(@($all.files).Count -ne $allowed.Count){throw 'Frozen snapshot contains unlisted files'}
  foreach($row in $all.files){if(!$allowed.Contains($row.path)){throw "Unlisted snapshot file: $($row.path)"}}
  return [pscustomobject]@{tree=$all;manifest=$manifest;manifestSha256=$expectedSnapshotSha}
}
function Extract-NewZip([string]$Zip,[string]$Destination) {
  if(Test-Path -LiteralPath $Destination){throw "Fresh extraction destination already exists: $Destination"}
  Assert-NoReparseAncestors $Destination
  New-Item -ItemType Directory -Path $Destination | Out-Null
  $archive=[IO.Compression.ZipFile]::OpenRead($Zip)
  try {
    $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach($entry in $archive.Entries){
      $name=$entry.FullName
      if(!$name -or $name.Contains('\') -or $name.Contains(':') -or $name.StartsWith('/') -or $name -match '(^|/)\.\.?(/|$)' -or $name.Contains('//')){throw "Unsafe ZIP entry: $name"}
      $key=$name.TrimEnd('/')
      if(!$key -or !$seen.Add($key)){throw "Duplicate ZIP entry: $name"}
      $attrs=[int64]$entry.ExternalAttributes -band 4294967295L
      $unixType=($attrs -shr 16) -band 61440
      if($unixType -eq 40960 -or ($attrs -band 1024) -ne 0){throw "ZIP reparse/symlink refused: $name"}
      $to=Join-Path $Destination $name
      if(!(Inside $to $Destination)){throw "ZIP entry escaped extraction: $name"}
      Assert-NoReparseAncestors $to
      if($name.EndsWith('/')){[IO.Directory]::CreateDirectory($to) | Out-Null;continue}
      [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($to)) | Out-Null
      $entryStream=$entry.Open();$fileStream=[IO.File]::Open($to,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
      try{$entryStream.CopyTo($fileStream)}finally{$fileStream.Dispose();$entryStream.Dispose()}
    }
  } finally {$archive.Dispose()}
}
try {
  $RepoRoot=Full-Path $RepoRoot;$ProductionRoot=Full-Path $ProductionRoot;$EvidenceRoot=Full-Path $EvidenceRoot;$DeliveryRoot=Full-Path $DeliveryRoot;$SourceCommit=$SourceCommit.ToLowerInvariant()
  if(!(Same-Path $DeliveryRoot $expectedDelivery)){throw 'DeliveryRoot differs from the explicitly authorized stable M9 destination'}
  if(Test-Path -LiteralPath $DeliveryRoot){throw "Refusing to overwrite existing DeliveryRoot: $DeliveryRoot"}
  if((Inside $EvidenceRoot $DeliveryRoot) -or (Same-Path $EvidenceRoot $DeliveryRoot) -or (Inside $EvidenceRoot $ProductionRoot) -or (Same-Path $EvidenceRoot $ProductionRoot)){throw 'EvidenceRoot must stay outside delivery and production trees'}
  foreach($inputPath in @($RepoRoot,$ProductionRoot,$EvidenceRoot,$DeliveryRoot,$knownSnapshot)){Assert-NoReparseAncestors $inputPath}
  $receipt.sourceBefore=Assert-CleanSource 'before assembly'
  $receipt.scriptSha256=Hash $scriptSelf
  $packageJson=Join-Path $RepoRoot 'package.json'
  $version=[string](Get-Content -LiteralPath $packageJson -Raw | ConvertFrom-Json).version
  if($version -notmatch '^\d+\.\d+\.\d+([+-][a-zA-Z0-9.-]+)?$'){throw "Invalid source version: $version"}
  $unpacked=Join-Path $ProductionRoot 'win-unpacked'
  $releaseManifestPath=Join-Path $ProductionRoot 'release-manifest.json'
  if(!(Test-Path -LiteralPath $releaseManifestPath -PathType Leaf)){throw 'Production release-manifest.json missing'}
  $releaseManifest=Get-Content -LiteralPath $releaseManifestPath -Raw | ConvertFrom-Json
  if([string]$releaseManifest.version -ne $version){throw 'Production release-manifest version differs from source package.json'}
  $appTree=Tree $unpacked
  if(@($appTree.files).Count -eq 0){throw 'win-unpacked is empty'}
  foreach($required in @('K线训练器.exe','resources/app.asar','resources/app-update.yml','resources/migration-export-inline.html','resources/migration-import-recordings.js')){if(!(Test-Path -LiteralPath (Join-Path $unpacked $required) -PathType Leaf)){throw "Production payload missing: $required"}}
  $snapshot=Validate-Snapshot $knownSnapshot
  $wrappers=@('Start-Acceptance.cmd','Start-Acceptance.ps1')
  $wrapperRows=@(foreach($name in $wrappers){$source=Join-Path $RepoRoot ('scripts/acceptance/'+$name);Assert-NoReparseAncestors $source;if(!(Test-Path -LiteralPath $source -PathType Leaf)){throw "Wrapper missing: $source"};[pscustomobject]@{name=$name;source=$source;sha256=(Hash $source);bytes=(Get-Item -LiteralPath $source).Length}})
  # Every source and manifest is validated before creating the stable destination.
  if(Test-Path -LiteralPath $DeliveryRoot){throw 'DeliveryRoot appeared during preflight; refusing overwrite'}
  $evidenceName='zip-assembly-'+$SourceCommit.Substring(0,8)+'-'+[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ')
  $assemblyEvidence=Join-Path $EvidenceRoot $evidenceName
  if(Test-Path -LiteralPath $assemblyEvidence){throw 'Assembly evidence directory already exists'}
  New-Item -ItemType Directory -Path $assemblyEvidence | Out-Null
  New-Item -ItemType Directory -Path $DeliveryRoot | Out-Null
  $packageRoot=Join-Path $DeliveryRoot 'M9-ENABLE-01'
  New-Item -ItemType Directory -Path $packageRoot | Out-Null
  $receipt.repoRoot=$RepoRoot;$receipt.productionRoot=$ProductionRoot;$receipt.sourceCommit=$SourceCommit;$receipt.sourceVersion=$version;$receipt.deliveryRoot=$DeliveryRoot;$receipt.evidenceRoot=$assemblyEvidence;$receipt.packageRoot=$packageRoot
  Write-Json (Join-Path $assemblyEvidence 'production-input-files.json') $appTree
  Write-Json (Join-Path $assemblyEvidence 'snapshot-input-files.json') $snapshot
  Copy-Tree $unpacked (Join-Path $packageRoot 'app') $appTree
  Copy-Tree $knownSnapshot (Join-Path $packageRoot 'sample-market') $snapshot.tree
  $copiedSnapshot=Validate-Snapshot (Join-Path $packageRoot 'sample-market')
  foreach($row in $wrapperRows){[IO.File]::Copy($row.source,(Join-Path $packageRoot $row.name),$false);if((Hash (Join-Path $packageRoot $row.name)) -ne $row.sha256){throw "Wrapper copy differs: $($row.name)"}}
  $identity=[ordered]@{
    schemaVersion=1;kind='M9-ENABLE-01-production-acceptance';preparedAt=[DateTime]::UtcNow.ToString('o');sourceCommit=$SourceCommit;sourceVersion=$version;sourcePackageSha256=(Hash $packageJson)
    sourceCheckout=$RepoRoot;productionRoot=$ProductionRoot;releaseManifestSha256=(Hash $releaseManifestPath);releaseManifestVersion=$releaseManifest.version
    sourceAssociation='Caller-declared build commit plus clean checkout and byte identities; separate build receipt/runtime acceptance required'
    app=[ordered]@{path='app/K线训练器.exe';exeSha256=(Hash (Join-Path $packageRoot 'app/K线训练器.exe'));asarSha256=(Hash (Join-Path $packageRoot 'app/resources/app.asar'));fileCount=@($appTree.files).Count}
    sampleMarket=[ordered]@{source=$knownSnapshot;frozenRun='run-6eb1ecab-8032-4fac-a5bb-80aa2dc58a2b';cutoff=$snapshot.manifest.cutoff;manifestSha256=$expectedSnapshotSha;dataFileCount=6}
    wrappers=$wrapperRows;fileManifest='file-hashes.json';fileManifestSelfHash='Excluded from itself; covered by external payload-tree/ZIP SHA receipt';runtimeAcceptance='not run';visualAcceptance='pending root review';userAcceptance='pending';publication='not authorized'
  }
  Write-Json (Join-Path $packageRoot 'acceptance-identity.json') $identity
  $beforeManifest=Tree $packageRoot
  $fileManifest=[ordered]@{schemaVersion=1;algorithm='SHA256';sourceCommit=$SourceCommit;selfExcluded='file-hashes.json';files=@($beforeManifest.files);directories=@($beforeManifest.directories)}
  Write-Json (Join-Path $packageRoot 'file-hashes.json') $fileManifest
  $payloadTree=Tree $packageRoot
  Write-Json (Join-Path $assemblyEvidence 'payload-tree.json') $payloadTree
  $zipName='kline-trainer-M9-ENABLE-01-v'+$version+'-'+$SourceCommit.Substring(0,8)+'-windows-x64.zip'
  $zipPath=Join-Path $DeliveryRoot $zipName
  if(Test-Path -LiteralPath $zipPath){throw 'ZIP already exists'}
  [IO.Compression.ZipFile]::CreateFromDirectory($packageRoot,$zipPath,[IO.Compression.CompressionLevel]::Optimal,$false)
  $zipSha=Hash $zipPath
  [IO.File]::WriteAllText(($zipPath+'.sha256'),($zipSha+'  '+$zipName+[Environment]::NewLine),$utf8)
  $extraction=Join-Path $DeliveryRoot 'zip-roundtrip'
  Extract-NewZip $zipPath $extraction
  $roundtrip=Tree $extraction
  Compare-Trees $payloadTree $roundtrip 'Fresh ZIP roundtrip'
  if((Hash $zipPath) -ne $zipSha){throw 'ZIP changed during fresh-extraction verification'}
  $extractedManifest=Get-Content -LiteralPath (Join-Path $extraction 'file-hashes.json') -Raw | ConvertFrom-Json
  $extractedExceptSelf=[pscustomobject]@{files=@($roundtrip.files | Where-Object {$_.path -ne 'file-hashes.json'});directories=@($roundtrip.directories)}
  Compare-Trees $extractedManifest $extractedExceptSelf 'Extracted internal file manifest'
  $receipt.sourceAfter=Assert-CleanSource 'after assembly'
  $receipt.zip=[ordered]@{path=$zipPath;bytes=(Get-Item -LiteralPath $zipPath).Length;sha256=$zipSha;sha256File=$zipPath+'.sha256'}
  $receipt.identitySha256=Hash (Join-Path $packageRoot 'acceptance-identity.json');$receipt.fileManifestSha256=Hash (Join-Path $packageRoot 'file-hashes.json')
  $receipt.payloadFileCount=@($payloadTree.files).Count;$receipt.freshExtraction=$extraction;$receipt.freshExtractionFileCount=@($roundtrip.files).Count;$receipt.roundtripEveryFileMatched=$true;$receipt.reparsePointsAllowed=$false;$receipt.wrappers=$wrapperRows;$receipt.sampleManifestSha256=$expectedSnapshotSha;$receipt.finishedAt=[DateTime]::UtcNow.ToString('o');$receipt.passed=$true
  Write-Json (Join-Path $assemblyEvidence 'assembly-result.json') $receipt
  Write-Json (Join-Path $DeliveryRoot 'assembly-result.json') $receipt
  Write-Output ($receipt | ConvertTo-Json -Depth 8)
} catch {
  $receipt.failure=$_.Exception.ToString();$receipt.finishedAt=[DateTime]::UtcNow.ToString('o')
  if($assemblyEvidence -and (Test-Path -LiteralPath $assemblyEvidence)){Write-Json (Join-Path $assemblyEvidence 'assembly-result.json') $receipt}
  throw
}
