# CMD loopback探针误报与v2候选

只操作外部cache，未运行产品smoke或启动应用；未终止任何产品进程。PID71272及port13735只读查询显示当前PID不存在、端口连接0行，不能凭稍后的状态直接改写原05:00:15失败收据。

## 受控根因复现

从原m9-zip-smoke.ps1的AST精确抽取原Test-LoopbackPort，未执行脚本主体。仅创建127.0.0.1随机自有listener，先开放、再Stop，对同端口各运行3次原函数；另用与v3相同Node socket/750ms/ECONNREFUSED三态语义交叉。

原函数的Wait(750)未完成分支直接return true，所以将“尚未知”写成“确实开放”。受控端口14292开放时3/3 true（0至12ms）；listener Stop后原函数仍3/3 true（757至764ms），详细态Connected=false、TaskStatus=WaitingForActivation、Wait750=false。Node对应开放2ms=open，关闭2ms=ECONNREFUSED/closed，原生退出均0。证据controlled-positive-negative.json，完整输出controlled-probe.raw.log。

这动态证明了原probe在本机Windows/.NET环境能把已关闭的自有端口误报为open，且错误分支与smoke唯一阻断断言一致。没有原05:00:15各次连接诊断，仍不补造当时端口已关闭的历史事实。

## v2仅替换探针候选

候选：C:/Users/Stark_Du666/.codex/headroom-cache/M9-acceptance-brief/m9-zip-smoke.v2.ps1。
SHA256：2792b8b945ab097f2504acf19d20959636ca6d34900bf1ac7899391f311083f0。

只替换Test-LoopbackPort，函数之外前后字节完全一致，原v1未改；全部exe/wrapper/profile/health/sample身份、原生关闭及退出断言、30s关闭等待、10s端口释放窗口、250ms轮询与750ms单连接预算保留。证据v2-preservation.json及v2-v1.diff。

新函数用Node TCP语义：连接成功=open(true)；只有ECONNREFUSED=closed(false)；750ms超时或其他错误=unknown，抛错保持失败。Node命令非0、JSON解析或port/budget不符也保持失败，不把未知改false换绿。

PowerShell Parser错误0。只抽取v2函数做同自有listener正负控制，开放3/3 true、关闭3/3 false；同样保留.NET诊断（仍表现750ms pending），Node对照开放/关闭均可正确区分。证据v2-controlled-positive-negative.json。未运行真实CMD/APP，因此v2是已通过探针正负控制的工具候选，不能宣布产品smoke已通过。

v4导出脚本与本候选互相独立：前者只显式acceptDownloads，后者只改CMD外部验收端口oracle。两条真实验证仍需fresh extraction与独立收据，历史失败均保留。

补充：Windows PowerShell 5.1首尝试因Node --eval内双引号的旧参数传递规则失败，错误保留于v2-controlled-ps51.raw.log；最终只改为JS单引号字面量，PS5.1正反控制原生0，开放3/3true、关闭3/3false，见v2-controlled-positive-negative.ps51.json。最终候选哈希如上。已获主代理授权启动新的fresh ZIP真实CMD冒烟，结果另见real-cmd-smoke-v2.receipt.json，不覆盖首轮失败。


真实CMD v2复跑：新fresh ZIP SHA c74a53bf5f4c3a036c2c23a88ff24bbbe7d63ef43f38ff5d88734a636e23629c；2026-11-18 05:21:08至05:21:29，外层powershell.exe原生0，产品PID73076/port2009，app_exit0。receipt为M9-final-run-f9454fe/cmd-smoke-v2/zip-launcher-smoke.json。原脚本记录launcher_exit=null并按原有允许null的契约通过，不能补写launcher_exit0。应用可见窗口、profile/DB/health/sample检查及实际关闭通过，后续PID不存在；TCP表有OwningProcess0的State11残留，不能把TCP表非空等同端口仍监听。未强杀或覆盖旧失败。
