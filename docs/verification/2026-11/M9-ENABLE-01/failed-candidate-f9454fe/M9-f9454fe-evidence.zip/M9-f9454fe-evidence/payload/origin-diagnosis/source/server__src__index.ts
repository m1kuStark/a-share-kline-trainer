import Fastify from 'fastify'
import staticFiles from '@fastify/static'
import { registerApi } from './api.js'
import { registerSetupControlApi } from './setup/control-api.js'
import { createDrainController, type DrainController } from './setup/drain-controller.js'
import { getActiveTraining } from './train/engine.js'
import { loadConfig } from './config.js'
import { ensureDatabaseDirectory, migrateDatabase, openDatabase } from './db.js'
import { seedBuiltinFormulas } from './formulas/seed.js'
import { registerUpdateApi } from './update/api.js'
import { registerDiagnosticsApi } from './diagnostics/api.js'
import { reconcileUpdateStatus, resolveStaleBusyMs } from './update/status.js'
import { serverVersion } from './update/version.js'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { spawn } from 'node:child_process'
import { writeFile, rename, rm } from 'node:fs/promises'
import { randomUUID } from 'node:crypto'

/**
 * PACK-01：服务入口双形态。startTrainerServer() 供进程内嵌入（Electron 主进程等）
 * 调用——完成 loadConfig→建库迁移→Fastify 组装→listen 并返回句柄；直接以 CLI 运行
 * （node server/dist/index.js / tsx server/src/index.ts）时维持原有顶层行为：
 * ready 文件、SIGINT/SIGTERM、trainer:shutdown IPC、disconnect、浏览器打开语义不变。
 * 行为保持的证据＝server/test/setup-control-process.test.ts（真实子进程闭环）。
 */
export interface StartedTrainerServer {
  app: ReturnType<typeof Fastify>
  config: Awaited<ReturnType<typeof loadConfig>>
  url: string
  port: number
  shutdown(): Promise<void>
  /**
   * PACK-02 优雅退出接线：SETUP-01 冻结排空控制器本体。进程内宿主（Electron 主进程）
   * 复用同一排空语义（prepare→shutdown）的通道——不新造退出协议；HTTP 控制端点的严格
   * 守卫（拒活动训练）面向一次性助手，进程内宿主走 in-app 退出口径（allowActiveTraining）。
   */
  drain: DrainController
}

export async function startTrainerServer(): Promise<StartedTrainerServer> {
  const config = await loadConfig()
  await ensureDatabaseDirectory(config.databasePath)
  const database = openDatabase(config.databasePath)
  migrateDatabase(database)
  // M9-04D：内置示例公式幂等 seed（失败不阻断启动；公式库/接口仍可用，UI 可手动新建）
  try {
    const seeded = seedBuiltinFormulas(database)
    if (seeded > 0) console.log('[formulas] seeded ' + seeded + ' builtin example(s)')
  } catch (error) {
    console.error('[formulas] builtin seed failed:', error instanceof Error ? error.message : error)
  }

  const app = Fastify({ logger: true })
  app.addHook('onRequest', async (request, reply) => {
    if (!/^(?:127\.0\.0\.1|localhost|\[::1\])(?::\d{1,5})?$/.test(request.headers.host ?? '')) {
      return reply.code(403).send({ error: '训练器仅接受本机地址访问', code: 'LOCAL_HOST_REQUIRED' })
    }
    const site = request.headers['sec-fetch-site']
    if (site !== undefined && site !== 'same-origin' && site !== 'none') {
      return reply.code(403).send({ error: '此请求不来自训练器页面', code: 'LOCAL_ORIGIN_REQUIRED' })
    }
    if (request.headers.origin !== undefined && request.headers.origin !== `http://${request.headers.host}`) {
      return reply.code(403).send({ error: '此请求不来自训练器页面', code: 'LOCAL_ORIGIN_REQUIRED' })
    }
  })
  const drainController = createDrainController({
    getActiveTraining: () => getActiveTraining(database),
  })
  // UPD-01（UPD-VERSION-EXPOSE）：currentVersion 来自包根 package.json（构建时写入），
  // 不改 status/runId/pid 三身份字段（launcher isTrainerHealth 只认这三者）。
  app.get('/api/health', async () => ({ status: 'ok', runId: config.runId ?? null, pid: process.pid, currentVersion: serverVersion() }))
  // DIAG-OPLOG-01：本地操作日志（事件面/读取面 + /api/** onResponse 自动记录），只落本机。
  const diagnostics = registerDiagnosticsApi(app, config)
  await registerApi(app, config, database, {
    drain: drainController.gate,
    // REL-LAUNCH-UX-01：页面"保存并退出"与控制桥共用同一冻结排空实现与真实关闭函数
    lifecycle: { controller: drainController, shutdown: () => shutdown() },
  })
  // UPD-01 在线更新端点（check/apply/status）；活跃训练查询复用业务口径
  await registerUpdateApi(app, config, { getActiveTraining: () => getActiveTraining(database) })
  // UPD-BUSY-HEAL-01：启动期 reconcile——上次更新流程被杀（杀软误杀 detached 更新器、
  // 断电等已知根因）残留的陈旧 busy 状态就地复位 failed（人话原因落日志），在线更新
  // 通道不再自锁；restarting→completed 既有路径在 reconcile 内先行，不受影响。
  // best-effort：复位失败不阻断启动（apply/status 读路径会再次尝试自愈）。
  await reconcileUpdateStatus(config.dataDir, serverVersion(), { staleBusyMs: resolveStaleBusyMs(process.env), log: console })
    .catch(error => { console.error(`[update] 启动期陈旧 busy 自愈失败（忽略，启动继续）：${error instanceof Error ? error.message : String(error)}`) })
  await registerSetupControlApi(app, {
    controller: drainController,
    config,
    shutdown: () => shutdown(),
  })
  app.addHook('onClose', async () => { drainController.gate.close() })

  const serverDirectory = dirname(fileURLToPath(import.meta.url))
  const webDirectory = config.staticDirectory ?? join(serverDirectory, '..', '..', 'web', 'dist')
  // wildcard 模式：按请求读文件，rebuild 换 hash 后无需重启即可服务新资产
  await app.register(staticFiles, { root: webDirectory })

  let closing: Promise<void> | undefined
  async function shutdown() {
    return closing ??= (async () => {
      await app.close()
      await diagnostics.log.flush()
      database.close()
      if (config.readyFile) await rm(config.readyFile, { force: true })
      if (process.connected) process.disconnect()
    })()
  }

  const url = await app.listen({ port: config.port, host: config.host })
  const address = app.server.address()
  if (!address || typeof address === 'string') throw new Error('Server did not bind a TCP port')
  void diagnostics.log.append({
    type: 'lifecycle', action: 'server.started', source: 'server',
    data: { version: serverVersion(), port: address.port },
  })
  return { app, config, url, port: address.port, shutdown, drain: drainController }
}

/** 直接以进程入口运行本文件（而非被 import）时才执行 CLI 行为。 */
function isCliInvocation(): boolean {
  const entry = process.argv[1]
  if (!entry) return false
  try {
    return import.meta.url === pathToFileURL(resolve(entry)).href
  } catch {
    return false
  }
}

if (isCliInvocation()) {
  const started = await startTrainerServer()
  const { config, port, url } = started
  const shutdown = () => started.shutdown()
  if (config.readyFile) {
    const temporary = `${config.readyFile}.${randomUUID()}.tmp`
    await writeFile(temporary, JSON.stringify({ runId: config.runId ?? null, pid: process.pid, baseURL: url, port }), { flag: 'wx' })
    await rename(temporary, config.readyFile)
  }
  console.log(`A-share K-line trainer server listening at ${url}`)

  for (const signal of ['SIGINT', 'SIGTERM'] as const) {
    process.once(signal, () => { void started.shutdown().catch(error => { console.error(error); process.exitCode = 1 }) })
  }
  process.on('message', message => {
    if (message && typeof message === 'object' && 'type' in message && 'runId' in message
      && message.type === 'trainer:shutdown' && message.runId === config.runId) {
      void started.shutdown().catch(error => { console.error(error); process.exitCode = 1 })
    }
  })
  process.once('disconnect', () => { void started.shutdown().catch(error => { console.error(error); process.exitCode = 1 }) })

  if (process.env.OPEN_BROWSER !== '0' && !process.env.VITEST) {
    const command = process.platform === 'win32' ? 'cmd' : process.platform === 'darwin' ? 'open' : 'xdg-open'
    const args = process.platform === 'win32' ? ['/c', 'start', '', url] : [url]
    const child = spawn(command, args, { detached: true, stdio: 'ignore', windowsHide: true })
    child.unref()
  }
}
