# v4 packaged recording and restart evidence review

Verdict: the observed receipt and script support a real UI export, local-library replay and persistence across a real process restart on the same origin. The exported file itself was not imported/replayed, so an exported-file round-trip is outside this evidence.

The script SHA matches the receipt. The gzip SHA matches, parses as schema 2, and contains eight gap-free events (one accepted buy plus three accepted advances), eleven checkpoints and complete=true. Offline reference checks reconstruct all four chart series, validate account arithmetic and resolve checkpoint resources. Four action checkpoints have chart=null and subsequent same-sequence checkpoints carry full chart state.

Both boots report normal exits, the same origin, SQLite path, Chromium profile and recording namespace, with different product PIDs/runIds. Both replay DOM snapshots progress from 2025-01-02 to 2025-01-03 and are byte-equal at matching positions across boots. The saved row has ten events because settlement occurs after the eight-event export.

The script checks UI day progression and a non-empty replay chart. It does not verify all replay frames or numerical chart fidelity against the gzip, and does not prove CMD, installer, upgrade, visual or user acceptance. Recording app.version remains unknown; gitCommit matches f945 while packaged identity is 1.3.8.

See review.receipt.json for hashes, individual offline assertions and exact script line references. No repository, control, matrix, GitHub, application or database changes were made by this review.
