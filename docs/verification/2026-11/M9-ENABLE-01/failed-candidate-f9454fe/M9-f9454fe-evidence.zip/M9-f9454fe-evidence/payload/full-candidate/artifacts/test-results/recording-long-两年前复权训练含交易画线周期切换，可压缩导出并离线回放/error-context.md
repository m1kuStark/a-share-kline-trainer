# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: recording-long.spec.ts >> 两年前复权训练含交易画线周期切换，可压缩导出并离线回放
- Location: e2e\recording-long.spec.ts:26:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary "主导航" [ref=e4]:
    - generic [ref=e5]: K
    - navigation [ref=e6]:
      - button "训练" [ref=e7] [cursor=pointer]
      - button "历史排行" [ref=e13] [cursor=pointer]:
        - generic [ref=e20]: 排行
      - button "历史训练" [ref=e21] [cursor=pointer]:
        - generic [ref=e26]: 历史
      - button "训练录像" [ref=e27] [cursor=pointer]:
        - generic [ref=e31]: 录像
    - button "保存并退出训练器" [ref=e32] [cursor=pointer]:
      - generic [ref=e35]: 退出
    - button "训练默认设置" [ref=e36] [cursor=pointer]:
      - generic [ref=e40]: 设置
  - main [ref=e41]:
    - generic [ref=e42]:
      - generic [ref=e43]: A股 K线训练器
      - generic [ref=e45]:
        - generic [ref=e47]:
          - generic [ref=e48]:
            - checkbox "记录操作" [checked] [ref=e49]
            - text: 记录操作
          - status [ref=e50]: 正在记录 · 2 次操作
          - button "导出录制" [ref=e51] [cursor=pointer]
        - button "切换到浅色主题" [ref=e52] [cursor=pointer]
        - generic [ref=e60]: TDX · 截止 2026-09-16
    - generic [ref=e61]:
      - generic [ref=e62]:
        - generic [ref=e63]:
          - generic "贵州茅台 · 600519" [ref=e65]
          - generic [ref=e66]:
            - text: 当前
            - strong [ref=e67]: 2024-09-13
          - tablist "K线周期" [ref=e68]:
            - tab "日K" [selected] [ref=e69] [cursor=pointer]
            - tab "周K" [ref=e70] [cursor=pointer]
            - tab "月K" [ref=e71] [cursor=pointer]
          - group "副图指标开关" [ref=e72]:
            - button "VOL" [pressed] [ref=e73] [cursor=pointer]
            - button "MACD" [pressed] [ref=e74] [cursor=pointer]
            - button "KDJ" [pressed] [ref=e75] [cursor=pointer]
            - button "多空反转" [ref=e76] [cursor=pointer]
          - group [ref=e77]:
            - generic "训练详情" [ref=e78] [cursor=pointer]
        - generic [ref=e81]:
          - button "划线" [pressed] [ref=e82] [cursor=pointer]
          - button "日线数据更新：最新交易日待确认，点击重新读取本地日线" [ref=e86] [cursor=pointer]: 更新
          - button "刷新图表" [ref=e87] [cursor=pointer]
          - button "回到最新K线" [ref=e93] [cursor=pointer]
          - button "推进下一日" [ref=e96] [cursor=pointer]
          - button "提前结算" [ref=e99] [cursor=pointer]
          - button "放弃训练" [ref=e100] [cursor=pointer]
      - generic [ref=e101]:
        - generic "按该比例计算的金额不足一手" [ref=e102]
        - group "K线行情" [ref=e104]:
          - generic [ref=e105]: 日K 2024-09-13 周五
          - generic [ref=e106]: 开 1331.00
          - generic [ref=e107]: 高 1332.00
          - generic [ref=e108]: 低 1297.30
          - generic [ref=e109]: 收 1304.13
          - generic [ref=e110]: 日涨幅 -2.32%
          - generic [ref=e111]: 最近已知K线
        - generic "空格：推进下一日；[ / ]：日周月周期；Home：回到最新；↑ / ↓：缩放；Shift+← / →：平移视图；Del：删除选中画线；B / S：买入卖出；Ctrl+Z / Ctrl+Y：撤销重做。输入、弹窗和画线取点期间部分快捷键暂停。" [ref=e112]: 空格 下一日 · [ ] 周期 · Home 最新 · ↑↓ 缩放 · Shift←→ 平移 · Del 删线
        - generic [ref=e113]: 可见至 2024-09-13 周五
        - generic "当前同屏K线根数 / 同屏上限" [ref=e114]: 154 / 840 根
      - generic [ref=e115]:
        - generic [ref=e117]:
          - button "设置均线" [ref=e119] [cursor=pointer]: MA 设置
          - group "成交标记" [ref=e160]
        - complementary [ref=e161]:
          - generic [ref=e162]:
            - generic [ref=e163]:
              - generic [ref=e164]: 训练账户
              - generic [ref=e165]: ● 进行中
            - generic [ref=e166]:
              - generic [ref=e167]: 账户权益
              - strong [ref=e168]:
                - generic [ref=e169]: ¥123,456
              - emphasis [ref=e170]:
                - generic [ref=e171]: +0.00%
            - generic [ref=e172]:
              - generic [ref=e173]:
                - generic [ref=e174]: 可用资金
                - strong [ref=e175]: ¥123,456
              - generic [ref=e176]:
                - generic [ref=e177]: 持仓市值
                - strong [ref=e178]: ¥0
              - generic [ref=e179]:
                - generic [ref=e180]: 持仓（可卖）
                - strong [ref=e181]: 0（0）
              - generic [ref=e182]:
                - generic [ref=e183]: 摊薄成本
                - strong [ref=e184]: "--"
            - generic [ref=e186]:
              - tablist "下单方式" [ref=e187]:
                - tab "普通下单" [selected] [ref=e188] [cursor=pointer]
              - generic [ref=e189]: 按当日收盘价成交
            - generic [ref=e190]:
              - button "10%" [ref=e191] [cursor=pointer]
              - button "20%" [ref=e192] [cursor=pointer]
              - button "25%" [ref=e193] [cursor=pointer]
              - button "30%" [ref=e194] [cursor=pointer]
              - button "50%" [ref=e195] [cursor=pointer]
              - button "75%" [ref=e196] [cursor=pointer]
              - button "100%" [ref=e197] [cursor=pointer]
              - spinbutton "自定义%" [ref=e198]
            - generic [ref=e199]:
              - spinbutton "按股数买卖" [ref=e200]
              - generic [ref=e201]: 留空则按左侧比例
            - generic [ref=e202]:
              - button "买入" [active] [ref=e203] [cursor=pointer]
              - button "卖出" [ref=e204] [cursor=pointer]
          - generic [ref=e205]:
            - generic [ref=e206]:
              - button "折叠画线工具条" [expanded] [ref=e215] [cursor=pointer]
              - generic [ref=e218]: 常用工具
              - button "自定义常用" [ref=e219] [cursor=pointer]
              - button "固定工具面板" [ref=e223] [cursor=pointer]
            - generic [ref=e226]:
              - generic [ref=e227]:
                - button "线段" [ref=e229] [cursor=pointer]
                - button "射线" [ref=e236] [cursor=pointer]
                - button "直线" [ref=e243] [cursor=pointer]
                - button "水平直线" [ref=e248] [cursor=pointer]
                - button "垂直直线" [ref=e252] [cursor=pointer]
                - button "价位线" [ref=e256] [cursor=pointer]
                - button "百分比线" [ref=e260] [cursor=pointer]
              - button "其他工具 16" [expanded] [ref=e266] [cursor=pointer]:
                - text: 其他工具
                - generic [ref=e269]: "16"
              - generic [ref=e270]:
                - button "水平线段" [ref=e272] [cursor=pointer]
                - button "水平射线" [ref=e278] [cursor=pointer]
                - button "垂直线段" [ref=e284] [cursor=pointer]
                - button "垂直射线" [ref=e290] [cursor=pointer]
                - button "平行直线" [ref=e296] [cursor=pointer]
                - button "价格通道线" [ref=e302] [cursor=pointer]
                - button "斐波那契线" [ref=e308] [cursor=pointer]
                - button "画笔" [ref=e312] [cursor=pointer]
                - button "矩形" [ref=e317] [cursor=pointer]
                - button "圆圈" [ref=e322] [cursor=pointer]
                - button "圆弧" [ref=e327] [cursor=pointer]
                - button "箭头线" [ref=e332] [cursor=pointer]
                - button "看涨箭头" [ref=e338] [cursor=pointer]
                - button "看跌箭头" [ref=e344] [cursor=pointer]
                - button "诅咒线" [ref=e350] [cursor=pointer]
                - button "文本" [ref=e355] [cursor=pointer]
            - generic [ref=e359]:
              - button "多选" [ref=e360] [cursor=pointer]
              - button "撤销" [disabled] [ref=e361]
              - button "重做" [disabled] [ref=e365]
              - button "清空" [ref=e369] [cursor=pointer]
              - combobox "吸附" [ref=e373]:
                - option "关闭"
                - option "弱吸附" [selected]
                - option "强吸附"
            - status "已保存" [ref=e375]
            - separator "调整工具面板尺寸（拖动调整宽高，双击恢复默认）" [ref=e376]
```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test'
  2   | import { readFile, stat, writeFile } from 'node:fs/promises'
  3   | import { CompactReader } from '../web/src/recording/compactCodec'
  4   | import { startTrainingFromForm, expectSettledResultsDialog } from './training-flow'
  5   | import { evidencePath } from './runtime'
  6   | import { readRecordingArtifact } from './recording-file'
  7   | 
  8   | // 30min 超长真实回放测试：关闭 trace 录制，避免逐动作 trace 增长反过来拖慢测试（断言不变）
  9   | test.use({ trace: 'off' })
  10  | 
  11  | async function exported(page: Page, button: string, name: string) {
  12  |   const started = Date.now()
  13  |   const pending = page.waitForEvent('download')
  14  |   await page.getByRole('button', { name: button, exact: true }).click()
  15  |   const download = await pending
  16  |   const path = evidencePath(name)
  17  |   await download.saveAs(path)
  18  |   const bytes = await readFile(path)
  19  |   expect([...bytes.subarray(0, 2)]).toEqual([0x1f, 0x8b])
  20  |   const file = await readRecordingArtifact(path)
  21  |   expect(file.schemaVersion).toBe(2)
  22  |   if (file.schemaVersion !== 2) throw Error('Expected compact recording')
  23  |   return { file, path, durationMs: Date.now() - started }
  24  | }
  25  | 
  26  | test('两年前复权训练含交易画线周期切换，可压缩导出并离线回放', async ({ page }) => {
  27  |   test.setTimeout(30 * 60 * 1000)
  28  |   const active = (await (await page.request.get('/api/trainings/active')).json()).training
  29  |   if (active) await page.request.post(`/api/trainings/${active.id}/abandon`)
  30  |   const pageErrors: string[] = []
  31  |   page.on('pageerror', error => pageErrors.push(error.message))
  32  |   await page.goto('/')
  33  |   await page.getByPlaceholder('股票代码，如 600519').fill('600519')
  34  | await expect(page.locator(".suggestions button").first()).toBeVisible()
  35  | await page.locator(".suggestions button").first().click()
  36  |   await expect(page.getByText(/已选：/)).toBeVisible()
  37  |   await page.getByRole('button', { name: '2年', exact: true }).click()
  38  |   await page.locator('input[type="date"]').fill('2024-09-13')
  39  |   // 全量套件共享设置库：前置用例可能改过初始资金；本用例需要一手可成交，先固定默认初始资金并保存
  40  |   const trainingDefaults = await (await page.request.get('/api/settings/training')).json() as Record<string, unknown>
  41  |   const defaultsPut = await page.request.put('/api/settings/training', {
  42  |     data: {
  43  |       feesEnabled: trainingDefaults.feesEnabled ?? false,
  44  |       tPlusOne: trainingDefaults.tPlusOne ?? true,
  45  |       initialCash: 1_000_000,
  46  |       adjustMode: trainingDefaults.adjustMode ?? 'forward',
  47  |       commissionRate: trainingDefaults.commissionRate ?? 0.00025,
  48  |       minimumCommission: trainingDefaults.minimumCommission ?? 5,
  49  |       stampDutyRate: trainingDefaults.stampDutyRate ?? 0.0005,
  50  |     },
  51  |   })
  52  |   expect(defaultsPut.status()).toBe(200)
  53  |   await startTrainingFromForm(page)
  54  |   const recording = page.getByRole('status').filter({ hasText: '正在记录' })
  55  |   await expect(recording).toBeVisible()
  56  |   // Fail early against the old implementation, before the costly two-year journey.
  57  |   const initialRecording = await exported(page, '导出录制', 'two-year-initial.json.gz')
  58  |   await page.getByRole('button', { name: '买入', exact: true }).click()
  59  |   // 满载启动窗口内首次点击可能落在按钮可用前；重试一次并必须确认成交，后续卖出断言才有持仓可卖
  60  |   let initialBuyFilled = false
  61  |   for (let attempt = 0; attempt < 2; attempt += 1) {
  62  |     if (attempt > 0) await page.getByRole('button', { name: '买入', exact: true }).click()
  63  |     const filled = await expect(page.locator('.status-message')).toContainText('成交', { timeout: 10_000 }).then(() => true, () => false)
  64  |     if (filled) { initialBuyFilled = true; break }
  65  |   }
> 66  |   expect(initialBuyFilled).toBe(true)
      |                            ^ Error: expect(received).toBe(expected) // Object.is equality
  67  |   await expect(page.getByRole('button', { name: '刷新图表', exact: true })).toBeEnabled()
  68  |   await page.getByRole('button', { name: '卖出', exact: true }).click()
  69  |   await expect(page.locator('.status-message')).toHaveClass(/error-text/)
  70  |   await page.locator('.draw-toolbar').getByRole('button', { name: '线段', exact: true }).click()
  71  |   const box = await page.locator('.chart-host').boundingBox()
  72  |   await page.mouse.click(box!.x + box!.width * .35, box!.y + 140)
  73  |   await page.waitForTimeout(550)
  74  |   await page.mouse.click(box!.x + box!.width * .55, box!.y + 180)
  75  |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.drawings().length)).toBe(1)
  76  |   await expect(page.locator('.drawing-save-status')).toHaveText('已保存')
  77  |   const advanceTimes: number[] = []
  78  |   let finalSnapshot: any = null
  79  |   for (let count = 1; count <= 510; count++) {
  80  |     const started = Date.now()
  81  |     const response = page.waitForResponse(r => /\/api\/trainings\/\d+\/next$/.test(r.url()) && r.request().method() === 'POST', { timeout: 20_000 })
  82  |     await page.getByRole('button', { name: '推进下一日', exact: true }).click()
  83  |     const result = await (await response).json()
  84  |     expect(result.snapshot).toBeTruthy()
  85  |     finalSnapshot = result.snapshot
  86  |     await expect(page.getByRole('button', { name: '刷新图表', exact: true })).toBeEnabled()
  87  |     await expect(recording).toBeVisible()
  88  |     advanceTimes.push(Date.now() - started)
  89  |     if (result.settled) break
  90  |     if (count === 1) {
  91  |       await page.getByRole('button', { name: '卖出', exact: true }).click()
  92  |       await expect(page.locator('.status-message')).toContainText('成交')
  93  |       await expect(page.getByRole('button', { name: '刷新图表', exact: true })).toBeEnabled()
  94  |     }
  95  |     if (count % 60 === 0) {
  96  |       for (const name of ['周K', '月K', '日K']) {
  97  |         await page.getByRole('tab', { name, exact: true }).click()
  98  |         await expect(page.getByRole('button', { name: '刷新图表', exact: true })).toBeEnabled()
  99  |       }
  100 |     }
  101 |     if (count === 240) {
  102 |       await page.reload()
  103 |       await expect(page.locator('.training-topbar')).toBeVisible({ timeout: 30_000 })
  104 |       await expect(recording).toBeVisible({ timeout: 30_000 })
  105 |     }
  106 |   }
  107 |   expect(finalSnapshot.training.status).toBe('settled')
  108 |   expect(advanceTimes.length).toBeGreaterThan(450)
  109 |   // 自然到期同样出现结算结果面板，「保留到本机训练历史」默认勾选（返修合同行为3）
  110 |   await expectSettledResultsDialog(page)
  111 |   const output = await exported(page, '导出本场录制', 'two-year-final.json.gz')
  112 |   const file = output.file
  113 |   expect(file.sessionId).toBe(initialRecording.file.sessionId)
  114 |   expect(file.events.filter(event => event.action === 'training.advance' && event.phase === 'started')).toHaveLength(advanceTimes.length)
  115 |   expect(file.gaps).toEqual([])
  116 |   const reader = new CompactReader(file)
  117 |   const last = reader.checkpointAt(file.checkpoints.length - 1)
  118 |   expect(last.training?.account).toEqual(finalSnapshot.account)
  119 |   // The chart query additionally supplies chartPrice in the current adjustment basis.
  120 |   const displayed = await (await page.request.get(`/api/trainings/${finalSnapshot.training.id}/bars?tf=1D`)).json()
  121 |   expect(last.training?.trades).toEqual(displayed.trades)
  122 |   expect(last.training?.trades.map(({ chartPrice: _chartPrice, ...trade }) => trade)).toEqual(finalSnapshot.trades)
  123 |   expect(last.chart?.drawings.length).toBe(1)
  124 |   expect(file.events.some(e => e.action === 'training.trade' && e.outcome === 'rejected')).toBe(true)
  125 |   for (let i = 0; i < file.checkpoints.length; i++) {
  126 |     const checkpoint = reader.checkpointAt(i)
  127 |     if (!checkpoint.chart) continue
  128 |     const cutoff = checkpoint.training!.training.currentDate!
  129 |     expect(checkpoint.chart.bars.every(bar => (bar.date.length === 7 ? `${bar.date}-01` : bar.date) <= cutoff)).toBe(true)
  130 |   }
  131 |   await page.getByRole('button', { name: '完成，返回首页', exact: true }).click()
  132 |   await page.getByRole('button', { name: '训练录像', exact: true }).click()
  133 |   await expect(page.getByRole('heading', { name: '训练录像', exact: true })).toBeVisible()
  134 |   await page.route('**/api/**', route => route.abort())
  135 |   const writes: string[] = []
  136 |   page.on('request', request => { const url = request.url(); if (/\/api\//.test(url) && ['POST','PUT','DELETE'].includes(request.method()) && !/\/api\/diagnostics\/events$/.test(url)) writes.push(url) })
  137 |   const importedAt = Date.now()
  138 |   await page.getByLabel('导入录制', { exact: true }).setInputFiles(output.path)
  139 |   // REC-03 按日回放：跳到最后一天后画线仍在，且 b/Delete/鼠标都改不动（只读）
  140 |   await page.getByRole('button', { name: '跳到最后一天' }).click()
  141 |   await expect(page.locator('.replay-day')).toHaveText(/第 \d+ \/ \d+ 日/)
  142 |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart?.drawings().length)).toBe(1)
  143 |   const importMs = Date.now() - importedAt
  144 |   await page.keyboard.press('b')
  145 |   await page.keyboard.press('Delete')
  146 |   await page.screenshot({ path: evidencePath('recording-two-year-replay.png') })
  147 |   expect(writes).toEqual([])
  148 |   expect(pageErrors).toEqual([])
  149 |   const sorted = [...advanceTimes].sort((a,b) => a-b)
  150 |   await writeFile(evidencePath('recording-two-year-metrics.json'), JSON.stringify({
  151 |     steps: advanceTimes.length, events: file.events.length, checkpoints: file.checkpoints.length,
  152 |     fileBytes: (await stat(output.path)).size, jsonBytes: Buffer.byteLength(JSON.stringify(file)),
  153 |     exportMs: output.durationMs, importMs, advanceP95Ms: sorted[Math.floor(sorted.length*.95)],
  154 |     restoredCheckpoints: file.checkpoints.length, unexpectedPageErrors: pageErrors,
  155 |   }, null, 2))
  156 | })
  157 | 
```