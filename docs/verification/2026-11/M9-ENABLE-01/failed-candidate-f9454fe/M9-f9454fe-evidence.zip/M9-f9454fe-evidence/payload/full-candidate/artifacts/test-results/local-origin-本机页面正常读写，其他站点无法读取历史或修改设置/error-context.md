# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: local-origin.spec.ts >> 本机页面正常读写，其他站点无法读取历史或修改设置
- Location: e2e\local-origin.spec.ts:6:1

# Error details

```
Error: page.goto: net::ERR_UNSAFE_PORT at http://127.0.0.1:3659/
Call log:
  - navigating to "http://127.0.0.1:3659/", waiting until "load"

```

# Page snapshot

```yaml
- generic [ref=f1e2]:
  - generic [ref=f1e6]:
    - heading "嗯… 无法访问此页面" [level=1] [ref=f1e7]
    - paragraph [ref=f1e8]:
      - strong [ref=f1e9]: http://127.0.0.1:3659/
      - text: 上的网页似乎有问题，或者可能已永久移动到新的 Web 地址。
    - generic [ref=f1e10]: ERR_UNSAFE_PORT
  - generic [ref=f1e12]: Microsoft Edge
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test'
  2  | import { createServer } from 'node:http'
  3  | import { once } from 'node:events'
  4  | import { runtime, evidencePath } from './runtime'
  5  | 
  6  | test('本机页面正常读写，其他站点无法读取历史或修改设置', async ({ page }) => {
  7  |   const run = runtime()
  8  |   const active = (await (await page.request.get('/api/trainings/active')).json()).training
  9  |   if (active) await page.request.post(`/api/trainings/${active.id}/abandon`)
  10 |   await page.request.put('/api/settings/app', { data: { autoDataCheck: true } })
  11 |   await page.goto('/')
  12 |   await expect(page.getByRole('button', { name: '开始训练', exact: true })).toBeVisible()
  13 |   expect(await page.evaluate(async () => (await fetch('/api/trainings/history')).status)).toBe(200)
  14 |   expect(await page.evaluate(async () => (await fetch('/api/settings/app', {
  15 |     method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ autoDataCheck: true }),
  16 |   })).status)).toBe(200)
  17 |   await page.screenshot({ path: evidencePath('origin-guard-legitimate-page.png') })
  18 | 
  19 |   const foreign = createServer((_request, response) => {
  20 |     response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' })
  21 |     response.end('<!doctype html><title>隔离外站夹具</title>外站来源验证')
  22 |   })
  23 |   foreign.listen(0, '127.0.0.1')
  24 |   await once(foreign, 'listening')
  25 |   try {
  26 |     const port = (foreign.address() as { port: number }).port
> 27 |     await page.goto(`http://127.0.0.1:${port}`)
     |                ^ Error: page.goto: net::ERR_UNSAFE_PORT at http://127.0.0.1:3659/
  28 |     const results = await page.evaluate(async baseURL => {
  29 |       const read = await fetch(`${baseURL}/api/trainings/history`).then(response => `read:${response.status}`, () => 'blocked')
  30 |       const write = await fetch(`${baseURL}/api/settings/app`, {
  31 |         method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ autoDataCheck: false }),
  32 |       }).then(response => `write:${response.status}`, () => 'blocked')
  33 |       return { read, write }
  34 |     }, run.baseURL!)
  35 |     expect(results).toEqual({ read: 'blocked', write: 'blocked' })
  36 |     expect((await (await page.request.get(`${run.baseURL}/api/settings/app`)).json()).autoDataCheck).toBe(true)
  37 |   } finally {
  38 |     await new Promise<void>((resolve, reject) => foreign.close(error => error ? reject(error) : resolve()))
  39 |   }
  40 | })
  41 | 
```