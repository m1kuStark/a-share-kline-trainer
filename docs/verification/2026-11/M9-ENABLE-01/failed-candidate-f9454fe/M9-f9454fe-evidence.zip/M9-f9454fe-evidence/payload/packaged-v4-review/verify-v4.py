import collections,datetime,gzip,hashlib,json,pathlib,sys
root=pathlib.Path(r'C:/Users/Stark_Du666/.codex/headroom-cache')
evidence=root/'M9-final-run-f9454fe'/'packaged-real-v4'
script=root/'M9-home-oracle-repair'/'m9-packaged-acceptance.v4.cjs'
out=root/'M9-packaged-v4-review'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text('utf-8'))
r=load(evidence/'acceptance-result.json')
x=json.loads(gzip.decompress((evidence/'actual-ui-recording.json.gz').read_bytes()))
checks=[]
def check(name,condition):
 checks.append({'name':name,'passed':bool(condition)})
 if not condition:raise AssertionError(name)
check('script identity matches run receipt',sha(script)==r['scriptSha256']=='902970cc9d8e8cd60378e332b9f77010d9f1ff5b1a7a71ad40861d88bc4a704f')
check('gzip identity matches run receipt',sha(evidence/'actual-ui-recording.json.gz')==r['recording']['sha256']=='820094bddfff22f3660538d66f0819bae7d102d55f687ca616e22e7d41cb2931')
check('receipt passed and no recorded renderer errors/dialogs',r['passed'] and not r['pageErrors'] and not r['unexpectedJsDialogs'])
check('recording format complete gap-free and matching source/session',x['format']=='trainer-session' and x['schemaVersion']==2 and x['complete'] is True and x['gaps']==[] and x['app']['gitCommit']==r['sourceCommit'] and x['sessionId']==r['recording']['sessionId'])
check('event count and contiguous sequence',len(x['events'])==8==r['recording']['eventCount'] and [e['seq'] for e in x['events']]==list(range(1,9)))
ops=collections.defaultdict(list)
for event in x['events']:ops[event['opId']].append(event)
check('one trade plus three advance operation pairs',collections.Counter(pair[0]['action'] for pair in ops.values())=={'training.trade':1,'training.advance':3})
for pair in ops.values():check('started/finished accepted UI operation '+pair[0]['opId'],[e['phase'] for e in pair]==['started','finished'] and all(e['source']=='ui' for e in pair) and pair[1]['outcome']=='accepted' and pair[0]['action']==pair[1]['action'])
res=x['resources'];lookup={k:{z['id']:z for z in v} for k,v in res.items()}
cps=x['checkpoints'];cpbyid={c['id']:c for c in cps}
check('checkpoint count and unique ids',len(cps)==11==r['recording']['checkpointCount'] and len(cpbyid)==11)
check('checkpoint sequences monotonic and bounded',[c['afterSeq'] for c in cps]==sorted(c['afterSeq'] for c in cps) and all(0<=c['afterSeq']<=8 for c in cps))
for pair in ops.values():
 e=pair[1];check('operation checkpoint references matching sequence '+e['opId'],e['checkpointId'] in cpbyid and cpbyid[e['checkpointId']]['afterSeq']==e['seq'])
series={}
for s in res['series']:
 if s.get('base'):
  values=dict(series[s['base']]);[values.pop(d,None) for d in s.get('remove',[])];values.update({b['date']:b for b in s.get('upsert',[])})
 else:values={b['date']:b for b in s.get('bars',[])}
 series[s['id']]=values
 if not values: raise AssertionError('empty series '+s['id']+' keys='+str(list(s)))
summary=[]
for i,c in enumerate(cps):
 t=c['training'];m=lookup['trainingMeta'][t['metaRef']]['value'];a=lookup['accounts'][t['accountRef']]['value'];ch=c.get('chart')
 check('checkpoint resources resolve '+str(i),c['contextRef'] in lookup['contexts'] and all(z in lookup['trades'] for z in t['tradeRefs']))
 check('checkpoint equity arithmetic '+str(i),abs(a['cash']+a['shares']*m['currentClose']-a['equity'])<1e-5)
 if ch:
  check('chart refs/date resolve '+str(i),ch['drawingsRef'] in lookup['drawings'] and ch['seriesRef'] in series and max(series[ch['seriesRef']])==m['currentDate'])
 summary.append({'index':i,'afterSeq':c['afterSeq'],'date':m['currentDate'],'shares':a['shares'],'cash':a['cash'],'equity':a['equity'],'chartPresent':ch is not None,'seriesRef':ch.get('seriesRef') if ch else None})
boots=r['boots'];check('two normal product exits',len(boots)==2 and all(b['exit']=={'code':0,'signal':None} for b in boots))
check('same origin, SQLite, profile, namespace across restart',boots[0]['state']['baseURL']==boots[1]['state']['baseURL']=='http://127.0.0.1:6608' and boots[0]['state']['databasePath']==boots[1]['state']['databasePath'] and boots[0]['identity']['userData']==boots[1]['identity']['userData'] and boots[0]['recordingNamespace']==boots[1]['recordingNamespace'])
check('different PID/runId confirms second process',boots[0]['identity']['pid']!=boots[1]['identity']['pid'] and boots[0]['state']['runId']!=boots[1]['state']['runId'])
doms={n:(evidence/(n+'.dom.txt')).read_text('utf-8') for n in ['first-boot-replay-first','first-boot-replay-progress','second-boot-replay-first','second-boot-replay-progress']}
check('both boots captured first trading day',all('2025-01-02' in doms[n] and '第 1 / 4 日' in doms[n] for n in ['first-boot-replay-first','second-boot-replay-first']))
check('both boots captured advanced trading day',all('2025-01-03' in doms[n] and '第 2 / 4 日' in doms[n] for n in ['first-boot-replay-progress','second-boot-replay-progress']))
check('captured replay DOM equal across boots at same positions',doms['first-boot-replay-first']==doms['second-boot-replay-first'] and doms['first-boot-replay-progress']==doms['second-boot-replay-progress'])
files=[script,evidence/'acceptance-result.json',evidence/'actual-ui-recording.json.gz']+[evidence/(n+'.dom.txt') for n in doms]
result={'reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewScope':'Offline read-only inspection of v4 script, receipt, gzip resources and DOM snapshots; no product or database execution','sourceCommit':r['sourceCommit'],'allOfflineChecksPassed':True,'checks':checks,'artifacts':[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files],'recording':{'sessionId':x['sessionId'],'format':x['format'],'schemaVersion':x['schemaVersion'],'eventCount':len(x['events']),'checkpointCount':len(cps),'gzipBytes':(evidence/'actual-ui-recording.json.gz').stat().st_size,'decompressedBytes':len(gzip.decompress((evidence/'actual-ui-recording.json.gz').read_bytes())),'complete':x['complete'],'gaps':x['gaps'],'resourceCounts':{k:len(v) for k,v in res.items()},'checkpoints':summary},'scriptEvidence':{'download':'lines 521-532: actual page download, DOM export click, saveAs, gzip magic/decode/format/gaps/checkpoints/trade check','replay':'lines 399-425: local library one row; row text equality; replay not empty; next and play alter displayed day','restart':'lines 545-559 plus boot lines 211-223: prior exit, same port/origin/profile/namespace, new runId, formula same id/enabled, repeat local replay'},'limits':['Library replay opens the post-settlement local recording (10 events); the exported pre-settlement gzip has 8 events and is not imported or replayed by this script. Exported-file round-trip is not proven.','Replay asserts non-empty chart and date progression, with matching captured DOM at two positions across boots. It does not compare replay accounts/chart curves/all frames against every gzip checkpoint.','Four operation completion checkpoints have chart=null; each is followed by a full chart checkpoint at the same afterSeq. All referenced resources and account arithmetic resolve offline.','Recording metadata app.version is unknown although app.gitCommit matches f945 and packaged identity reports version 1.3.8.','CMD entry, installer, migration/upgrade, macOS, remote release, visual correctness and human acceptance are outside this receipt.','Native process exit 0 for the original v4 command was reported by the parent; this offline verifier independently checks recorded exits/receipt and runs no product.'],'inspectionNote':'Initial exploratory reader assumed every checkpoint.chart was an object and raised TypeError on null; corrected reader explicitly handles documented nullable chart snapshots without modifying artifacts.'}
(out/'review.receipt.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report='''# v4 packaged recording and restart evidence review\n\nVerdict: the observed receipt and script support a real UI export, local-library replay and persistence across a real process restart on the same origin. The exported file itself was not imported/replayed, so an exported-file round-trip is outside this evidence.\n\nThe script SHA matches the receipt. The gzip SHA matches, parses as schema 2, and contains eight gap-free events (one accepted buy plus three accepted advances), eleven checkpoints and complete=true. Offline reference checks reconstruct all four chart series, validate account arithmetic and resolve checkpoint resources. Four action checkpoints have chart=null and subsequent same-sequence checkpoints carry full chart state.\n\nBoth boots report normal exits, the same origin, SQLite path, Chromium profile and recording namespace, with different product PIDs/runIds. Both replay DOM snapshots progress from 2025-01-02 to 2025-01-03 and are byte-equal at matching positions across boots. The saved row has ten events because settlement occurs after the eight-event export.\n\nThe script checks UI day progression and a non-empty replay chart. It does not verify all replay frames or numerical chart fidelity against the gzip, and does not prove CMD, installer, upgrade, visual or user acceptance. Recording app.version remains unknown; gitCommit matches f945 while packaged identity is 1.3.8.\n\nSee review.receipt.json for hashes, individual offline assertions and exact script line references. No repository, control, matrix, GitHub, application or database changes were made by this review.\n'''
(out/'review.md').write_text(report,encoding='utf-8')
print(json.dumps({'allOfflineChecksPassed':True,'checks':len(checks),'reviewReceipt':str(out/'review.receipt.json'),'receiptSha256':sha(out/'review.receipt.json'),'report':str(out/'review.md'),'reportSha256':sha(out/'review.md')},ensure_ascii=True))