# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: pane-resize.spec.ts >> Ctrl separator drag preserves selection through the right axis side
- Location: e2e\pane-resize.spec.ts:138:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 4
Received: 5

Call Log:
- Timeout 15000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary "主导航" [ref=e4]:
    - generic [ref=e5]: K
    - navigation [ref=e6]:
      - button "训练" [ref=e7] [cursor=pointer]
      - button "历史排行" [ref=e13] [cursor=pointer]:
        - generic [ref=e20]: 排行
      - button "历史训练" [ref=e21] [cursor=pointer]:
        - generic [ref=e26]: 历史
      - button "训练录像" [ref=e27] [cursor=pointer]:
        - generic [ref=e31]: 录像
    - button "保存并退出训练器" [ref=e32] [cursor=pointer]:
      - generic [ref=e35]: 退出
    - button "训练默认设置" [ref=e36] [cursor=pointer]:
      - generic [ref=e40]: 设置
  - main [ref=e41]:
    - generic [ref=e42]:
      - generic [ref=e43]: A股 K线训练器
      - generic [ref=e45]:
        - generic [ref=e47]:
          - generic [ref=e48]:
            - checkbox "记录操作" [checked] [ref=e49]
            - text: 记录操作
          - status [ref=e50]: 正在记录 · 0 次操作
          - button "导出录制" [ref=e51] [cursor=pointer]
        - button "切换到浅色主题" [ref=e52] [cursor=pointer]
        - generic [ref=e60]: TDX · 截止 2026-09-16
    - generic [ref=e61]:
      - generic [ref=e62]:
        - generic [ref=e63]:
          - generic "贵州茅台 · 600519" [ref=e65]
          - generic [ref=e66]:
            - text: 当前
            - strong [ref=e67]: 2025-01-02
          - tablist "K线周期" [ref=e68]:
            - tab "日K" [selected] [ref=e69] [cursor=pointer]
            - tab "周K" [ref=e70] [cursor=pointer]
            - tab "月K" [ref=e71] [cursor=pointer]
          - group "副图指标开关" [ref=e72]:
            - button "VOL" [pressed] [ref=e73] [cursor=pointer]
            - button "MACD" [pressed] [ref=e74] [cursor=pointer]
            - button "KDJ" [pressed] [ref=e75] [cursor=pointer]
            - button "多空反转" [ref=e76] [cursor=pointer]
          - group [ref=e77]:
            - generic "训练详情" [ref=e78] [cursor=pointer]
        - generic [ref=e81]:
          - button "划线" [pressed] [ref=e82] [cursor=pointer]
          - button "日线数据更新：最新交易日待确认，点击重新读取本地日线" [ref=e86] [cursor=pointer]: 更新
          - button "刷新图表" [ref=e87] [cursor=pointer]
          - button "回到最新K线" [ref=e93] [cursor=pointer]
          - button "推进下一日" [ref=e96] [cursor=pointer]
          - button "提前结算" [ref=e99] [cursor=pointer]
          - button "放弃训练" [ref=e100] [cursor=pointer]
      - generic [ref=e101]:
        - generic "训练就绪" [ref=e102]
        - group "K线行情" [ref=e104]:
          - generic [ref=e105]: 日K 2025-01-02 周四
          - generic [ref=e106]: 开 1524.00
          - generic [ref=e107]: 高 1524.49
          - generic [ref=e108]: 低 1480.00
          - generic [ref=e109]: 收 1488.00
          - generic [ref=e110]: 日涨幅 -2.36%
          - generic [ref=e111]: 最近已知K线
        - generic "空格：推进下一日；[ / ]：日周月周期；Home：回到最新；↑ / ↓：缩放；Shift+← / →：平移视图；Del：删除选中画线；B / S：买入卖出；Ctrl+Z / Ctrl+Y：撤销重做。输入、弹窗和画线取点期间部分快捷键暂停。" [ref=e112]: 空格 下一日 · [ ] 周期 · Home 最新 · ↑↓ 缩放 · Shift←→ 平移 · Del 删线
        - generic [ref=e113]: 可见至 2025-01-02 周四
        - generic "当前同屏K线根数 / 同屏上限" [ref=e114]: 152 / 840 根
      - generic [ref=e115]:
        - generic [ref=e117]:
          - button "设置均线" [ref=e119] [cursor=pointer]: MA 设置
          - group "成交标记" [ref=e169]
        - complementary [ref=e170]:
          - generic [ref=e171]:
            - generic [ref=e172]:
              - generic [ref=e173]: 训练账户
              - generic [ref=e174]: ● 进行中
            - generic [ref=e175]:
              - generic [ref=e176]: 账户权益
              - strong [ref=e177]:
                - generic [ref=e178]: ¥100,000,000
              - emphasis [ref=e179]:
                - generic [ref=e180]: +0.00%
            - generic [ref=e181]:
              - generic [ref=e182]:
                - generic [ref=e183]: 可用资金
                - strong [ref=e184]: ¥100,000,000
              - generic [ref=e185]:
                - generic [ref=e186]: 持仓市值
                - strong [ref=e187]: ¥0
              - generic [ref=e188]:
                - generic [ref=e189]: 持仓（可卖）
                - strong [ref=e190]: 0（0）
              - generic [ref=e191]:
                - generic [ref=e192]: 摊薄成本
                - strong [ref=e193]: "--"
            - generic [ref=e195]:
              - tablist "下单方式" [ref=e196]:
                - tab "普通下单" [selected] [ref=e197] [cursor=pointer]
              - generic [ref=e198]: 按当日收盘价成交
            - generic [ref=e199]:
              - button "10%" [ref=e200] [cursor=pointer]
              - button "20%" [ref=e201] [cursor=pointer]
              - button "25%" [ref=e202] [cursor=pointer]
              - button "30%" [ref=e203] [cursor=pointer]
              - button "50%" [ref=e204] [cursor=pointer]
              - button "75%" [ref=e205] [cursor=pointer]
              - button "100%" [ref=e206] [cursor=pointer]
              - spinbutton "自定义%" [ref=e207]
            - generic [ref=e208]:
              - spinbutton "按股数买卖" [ref=e209]
              - generic [ref=e210]: 留空则按左侧比例
            - generic [ref=e211]:
              - button "买入" [ref=e212] [cursor=pointer]
              - button "卖出" [ref=e213] [cursor=pointer]
          - generic [ref=e214]:
            - generic [ref=e215]:
              - button "折叠画线工具条" [expanded] [ref=e224] [cursor=pointer]
              - generic [ref=e227]: 常用工具
              - button "自定义常用" [ref=e228] [cursor=pointer]
              - button "固定工具面板" [ref=e232] [cursor=pointer]
            - generic [ref=e235]:
              - generic [ref=e236]:
                - button "线段" [ref=e238] [cursor=pointer]
                - button "射线" [ref=e245] [cursor=pointer]
                - button "直线" [ref=e252] [cursor=pointer]
                - button "水平直线" [ref=e257] [cursor=pointer]
                - button "垂直直线" [ref=e261] [cursor=pointer]
                - button "价位线" [ref=e265] [cursor=pointer]
                - button "百分比线" [ref=e269] [cursor=pointer]
              - button "其他工具 16" [expanded] [ref=e275] [cursor=pointer]:
                - text: 其他工具
                - generic [ref=e278]: "16"
              - generic [ref=e279]:
                - button "水平线段" [ref=e281] [cursor=pointer]
                - button "水平射线" [ref=e287] [cursor=pointer]
                - button "垂直线段" [ref=e293] [cursor=pointer]
                - button "垂直射线" [ref=e299] [cursor=pointer]
                - button "平行直线" [ref=e305] [cursor=pointer]
                - button "价格通道线" [ref=e311] [cursor=pointer]
                - button "斐波那契线" [ref=e317] [cursor=pointer]
                - button "画笔" [ref=e321] [cursor=pointer]
                - button "矩形" [ref=e326] [cursor=pointer]
                - button "圆圈" [ref=e331] [cursor=pointer]
                - button "圆弧" [ref=e336] [cursor=pointer]
                - button "箭头线" [ref=e341] [cursor=pointer]
                - button "看涨箭头" [ref=e347] [cursor=pointer]
                - button "看跌箭头" [ref=e353] [cursor=pointer]
                - button "诅咒线" [ref=e359] [cursor=pointer]
                - button "文本" [ref=e364] [cursor=pointer]
            - generic [ref=e368]:
              - button "多选" [ref=e369] [cursor=pointer]
              - button "撤销" [disabled] [ref=e370]
              - button "重做" [disabled] [ref=e374]
              - button "清空" [ref=e378] [cursor=pointer]
              - combobox "吸附" [ref=e382]:
                - option "关闭"
                - option "弱吸附" [selected]
                - option "强吸附"
            - status "已保存" [ref=e384]
            - separator "调整工具面板尺寸（拖动调整宽高，双击恢复默认）" [ref=e385]
```

# Test source

```ts
  1   | import { evidencePath } from './runtime'
  2   | import { expect, test, type Page } from '@playwright/test'
  3   | import { join } from 'node:path'
  4   | 
  5   | type Pane = { id: string; name: string; top: number; height: number; width: number }
  6   | type Point = { x: number; y: number }
  7   | const errors = new WeakMap<Page, string[]>()
  8   | 
  9   | test.beforeEach(({ page }) => {
  10  |   const list: string[] = []
  11  |   errors.set(page, list)
  12  |   page.on('pageerror', error => list.push(error.message))
  13  | })
  14  | test.afterEach(({ page }) => { expect(errors.get(page)).toEqual([]) })
  15  | 
  16  | async function openChart(page: Page): Promise<void> {
  17  |   const active = await (await page.request.get('/api/trainings/active')).json()
  18  |   if (active.training) await page.request.post(`/api/trainings/${active.training.id}/abandon`)
  19  |   const response = await page.request.post('/api/trainings', {
  20  |     data: { code: '600519', tier: '1Y', start_date: '2025-01-02', initial_cash: 100_000_000 },
  21  |   })
  22  |   expect(response.status()).toBe(201)
  23  |   await page.goto('/')
  24  |   await expect(page.locator('.training-current-date')).toBeVisible({ timeout: 15_000 })
  25  |   await expect(page.locator('.drawing-save-status')).toHaveText('已保存')
  26  |   await expect(page.locator('.loading-dot')).not.toBeVisible()
  27  |   // M6-01：KDJ 副图默认随偏好挂载（candle/VOL/MACD/KDJ）
> 28  |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart?.panes().length)).toBe(4)
      |                                                                                                ^ Error: expect(received).toBe(expected) // Object.is equality
  29  |   await page.getByRole('combobox', { name: '吸附', exact: true }).selectOption('normal')
  30  | }
  31  | 
  32  | async function panes(page: Page): Promise<Pane[]> {
  33  |   return page.evaluate(() => (window as any).__trainerChart.panes())
  34  | }
  35  | async function state(page: Page) {
  36  |   return page.evaluate(() => {
  37  |     const chart = (window as any).__trainerChart
  38  |     return { range: chart.visibleRange(), drawings: chart.drawings(), selected: chart.selectedCount(), mode: chart.mode() }
  39  |   })
  40  | }
  41  | async function mainPoint(page: Page, x: number, y: number): Promise<Point> {
  42  |   const box = await page.locator('.chart-host').boundingBox()
  43  |   const pane = (await panes(page))[0]
  44  |   return { x: box!.x + pane.width * x, y: box!.y + pane.top + pane.height * y }
  45  | }
  46  | async function drawSegment(page: Page): Promise<void> {
  47  |   const button = page.locator('[data-tool-name="segment"]')
  48  |   if (!await button.isVisible()) await page.locator('.other-tools-toggle').click()
  49  |   await button.click()
  50  |   const a = await mainPoint(page, .25, .25), b = await mainPoint(page, .45, .4)
  51  |   await page.mouse.click(a.x, a.y)
  52  |   await page.mouse.click(b.x, b.y)
  53  |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.drawings().length)).toBe(1)
  54  |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.mode().draw)).toBeNull()
  55  | }
  56  | async function selectSegment(page: Page): Promise<void> {
  57  |   const box = await page.locator('.chart-host').boundingBox()
  58  |   const point = await page.evaluate(() => {
  59  |     const [a, b] = (window as any).__trainerChart.geometry()[0].anchors
  60  |     return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }
  61  |   })
  62  |   await page.mouse.click(box!.x + point.x, box!.y + point.y)
  63  |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart.selectedCount())).toBe(1)
  64  | }
  65  | 
  66  | // These are the library's real seven-pixel separator widgets, including their hit margins.
  67  | function separators(page: Page) { return page.locator('.chart-host div[style*="cursor: ns-resize"][style*="height: 7px"]') }
  68  | 
  69  | async function resizePane(page: Page, index: number, dx: number, dy: number, hitY: number, axisSide = false): Promise<void> {
  70  |   const before = await state(page)
  71  |   const beforeMetrics = await page.evaluate(() => (window as any).__trainerChart.viewportMetrics())
  72  |   const sizes = await panes(page)
  73  |   const box = await separators(page).nth(index).boundingBox()
  74  |   expect(box).not.toBeNull()
  75  |   expect(box!.height).toBeGreaterThanOrEqual(7)
  76  |   const x = box!.x + (axisSide ? box!.width - 5 : box!.width * .58)
  77  |   const y = box!.y + hitY
  78  |   await page.mouse.move(x, y)
  79  |   expect(await page.evaluate(({ x, y }) => getComputedStyle(document.elementFromPoint(x, y)!).cursor, { x, y })).toBe('ns-resize')
  80  |   await page.mouse.down()
  81  |   await page.mouse.move(x + dx, y + dy, { steps: 12 })
  82  |   await expect(page.locator('.select-rect')).not.toBeVisible()
  83  |   await expect(page.locator('.multi-rect')).not.toBeVisible()
  84  |   expect((await state(page)).mode.axisScaleDrag).toBe(false)
  85  |   await expect.poll(async () => Math.abs((await panes(page))[index].height - sizes[index].height)).toBeGreaterThan(10)
  86  |   await page.mouse.up()
  87  |   const afterSizes = await panes(page)
  88  |   expect(Math.abs(afterSizes[index + 1].height - sizes[index + 1].height)).toBeGreaterThan(10)
  89  |   expect(afterSizes[index].height + afterSizes[index + 1].height).toBeCloseTo(sizes[index].height + sizes[index + 1].height, 5)
  90  |   const after = await state(page)
  91  |   const afterMetrics = await page.evaluate(() => (window as any).__trainerChart.viewportMetrics())
  92  |   expect(afterMetrics.bar, JSON.stringify({ beforeMetrics, afterMetrics })).toBe(beforeMetrics.bar)
  93  |   expect({ ...after, range: undefined }).toEqual({ ...before, range: undefined })
  94  |   expect(after.range.to).toBe(before.range.to)
  95  |   expect(after.range.realTo).toBe(before.range.realTo)
  96  |   // Native y-axis labels can change width when pane heights change, exposing at most two edge bars.
  97  |   const edgeTolerance = beforeMetrics.width === afterMetrics.width ? 0 : Math.min(2, Math.ceil(Math.abs(afterMetrics.width - beforeMetrics.width) / beforeMetrics.bar) + 1)
  98  |   for (const key of ['from', 'realFrom'] as const) {
  99  |     expect(Math.abs(after.range[key] - before.range[key]), JSON.stringify({ beforeMetrics, afterMetrics })).toBeLessThanOrEqual(edgeTolerance)
  100 |   }
  101 |   await page.mouse.move(x + dx + 40, y + dy - 25)
  102 |   expect(await state(page)).toEqual(after)
  103 | }
  104 | 
  105 | async function normalBoxSelect(page: Page): Promise<void> {
  106 |   const before = await state(page)
  107 |   const a = await mainPoint(page, .55, .55), b = await mainPoint(page, .82, .55)
  108 |   await page.mouse.move(a.x, a.y)
  109 |   await page.mouse.down()
  110 |   await page.mouse.move(b.x, b.y, { steps: 12 })
  111 |   await expect(page.locator('.select-rect')).toBeVisible()
  112 |   await page.mouse.up()
  113 |   await expect(page.locator('.select-rect')).not.toBeVisible()
  114 |   await expect.poll(async () => { const { range } = await state(page); return range.to - range.from }).toBeLessThan(before.range.to - before.range.from)
  115 |   expect((await state(page)).drawings).toEqual(before.drawings)
  116 | }
  117 | 
  118 | for (const mode of ['default', 'multi'] as const) {
  119 |   for (const [index, name] of ['candle/VOL', 'VOL/MACD'].entries()) {
  120 |     test(`${name} separator owns diagonal left/right drags in ${mode} mode`, async ({ page }) => {
  121 |       if (mode === 'multi') await page.setViewportSize({ width: 1280, height: 800 })
  122 |       await openChart(page)
  123 |       await drawSegment(page)
  124 |       if (mode === 'multi') {
  125 |         await page.locator('.draw-toolbar').getByRole('button', { name: '多选', exact: true }).click()
  126 |         await selectSegment(page)
  127 |       }
  128 |       await resizePane(page, index, -65, -24, 1)
```