# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: uiux-training.spec.ts >> training keeps trading and drawing available together without shifting chart or advance target
- Location: e2e\uiux-training.spec.ts:145:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 4
Received: 5

Call Log:
- Timeout 15000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary "主导航" [ref=e4]:
    - generic [ref=e5]: K
    - navigation [ref=e6]:
      - button "训练" [ref=e7] [cursor=pointer]
      - button "历史排行" [ref=e13] [cursor=pointer]:
        - generic [ref=e20]: 排行
      - button "历史训练" [ref=e21] [cursor=pointer]:
        - generic [ref=e26]: 历史
      - button "训练录像" [ref=e27] [cursor=pointer]:
        - generic [ref=e31]: 录像
    - button "保存并退出训练器" [ref=e32] [cursor=pointer]:
      - generic [ref=e35]: 退出
    - button "训练默认设置" [ref=e36] [cursor=pointer]:
      - generic [ref=e40]: 设置
  - main [ref=e41]:
    - generic [ref=e42]:
      - generic [ref=e43]: A股 K线训练器
      - generic [ref=e45]:
        - generic [ref=e47]:
          - generic [ref=e48]:
            - checkbox "记录操作" [checked] [ref=e49]
            - text: 记录操作
          - status [ref=e50]: 正在记录 · 0 次操作
          - button "导出录制" [ref=e51] [cursor=pointer]
        - button "切换到浅色主题" [ref=e52] [cursor=pointer]
        - generic [ref=e60]: TDX · 截止 2026-09-16
    - generic [ref=e61]:
      - generic [ref=e62]:
        - generic [ref=e63]:
          - generic "协创数据 · 300857" [ref=e65]
          - generic [ref=e66]:
            - text: 当前
            - strong [ref=e67]: 2026-04-15
          - tablist "K线周期" [ref=e68]:
            - tab "日K" [selected] [ref=e69] [cursor=pointer]
            - tab "周K" [ref=e70] [cursor=pointer]
            - tab "月K" [ref=e71] [cursor=pointer]
          - group "副图指标开关" [ref=e72]:
            - button "VOL" [pressed] [ref=e73] [cursor=pointer]
            - button "MACD" [pressed] [ref=e74] [cursor=pointer]
            - button "KDJ" [pressed] [ref=e75] [cursor=pointer]
            - button "多空反转" [ref=e76] [cursor=pointer]
          - group [ref=e77]:
            - generic "训练详情" [ref=e78] [cursor=pointer]
        - generic [ref=e81]:
          - button "划线" [pressed] [ref=e82] [cursor=pointer]
          - button "日线数据更新：最新交易日待确认，点击重新读取本地日线" [ref=e86] [cursor=pointer]: 更新
          - button "刷新图表" [ref=e87] [cursor=pointer]
          - button "回到最新K线" [ref=e93] [cursor=pointer]
          - button "推进下一日" [ref=e96] [cursor=pointer]
          - button "提前结算" [ref=e99] [cursor=pointer]
          - button "放弃训练" [ref=e100] [cursor=pointer]
      - generic [ref=e101]:
        - generic "训练就绪"
        - group "K线行情" [ref=e103]:
          - generic [ref=e104]: 日K 2026-04-15 周三
          - generic [ref=e105]: 开 280.19
          - generic [ref=e106]: 高 288.68
          - generic [ref=e107]: 低 268.98
          - generic [ref=e108]: 收 280.69
          - generic [ref=e109]: 日涨幅 +12.46%
          - generic [ref=e110]: 最近已知K线
        - generic "空格：推进下一日；[ / ]：日周月周期；Home：回到最新；↑ / ↓：缩放；Shift+← / →：平移视图；Del：删除选中画线；B / S：买入卖出；Ctrl+Z / Ctrl+Y：撤销重做。输入、弹窗和画线取点期间部分快捷键暂停。" [ref=e111]: 空格 下一日 · [ ] 周期 · Home 最新 · ↑↓ 缩放 · Shift←→ 平移 · Del 删线
        - generic [ref=e112]: 可见至 2026-04-15 周三
        - generic "当前同屏K线根数 / 同屏上限" [ref=e113]: 155 / 840 根
      - generic [ref=e114]:
        - generic [ref=e116]:
          - button "设置均线" [ref=e118] [cursor=pointer]: MA 设置
          - group "成交标记" [ref=e168]
        - complementary [ref=e169]:
          - generic [ref=e170]:
            - generic [ref=e171]:
              - generic [ref=e172]: 训练账户
              - generic [ref=e173]: ● 进行中
            - generic [ref=e174]:
              - generic [ref=e175]: 账户权益
              - strong [ref=e176]:
                - generic [ref=e177]: ¥1,000,000
              - emphasis [ref=e178]:
                - generic [ref=e179]: +0.00%
            - generic [ref=e180]:
              - generic [ref=e181]:
                - generic [ref=e182]: 可用资金
                - strong [ref=e183]: ¥1,000,000
              - generic [ref=e184]:
                - generic [ref=e185]: 持仓市值
                - strong [ref=e186]: ¥0
              - generic [ref=e187]:
                - generic [ref=e188]: 持仓（可卖）
                - strong [ref=e189]: 0（0）
              - generic [ref=e190]:
                - generic [ref=e191]: 摊薄成本
                - strong [ref=e192]: "--"
            - generic [ref=e194]:
              - tablist "下单方式" [ref=e195]:
                - tab "普通下单" [selected] [ref=e196] [cursor=pointer]
                - tab "条件单" [ref=e197] [cursor=pointer]
              - generic [ref=e198]: 按当日收盘价成交
            - generic [ref=e199]:
              - button "10%" [ref=e200] [cursor=pointer]
              - button "20%" [ref=e201] [cursor=pointer]
              - button "25%" [ref=e202] [cursor=pointer]
              - button "30%" [ref=e203] [cursor=pointer]
              - button "50%" [ref=e204] [cursor=pointer]
              - button "75%" [ref=e205] [cursor=pointer]
              - button "100%" [ref=e206] [cursor=pointer]
              - spinbutton "自定义%" [ref=e207]
            - generic [ref=e208]:
              - spinbutton "按股数买卖" [ref=e209]
              - generic [ref=e210]: 留空则按左侧比例
            - generic [ref=e211]:
              - button "买入" [ref=e212] [cursor=pointer]
              - button "卖出" [ref=e213] [cursor=pointer]
          - generic [ref=e214]:
            - generic [ref=e215]:
              - button "折叠画线工具条" [expanded] [ref=e224] [cursor=pointer]
              - generic [ref=e227]: 常用工具
              - button "自定义常用" [ref=e228] [cursor=pointer]
              - button "固定工具面板" [ref=e232] [cursor=pointer]
            - generic [ref=e235]:
              - generic [ref=e236]:
                - button "线段" [ref=e238] [cursor=pointer]
                - button "射线" [ref=e245] [cursor=pointer]
                - button "直线" [ref=e252] [cursor=pointer]
                - button "水平直线" [ref=e257] [cursor=pointer]
                - button "垂直直线" [ref=e261] [cursor=pointer]
                - button "价位线" [ref=e265] [cursor=pointer]
                - button "百分比线" [ref=e269] [cursor=pointer]
              - button "其他工具 16" [expanded] [ref=e275] [cursor=pointer]:
                - text: 其他工具
                - generic [ref=e278]: "16"
              - generic [ref=e279]:
                - button "水平线段" [ref=e281] [cursor=pointer]
                - button "水平射线" [ref=e287] [cursor=pointer]
                - button "垂直线段" [ref=e293] [cursor=pointer]
                - button "垂直射线" [ref=e299] [cursor=pointer]
                - button "平行直线" [ref=e305] [cursor=pointer]
                - button "价格通道线" [ref=e311] [cursor=pointer]
                - button "斐波那契线" [ref=e317] [cursor=pointer]
                - button "画笔" [ref=e321] [cursor=pointer]
                - button "矩形" [ref=e326] [cursor=pointer]
                - button "圆圈" [ref=e331] [cursor=pointer]
                - button "圆弧" [ref=e336] [cursor=pointer]
                - button "箭头线" [ref=e341] [cursor=pointer]
                - button "看涨箭头" [ref=e347] [cursor=pointer]
                - button "看跌箭头" [ref=e353] [cursor=pointer]
                - button "诅咒线" [ref=e359] [cursor=pointer]
                - button "文本" [ref=e364] [cursor=pointer]
            - generic [ref=e368]:
              - button "多选" [ref=e369] [cursor=pointer]
              - button "撤销" [disabled] [ref=e370]
              - button "重做" [disabled] [ref=e374]
              - button "清空" [ref=e378] [cursor=pointer]
              - combobox "吸附" [ref=e382]:
                - option "关闭"
                - option "弱吸附" [selected]
                - option "强吸附"
            - status "已保存" [ref=e384]
            - separator "调整工具面板尺寸（拖动调整宽高，双击恢复默认）" [ref=e385]
```

# Test source

```ts
  1   | import { expect, test, type Locator, type Page } from '@playwright/test'
  2   | import { evidencePath } from './runtime'
  3   | 
  4   | async function settle(page: Page) {
  5   |   await page.evaluate(async () => {
  6   |     await document.fonts.ready
  7   |     await Promise.all(document.getAnimations().filter(a => a.playState === 'running' && Number.isFinite(a.effect?.getComputedTiming().iterations)).map(a => a.finished.catch(() => {})))
  8   |     await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())))
  9   |   })
  10  | }
  11  | 
  12  | async function openTraining(page: Page) {
  13  |   const active = (await (await page.request.get('/api/trainings/active')).json()).training
  14  |   if (active) await page.request.post(`/api/trainings/${active.id}/abandon`)
  15  |   const created = await page.request.post('/api/trainings', { data: {
  16  |     code: '300857', tier: '1M', start_date: '2026-04-15', initial_cash: 1_000_000,
  17  |     blind: false, clock_mode: 'close_only', orders_enabled: true,
  18  |   } })
  19  |   expect(created.status()).toBe(201)
  20  |   const id = (await created.json()).training.id as number
  21  |   await page.goto('/')
  22  |   await expect(page.locator('.drawing-save-status')).toHaveText('已保存')
  23  |   await expect(page.locator('.training-grid')).not.toHaveAttribute('inert', '')
> 24  |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart?.panes().length)).toBe(4)
      |                                                                                                ^ Error: expect(received).toBe(expected) // Object.is equality
  25  |   await settle(page)
  26  |   return id
  27  | }
  28  | 
  29  | // Read clipping ancestors and hit-test before any click; locator auto-scroll must not repair the layout under test.
  30  | async function reachable(target: Locator, label: string) {
  31  |   const m = await target.evaluate(el => {
  32  |     const r = el.getBoundingClientRect(), clip = { left: 0, top: 0, right: innerWidth, bottom: innerHeight }
  33  |     // UI-TOOLBAR-01：悬浮工具面板 position:fixed，其上方的锚点祖先（console-scroll 等）overflow 实际不裁切它；
  34  |     // 只累计到固定面板自身（含内部滚动容器）为止，面板上方的祖先不再参与裁切。
  35  |     const fixedSubtree = (() => {
  36  |       let node: Element | null = el
  37  |       while (node) { if (getComputedStyle(node).position === 'fixed') return true; node = node.parentElement }
  38  |       return false
  39  |     })()
  40  |     for (let p = el.parentElement; p; p = p.parentElement) {
  41  |       const s = getComputedStyle(p), b = p.getBoundingClientRect()
  42  |       if (/(auto|scroll|hidden|clip)/.test(s.overflowX)) { clip.left = Math.max(clip.left, b.left + p.clientLeft); clip.right = Math.min(clip.right, b.left + p.clientLeft + p.clientWidth) }
  43  |       if (/(auto|scroll|hidden|clip)/.test(s.overflowY)) { clip.top = Math.max(clip.top, b.top + p.clientTop); clip.bottom = Math.min(clip.bottom, b.top + p.clientTop + p.clientHeight) }
  44  |       if (fixedSubtree && s.position === 'fixed') break
  45  |     }
  46  |     const hit = document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2)
  47  |     return { box: { x: r.x, y: r.y, width: r.width, height: r.height }, clip, fixed: fixedSubtree, hit: hit === el || el.contains(hit), hitText: hit?.textContent?.slice(0, 80) }
  48  |   })
  49  |   expect(m.box.width, label).toBeGreaterThan(0)
  50  |   expect(m.box.height, label).toBeGreaterThan(0)
  51  |   if (!m.fixed) {
  52  |   expect(m.box.x, `${label} left ${JSON.stringify(m)}`).toBeGreaterThanOrEqual(m.clip.left - 1)
  53  |   expect(m.box.y, `${label} top ${JSON.stringify(m)}`).toBeGreaterThanOrEqual(m.clip.top - 1)
  54  |   expect(m.box.x + m.box.width, `${label} right ${JSON.stringify(m)}`).toBeLessThanOrEqual(m.clip.right + 1)
  55  |   expect(m.box.y + m.box.height, `${label} bottom ${JSON.stringify(m)}`).toBeLessThanOrEqual(m.clip.bottom + 1)
  56  |   }
  57  |   expect(m.hit, `${label} center hit ${JSON.stringify(m)}`).toBe(true)
  58  |   return m.box
  59  | }
  60  | 
  61  | async function mouseClick(page: Page, target: Locator, label: string) {
  62  |   const b = await reachable(target, label)
  63  |   await page.mouse.click(b.x + b.width / 2, b.y + b.height / 2)
  64  | }
  65  | 
  66  | async function setTheme(page: Page, mode: 'light' | 'dark') {
  67  |   if (await page.locator('body').evaluate(el => el.classList.contains('dark')) !== (mode === 'dark')) await mouseClick(page, page.locator('.theme-toggle'), 'theme')
  68  |   await settle(page)
  69  | }
  70  | 
  71  | async function fixedPositions(page: Page) {
  72  |   return { chart: (await page.locator('.chart-host').boundingBox())!, advance: (await page.getByRole('button', { name: '推进下一日', exact: true }).boundingBox())!,
  73  |     heading: (await page.locator('.drawing-toolbar-heading').boundingBox())!, actions: (await page.locator('.drawing-toolbar-actions').boundingBox())!,
  74  |     footer: (await page.locator('.drawing-save-footer').boundingBox())!, scrollY: await page.evaluate(() => scrollY) }
  75  | }
  76  | 
  77  | async function stable(page: Page, before: Awaited<ReturnType<typeof fixedPositions>>) {
  78  |   const after = await fixedPositions(page)
  79  |   expect(after.scrollY).toBe(before.scrollY)
  80  |   for (const region of ['chart', 'advance', 'heading', 'actions', 'footer'] as const) for (const dim of ['x', 'y', 'width', 'height'] as const)
  81  |     expect(Math.abs(after[region][dim] - before[region][dim]), `${region} ${dim}`).toBeLessThanOrEqual(.5)
  82  | }
  83  | 
  84  | async function geometry(page: Page, name: string) {
  85  |   const data = await page.evaluate(() => {
  86  |     const r = document.querySelector('.chart-host')!.getBoundingClientRect()
  87  |     const metrics = (s: string) => { const e = document.querySelector(s)!; return { scrollHeight: e.scrollHeight, clientHeight: e.clientHeight, scrollTop: e.scrollTop } }
  88  |     return { content: { width: innerWidth, height: innerHeight }, browserOuter: { width: outerWidth, height: outerHeight }, dpr: devicePixelRatio,
  89  |       visualViewportScale: visualViewport?.scale, chart: { width: r.width, height: r.height }, console: metrics('.console-scroll'), tools: metrics('.toolbar-tool-lists'),
  90  |       panes: (window as any).__trainerChart.panes(), fontTokens: Object.fromEntries(['2xs', 'xs', 'sm', 'md', 'lg', 'xl', '2xl'].map(k => [k, getComputedStyle(document.documentElement).getPropertyValue(`--font-size-${k}`)])) }
  91  |   })
  92  |   await test.info().attach(name, { body: JSON.stringify(data, null, 2), contentType: 'application/json' })
  93  |   expect(data.panes.map((p: any) => p.name)).toEqual(['candle_pane', 'VOL', 'MACD', 'KDJ'])
  94  |   for (const p of data.panes) {
  95  |     expect(p.width).toBeGreaterThan(0); expect(p.height).toBeGreaterThan(0)
  96  |     expect(p.left).toBeGreaterThanOrEqual(0); expect(p.top).toBeGreaterThanOrEqual(0)
  97  |     expect(p.left + p.width).toBeLessThanOrEqual(data.chart.width + 1)
  98  |     expect(p.top + p.height).toBeLessThanOrEqual(data.chart.height + 1)
  99  |   }
  100 | }
  101 | 
  102 | async function buy100(page: Page, id: number) {
  103 |   const before = (await (await page.request.get(`/api/trainings/${id}`)).json()).account.shares
  104 |   await mouseClick(page, page.getByRole('spinbutton', { name: '按股数买卖', exact: true }), 'share input')
  105 |   await page.keyboard.press('Control+A'); await page.keyboard.type('100')
  106 |   const response = page.waitForResponse(r => r.url().endsWith(`/api/trainings/${id}/trade`) && r.request().method() === 'POST')
  107 |   await mouseClick(page, page.getByRole('button', { name: '买入', exact: true }), 'buy 100')
  108 |   expect((await response).status()).toBe(200)
  109 |   await expect.poll(async () => (await (await page.request.get(`/api/trainings/${id}`)).json()).account.shares).toBe(before + 100)
  110 |   await expect(page.locator('.training-grid')).not.toHaveAttribute('inert', '')
  111 |   await settle(page)
  112 | }
  113 | 
  114 | const scrollMetrics = (container: Locator) => container.evaluate(e => ({ top: e.scrollTop, height: e.scrollHeight, client: e.clientHeight }))
  115 | async function wheel(page: Page, container: Locator, delta: number) {
  116 |   const b = (await container.boundingBox())!
  117 |   await page.mouse.move(b.x + Math.min(20, b.width / 2), b.y + b.height / 2)
  118 |   await page.mouse.wheel(0, delta)
  119 |   await page.waitForTimeout(120)
  120 | }
  121 | async function wheelToEnd(page: Page, container: Locator, label: string, allowFits = false) {
  122 |   await wheel(page, container, -2400)
  123 |   await expect.poll(async () => (await scrollMetrics(container)).top, { message: `${label} begins at top by real wheel` }).toBe(0)
  124 |   const before = await scrollMetrics(container)
```