# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: percent-hover.spec.ts >> replay view computes the card from the replayed series, first bar shows the gray placeholder
- Location: e2e\percent-hover.spec.ts:220:1

# Error details

```
Error: 可见窗口内存在可悬停的上涨 K 线

expect(received).toBeTruthy()

Received: null
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary "主导航" [ref=e4]:
    - generic [ref=e5]: K
    - navigation [ref=e6]:
      - button "训练" [ref=e7] [cursor=pointer]
      - button "历史排行" [ref=e13] [cursor=pointer]:
        - generic [ref=e20]: 排行
      - button "历史训练" [ref=e21] [cursor=pointer]:
        - generic [ref=e26]: 历史
      - button "训练录像" [ref=e27] [cursor=pointer]:
        - generic [ref=e31]: 录像
    - button "保存并退出训练器" [ref=e32] [cursor=pointer]:
      - generic [ref=e35]: 退出
    - button "训练默认设置" [ref=e36] [cursor=pointer]:
      - generic [ref=e40]: 设置
  - main [ref=e41]:
    - generic [ref=e42]:
      - generic [ref=e43]: A股 K线训练器
      - generic [ref=e45]:
        - button "切换到浅色主题" [ref=e46] [cursor=pointer]
        - generic [ref=e54]: TDX · 截止 2026-09-16
    - generic [ref=e55]:
      - generic [ref=e56]:
        - generic [ref=e57]:
          - heading "录制回放" [level=2] [ref=e58]
          - paragraph [ref=e59]: 贵州茅台 · 600519 · 1 个交易日 · 0 条业务操作
        - button "关闭回放" [ref=e60] [cursor=pointer]
      - generic [ref=e61]:
        - generic [ref=e62]:
          - generic [ref=e63]:
            - strong [ref=e64]: 第 1 / 1 日 · 2025-01-02
            - tablist "观察周期" [ref=e65]:
              - tab "日K" [selected] [ref=e66] [cursor=pointer]
              - tab "周K" [ref=e67] [cursor=pointer]
              - tab "月K" [ref=e68] [cursor=pointer]
            - button "多空反转" [ref=e69] [cursor=pointer]
            - generic "当日无业务操作" [ref=e70]
          - generic [ref=e72]:
            - group "K线行情" [ref=e73]:
              - generic [ref=e74]: 日K 2025-01-02 周四
              - generic [ref=e75]: 开 1524.00
              - generic [ref=e76]: 高 1524.49
              - generic [ref=e77]: 低 1480.00
              - generic [ref=e78]: 收 1488.00
              - generic [ref=e79]: 日涨幅 -2.36%
              - generic [ref=e80]: 最近已知K线
            - button "设置均线" [ref=e82] [cursor=pointer]: MA 设置
            - group "成交标记" [ref=e132]
          - generic [ref=e133]:
            - button "回到第一天" [disabled] [ref=e134]: 首日
            - button "上一日" [disabled] [ref=e135]
            - button "播放录制" [ref=e136] [cursor=pointer]: 播放
            - button "下一日" [disabled] [ref=e137]
            - button "跳到最后一天" [disabled] [ref=e138]: 末日
            - generic [ref=e139]:
              - text: 间隔
              - combobox "每日播放时长" [ref=e140]:
                - option "0.2 秒/日"
                - option "0.5 秒/日"
                - option "1 秒/日" [selected]
                - option "2 秒/日"
                - option "5 秒/日"
                - option "10 秒/日"
            - slider "回放日期" [ref=e141]: "0"
            - generic "空格 下一日 · PgUp/PgDn 前后日 · [ ] 周期 · ↑↓ 缩放 · ←→ 十字线 · Home 最新" [ref=e142]
        - complementary [ref=e143]:
          - generic [ref=e144]:
            - heading "账户摘要" [level=3] [ref=e145]
            - paragraph [ref=e146]: 600519 贵州茅台 · 2025-01-02
            - generic [ref=e147]:
              - generic [ref=e148]:
                - term [ref=e149]: 总权益
                - definition [ref=e150]: 100,000,000.00
              - generic [ref=e151]:
                - term [ref=e152]: 现金
                - definition [ref=e153]: 100,000,000.00
              - generic [ref=e154]:
                - term [ref=e155]: 市值
                - definition [ref=e156]: "0.00"
              - generic [ref=e157]:
                - term [ref=e158]: 持仓
                - definition [ref=e159]: 0 股
              - generic [ref=e160]:
                - term [ref=e161]: 可用
                - definition [ref=e162]: 0 股
              - generic [ref=e163]:
                - term [ref=e164]: 成本价
                - definition [ref=e165]: —
          - generic [ref=e166]:
            - heading "业务操作" [level=3] [ref=e167]
            - paragraph [ref=e168]: 录制中没有买卖与图形变更。
```

# Test source

```ts
  7   | //    （CARD-CONTENTS-OHLC / PCT-VALUE-CORRECT / PCT-COLOR-CONVENTION），卡在十字线交点右下方、
  8   | //    与指针热点区（±12px）不相交、不遮价格轴/时间轴（CARD-POSITION-NO-OCCLUDE），
  9   | //    pointer-events:none，localStorage 全程不变（PCT-NO-INTERFERE）；移到另一根立即隐藏并重计时；
  10  | //    指针离开图表立即隐藏；
  11  | // ② 键盘十字线（←/→）立即显示（无 1000ms 延时，CARD-KEYBOARD-INSTANT）；
  12  | //    卡可见期间框选缩放照常（交互不受干扰）；
  13  | // ③ 录像回放视图：导出→导入录制后，卡按回放数据序列同样计算（PCT-REPLAY-PARITY），
  14  | //    并缩小＋左滚到回放序列首根验证无前收占位 "--"（灰）——回放无动态补历史，首根可达。
  15  | // 数值口径由 server/test/percent-hover.test.ts 的架构师 oracle 表锁定；本套件用同一冻结公式
  16  | // 对实时数据独立计算期望（oracleCard 不调用页面实现）。
  17  | // 注意：库的 visibleRange().from 会低估实际屏上首根（左侧柱像素可能为负），悬停目标
  18  | // 一律按 pointToPixel 的屏内像素挑选，不直接用 range.from 当作屏上首根。
  19  | 
  20  | type Bar = { timestamp: number; open: number; high: number; low: number; close: number; date?: string }
  21  | type HoverTarget = { index: number; x: number; y: number }
  22  | type CardOracle = { date: string; rows: string[]; pct: { text: string; cls: string } }
  23  | 
  24  | const errors = new WeakMap<Page, string[]>()
  25  | 
  26  | test.beforeEach(({ page }) => {
  27  |   const list: string[] = []
  28  |   errors.set(page, list)
  29  |   page.on('pageerror', error => list.push(error.message))
  30  | })
  31  | test.afterEach(({ page }) => { expect(errors.get(page)).toEqual([]) })
  32  | 
  33  | /** 冻结公式（任务卡 2026-10-05）：pct=(close−prev)/prev×100 两位小数带符号；红涨/绿跌/零灰/首根"--" */
  34  | function oraclePct(close: number | null | undefined, previousClose: number | null | undefined): { text: string; cls: string } {
  35  |   const hasClose = typeof close === 'number' && Number.isFinite(close)
  36  |   const hasPrev = typeof previousClose === 'number' && Number.isFinite(previousClose) && previousClose !== 0
  37  |   if (!hasClose || !hasPrev) return { text: '--', cls: 'pct-flat' }
  38  |   const pct = ((close - previousClose) / previousClose) * 100
  39  |   const rounded = Math.round(pct * 100) / 100
  40  |   if (rounded === 0) return { text: '0.00%', cls: 'pct-flat' }
  41  |   return { text: `${rounded > 0 ? '+' : ''}${rounded.toFixed(2)}%`, cls: rounded > 0 ? 'pct-up' : 'pct-down' }
  42  | }
  43  | 
  44  | /** 卡内容独立期望：日期原样＋开/高/低/收两位小数＋涨幅（冻结公式），不调用页面实现 */
  45  | function oracleCard(bar: Bar, previousClose: number | null): CardOracle {
  46  |   return {
  47  |     date: bar.date ?? '',
  48  |     rows: [`开${bar.open.toFixed(2)}`, `高${bar.high.toFixed(2)}`, `低${bar.low.toFixed(2)}`, `收${bar.close.toFixed(2)}`],
  49  |     pct: oraclePct(bar.close, previousClose),
  50  |   }
  51  | }
  52  | 
  53  | async function createTraining(page: Page): Promise<void> {
  54  |   const active = await (await page.request.get('/api/trainings/active')).json()
  55  |   if (active.training) await page.request.post(`/api/trainings/${active.training.id}/abandon`)
  56  |   const response = await page.request.post('/api/trainings', {
  57  |     data: { code: '600519', tier: '1Y', start_date: '2025-01-02', initial_cash: 100_000_000 },
  58  |   })
  59  |   expect(response.status()).toBe(201)
  60  | }
  61  | 
  62  | async function openChart(page: Page): Promise<void> {
  63  |   await createTraining(page)
  64  |   await page.goto('/')
  65  |   await expect(page.locator('.training-current-date')).toBeVisible({ timeout: 15_000 })
  66  |   await expect(page.locator('.drawing-save-status')).toHaveText('已保存')
  67  |   await expect(page.locator('.loading-dot')).not.toBeVisible()
  68  |   await expect.poll(() => page.evaluate(() => (window as any).__trainerChart?.bars?.().length ?? 0)).toBeGreaterThan(2)
  69  | }
  70  | 
  71  | function card(page: Page) { return page.locator('[data-testid="hover-card"]') }
  72  | 
  73  | async function chartBars(page: Page): Promise<Bar[]> {
  74  |   return page.evaluate(() => (window as any).__trainerChart.bars())
  75  | }
  76  | 
  77  | /**
  78  |  * 按屏内像素挑可见悬停目标（上涨/下跌/居中各一，均在主图绘图区内）。
  79  |  * 纵向留底部余量：信息卡在指针下方约 14px 处展开（高约 120px），目标须离绘图区底缘足够远，
  80  |  * 卡才不会被底缘钳位上抬（钳位时"右下方＋避让指针"几何退化，属轴保护的优先口径，不在本测断言）。
  81  |  */
  82  | async function pickHoverTargets(page: Page): Promise<{ up: HoverTarget; down: HoverTarget; mid: HoverTarget }> {
  83  |   const picked = await page.evaluate(() => {
  84  |     const t = (window as any).__trainerChart
  85  |     const bars = t.bars()
  86  |     const range = t.visibleRange()
  87  |     const pane = t.panes().find((item: { name: string }) => item.name === 'candle_pane')
  88  |     const usable = (i: number): { index: number; x: number; y: number } | null => {
  89  |       const px = t.pointToPixel(bars[i].timestamp, bars[i].close)
  90  |       if (!px || typeof px.x !== 'number' || typeof px.y !== 'number') return null
  91  |       if (px.x < 30 || px.x > pane.width - 60) return null
  92  |       if (px.y < pane.top + 20 || px.y > pane.top + pane.height - 170) return null
  93  |       return { index: i, x: px.x, y: px.y }
  94  |     }
  95  |     let up: { index: number; x: number; y: number } | null = null
  96  |     let down: { index: number; x: number; y: number } | null = null
  97  |     const mids: Array<{ index: number; x: number; y: number }> = []
  98  |     for (let i = Math.max(1, Math.ceil(range.from)); i < Math.min(range.to, bars.length); i++) {
  99  |       const target = usable(i)
  100 |       if (!target) continue
  101 |       if (!up && bars[i].close > bars[i - 1].close) up = target
  102 |       if (!down && bars[i].close < bars[i - 1].close) down = target
  103 |       mids.push(target)
  104 |     }
  105 |     return { up, down, mid: mids[Math.floor(mids.length / 2)] ?? null }
  106 |   })
> 107 |   expect(picked.up, '可见窗口内存在可悬停的上涨 K 线').toBeTruthy()
      |                                          ^ Error: 可见窗口内存在可悬停的上涨 K 线
  108 |   expect(picked.down, '可见窗口内存在可悬停的下跌 K 线').toBeTruthy()
  109 |   expect(picked.mid, '可见窗口内存在可悬停的居中 K 线').toBeTruthy()
  110 |   return picked
  111 | }
  112 | 
  113 | /** 把鼠标移动到已挑好的悬停目标（宿主坐标系像素）；返回宿主 boundingBox 供后续步骤复用 */
  114 | async function hoverTarget(page: Page, target: HoverTarget): Promise<{ x: number; y: number; width: number; height: number }> {
  115 |   const host = (await page.locator('.chart-host').boundingBox())!
  116 |   await page.mouse.move(host.x + target.x, host.y + target.y, { steps: 4 })
  117 |   return host
  118 | }
  119 | 
  120 | /** 指针离开图表宿主（信息卡必须立即隐藏） */
  121 | async function leaveChart(page: Page, host: { x: number; y: number }): Promise<void> {
  122 |   await page.mouse.move(host.x - 30, host.y - 30, { steps: 4 })
  123 | }
  124 | 
  125 | /** 断言卡内容与独立期望一致（日期行＋开/高/低/收/涨幅五行＋涨幅配色档与计算色） */
  126 | async function expectCardContents(page: Page, expected: CardOracle): Promise<void> {
  127 |   // CHART-WEEKDAY-01：日K悬浮卡日期追加星期（'YYYY-MM-DD 周X'）；转义正则元字符后匹配
  128 |   const escapedDate = expected.date.replace(/[.*+?^${}()|[\]\\]/g, match => `\\${match}`)
  129 |   await expect(page.locator('.hover-card-date')).toHaveText(new RegExp(`^${escapedDate} 周[一二三四五六日]$`))
  130 |   await expect(page.locator('[data-testid="hover-card"] .hover-card-row')).toHaveText([...expected.rows, `涨幅${expected.pct.text}`])
  131 |   const pctValue = page.locator('[data-testid="hover-card"] .hover-card-row').last().locator('.hover-card-value')
  132 |   await expect(pctValue).toHaveClass(new RegExp(expected.pct.cls))
  133 |   const rgb = expected.pct.cls === 'pct-up' ? 'rgb(239, 68, 68)' : expected.pct.cls === 'pct-down' ? 'rgb(22, 163, 74)' : 'rgb(148, 163, 184)'
  134 |   expect(await pctValue.evaluate(el => getComputedStyle(el).color)).toBe(rgb)
  135 | }
  136 | 
  137 | test('hover card appears after a 1s dwell with oracle rows and CN colors, clears on bar change and chart leave, no persistence', async ({ page }) => {
  138 |   await openChart(page)
  139 |   const bars = await chartBars(page)
  140 |   const targets = await pickHoverTargets(page)
  141 |   const storageBefore = await page.evaluate(() => JSON.stringify({ ...localStorage }))
  142 | 
  143 |   // 停留 800ms：不可见（CARD-DWELL-DELAY：未满 1000ms）
  144 |   const host = await hoverTarget(page, targets.up)
  145 |   await page.waitForTimeout(800)
  146 |   await expect(card(page)).toHaveCount(0)
  147 |   // 继续停留到 ≥1100ms：可见（同一根内未移动，计时未重置）
  148 |   await page.waitForTimeout(400)
  149 |   await expect(card(page)).toBeVisible()
  150 | 
  151 |   // 卡内容＝冻结公式独立计算（日期＋开/高/低/收＋涨幅，红涨色）＋纯信息层不拦截指针
  152 |   await expectCardContents(page, oracleCard(bars[targets.up.index], bars[targets.up.index - 1].close))
  153 |   expect(await card(page).evaluate(el => getComputedStyle(el).pointerEvents)).toBe('none')
  154 | 
  155 |   // 位置（CARD-POSITION-NO-OCCLUDE）：① 与指针热点区（±12px）不相交；② 不遮价格轴/时间轴
  156 |   const box = (await card(page).boundingBox())!
  157 |   const pointerX = host.x + targets.up.x, pointerY = host.y + targets.up.y
  158 |   const HOTSPOT = 12
  159 |   const disjoint = box.x + box.width <= pointerX - HOTSPOT || box.x >= pointerX + HOTSPOT
  160 |     || box.y + box.height <= pointerY - HOTSPOT || box.y >= pointerY + HOTSPOT
  161 |   expect(disjoint, '信息卡与指针热点区不相交').toBe(true)
  162 |   const metrics = await page.evaluate(() => {
  163 |     const t = (window as any).__trainerChart
  164 |     const pane = t.panes().find((item: { name: string }) => item.name === 'candle_pane')
  165 |     const last = t.panes().at(-1)
  166 |     return { plotRight: pane.width, plotBottom: last.top + last.height }
  167 |   })
  168 |   expect(box.x + box.width).toBeLessThanOrEqual(host.x + metrics.plotRight + 2)
  169 |   expect(box.x).toBeGreaterThanOrEqual(host.x)
  170 |   expect(box.y + box.height).toBeLessThanOrEqual(host.y + metrics.plotBottom + 2)
  171 |   await page.screenshot({ path: evidencePath('hover-card-dwell-up.png') })
  172 | 
  173 |   // 移到另一根 K 线：立即隐藏（重计时），停满后按新 K 线数据重现（绿跌色）
  174 |   await hoverTarget(page, targets.down)
  175 |   await expect(card(page)).toHaveCount(0)
  176 |   await page.waitForTimeout(1150)
  177 |   await expect(card(page)).toBeVisible()
  178 |   await expectCardContents(page, oracleCard(bars[targets.down.index], bars[targets.down.index - 1].close))
  179 |   await page.screenshot({ path: evidencePath('hover-card-dwell-down.png') })
  180 | 
  181 |   // 指针离开图表：立即隐藏；再次悬停可重现
  182 |   await leaveChart(page, host)
  183 |   await expect(card(page)).toHaveCount(0)
  184 |   await hoverTarget(page, targets.up)
  185 |   await expect(card(page)).toHaveCount(0)
  186 |   await leaveChart(page, host)
  187 |   await expect(card(page)).toHaveCount(0)
  188 |   // 信息卡状态不写任何持久层：悬停＋切换＋离开全程 localStorage 逐字节不变
  189 |   expect(await page.evaluate(() => JSON.stringify({ ...localStorage }))).toBe(storageBefore)
  190 | })
  191 | 
  192 | test('keyboard crosshair shows the card instantly (no dwell) and box select still zooms while it shows', async ({ page }) => {
  193 |   await openChart(page)
  194 |   const bars = await chartBars(page)
  195 |   // 键盘十字线（→）：定位最后一根，600ms 内可见——证明无 1000ms 停留延时（CARD-KEYBOARD-INSTANT）
  196 |   await page.keyboard.press('ArrowRight')
  197 |   const last = await page.evaluate(() => {
  198 |     const range = (window as any).__trainerChart.visibleRange()
  199 |     return Math.min(range.to - 1, (window as any).__trainerChart.bars().length - 1)
  200 |   })
  201 |   await expect(card(page)).toBeVisible({ timeout: 600 })
  202 |   await expectCardContents(page, oracleCard(bars[last], bars[last - 1].close))
  203 |   // （←）：移到前一根，内容按前一根相对其前收重算
  204 |   await page.keyboard.press('ArrowLeft')
  205 |   await expectCardContents(page, oracleCard(bars[last - 1], bars[last - 2].close))
  206 | 
  207 |   // 卡可见期间框选缩放照常（pointer-events:none 不吞框选手势）
```