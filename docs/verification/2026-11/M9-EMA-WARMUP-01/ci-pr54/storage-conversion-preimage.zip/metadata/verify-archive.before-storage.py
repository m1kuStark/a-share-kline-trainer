import hashlib
import json
import subprocess
import zipfile
from pathlib import Path


root = Path(__file__).resolve().parents[1]
repo = root.parents[4]
archive = root / "ci-capture"
digest = lambda value: hashlib.sha256(value).hexdigest()
receipt = json.loads((root / "copy-receipt.json").read_text(encoding="utf-8"))
source = Path(receipt["sourceDirectory"])
actual_files = sorted(path.relative_to(archive).as_posix() for path in archive.rglob("*") if path.is_file())
expected_files = sorted(row["sourceRelativePath"] for row in receipt["files"])
assert actual_files == expected_files, "Archive file set changed"

for row in receipt["files"]:
    local = (root / row["archiveRelativePath"]).read_bytes()
    original = (source / row["sourceRelativePath"]).read_bytes()
    assert local == original, row["sourceRelativePath"]
    assert len(local) == row["bytes"], row["sourceRelativePath"]
    assert digest(local) == row["sourceSha256"] == row["archiveSha256"], row["sourceRelativePath"]

result = json.loads((archive / "result.json").read_text(encoding="utf-8"))
for capture in result["rawReceipts"]:
    assert capture["nativeExitCode"] == 0, capture["name"]
    for stream in ("stdout", "stderr"):
        data = (archive / (capture["name"] + "." + stream)).read_bytes()
        assert len(data) == capture[stream]["bytes"], capture["name"]
        assert digest(data) == capture[stream]["sha256"], capture["name"]

for alias in result["rawJsonAliases"]:
    path = archive / Path(alias["path"]).name
    data = path.read_bytes()
    assert len(data) == alias["bytes"] and digest(data) == alias["sha256"], path.name
    stdout = archive / (path.name.removesuffix(".raw.json") + ".stdout")
    assert data == stdout.read_bytes(), path.name

with zipfile.ZipFile(archive / "run-logs.zip") as bundle:
    assert bundle.testzip() is None, "ZIP CRC mismatch"
    assert len(bundle.infolist()) == len(result["logEntries"]) == 32
    for log in result["logEntries"]:
        local = archive / "logs" / Path(log["path"]).name
        data = local.read_bytes()
        assert len(data) == log["bytes"] and digest(data) == log["sha256"], local.name
        assert bundle.read(log["archive_name"]) == data, local.name

assert (archive / "run-logs.zip").read_bytes() == (archive / "run-logs-archive.stdout").read_bytes()
pr = json.loads((root / "merge-evidence/pr-merged.stdout").read_bytes())
commit = json.loads((root / "merge-evidence/merge-commit.stdout").read_bytes())
assert pr["state"] == "MERGED"
assert pr["headRefOid"] == result["head"]
assert pr["mergeCommit"]["oid"] == commit["sha"] == "58ba0ffc13458fb136c7d885b62ee0c898d4bab8"
assert [parent["sha"] for parent in commit["parents"]] == [result["testedBaseCommit"]]

for name in ("pr-merged", "merge-commit"):
    capture = json.loads((root / "merge-evidence" / (name + ".receipt.json")).read_bytes())
    assert capture["nativeExitCode"] == 0, name
    for stream in ("stdout", "stderr"):
        data = (root / capture[stream]["archiveRelativePath"]).read_bytes()
        assert len(data) == capture[stream]["bytes"] and digest(data) == capture[stream]["sha256"], name

head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
assert head == "3ec3d730a477ca305566eda28a6b1ddc190e2262", head
subprocess.run(["git", "merge-base", "--is-ancestor", commit["sha"], head], cwd=repo, check=True)

print(json.dumps({"archiveFiles": len(actual_files), "archiveBytes": sum(row["bytes"] for row in receipt["files"]),
                  "allByteAndHashEqual": True, "rawCapturesVerified": len(result["rawReceipts"]),
                  "jsonAliasesVerified": len(result["rawJsonAliases"]), "zipCrcPassed": True,
                  "zipLogsByteAndHashEqual": 32, "mergeCapturesVerified": 2,
                  "prState": pr["state"], "actualMergeCommit": commit["sha"],
                  "actualMergeIsHeadAncestor": True, "archiveHeadUnchanged": head}, indent=2))
