# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: random-mode.spec.ts >> random mode (M7-02) >> random period grid: tier options mirror classic and real creation with 3M succeeds
- Location: e2e\random-mode.spec.ts:257:3

# Error details

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 40
Received:    20
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary "主导航" [ref=e4]:
    - generic [ref=e5]: K
    - navigation [ref=e6]:
      - button "训练" [ref=e7] [cursor=pointer]
      - button "历史排行" [ref=e13] [cursor=pointer]:
        - generic [ref=e20]: 排行
      - button "历史训练" [ref=e21] [cursor=pointer]:
        - generic [ref=e26]: 历史
      - button "训练录像" [ref=e27] [cursor=pointer]:
        - generic [ref=e31]: 录像
    - button "保存并退出训练器" [ref=e32] [cursor=pointer]:
      - generic [ref=e35]: 退出
    - button "训练默认设置" [ref=e36] [cursor=pointer]:
      - generic [ref=e40]: 设置
  - main [ref=e41]:
    - generic [ref=e42]:
      - generic [ref=e43]: A股 K线训练器
      - generic [ref=e45]:
        - generic [ref=e47]:
          - generic [ref=e48]:
            - checkbox "记录操作" [checked] [ref=e49]
            - text: 记录操作
          - status [ref=e50]: 正在记录 · 0 次操作
          - button "导出录制" [ref=e51] [cursor=pointer]
        - button "切换到浅色主题" [ref=e52] [cursor=pointer]
        - generic [ref=e60]: TDX · 截止 2026-09-16
    - generic [ref=e61]:
      - generic [ref=e62]:
        - generic [ref=e63]:
          - generic [ref=e64]:
            - generic "贵州茅台 · 600519" [ref=e65]
            - generic "随机模式 · 随机时段" [ref=e66]: 随机模式
            - button "显示被隐藏的信息" [ref=e67] [cursor=pointer]
          - generic [ref=e73]:
            - text: 剩余未推进
            - strong [ref=e74]: "19"
            - text: 根 K 线
          - tablist "K线周期" [ref=e75]:
            - tab "日K" [selected] [ref=e76] [cursor=pointer]
            - tab "周K" [ref=e77] [cursor=pointer]
            - tab "月K" [ref=e78] [cursor=pointer]
          - group "副图指标开关" [ref=e79]:
            - button "VOL" [pressed] [ref=e80] [cursor=pointer]
            - button "MACD" [pressed] [ref=e81] [cursor=pointer]
            - button "KDJ" [pressed] [ref=e82] [cursor=pointer]
          - group [ref=e83]:
            - generic "训练详情" [ref=e84] [cursor=pointer]
        - generic [ref=e87]:
          - button "日线数据更新：重新读取本地日线（不联网）" [ref=e88] [cursor=pointer]: 更新
          - button "刷新图表" [ref=e89] [cursor=pointer]
          - button "回到最新K线" [ref=e95] [cursor=pointer]
          - button "推进下一日" [ref=e98] [cursor=pointer]
          - button "提前结算" [ref=e101] [cursor=pointer]
          - button "放弃训练" [ref=e102] [cursor=pointer]
      - generic [ref=e103]:
        - generic "训练就绪" [ref=e104]
        - generic "空格：推进下一日；[ / ]：日周月周期；Home：回到最新；↑ / ↓：缩放；Del：删除选中画线；B / S：买入卖出；Ctrl+Z / Ctrl+Y：撤销重做。输入、弹窗和画线取点期间部分快捷键暂停。" [ref=e105]: 空格 下一日 · [ ] 周期 · Home 最新 · ↑↓ 缩放 · Del 删线
        - generic [ref=e106]: 可见至 ******
        - generic "当前同屏K线根数 / 同屏上限" [ref=e107]: 154 / 840 根
      - generic [ref=e108]:
        - generic [ref=e110]:
          - button "设置均线" [ref=e112] [cursor=pointer]: MA 设置
          - group "成交标记" [ref=e153]
        - complementary [ref=e154]:
          - generic [ref=e155]:
            - generic [ref=e156]:
              - generic [ref=e157]: 训练账户
              - generic [ref=e158]: ● 进行中
            - generic [ref=e159]:
              - generic [ref=e160]: 账户权益
              - strong [ref=e161]:
                - generic [ref=e162]: ¥1,000,000
              - emphasis [ref=e163]:
                - generic [ref=e164]: +0.00%
            - generic [ref=e165]:
              - generic [ref=e166]:
                - generic [ref=e167]: 可用资金
                - strong [ref=e168]: ¥1,000,000
              - generic [ref=e169]:
                - generic [ref=e170]: 持仓市值
                - strong [ref=e171]: ¥0
              - generic [ref=e172]:
                - generic [ref=e173]: 持仓（可卖）
                - strong [ref=e174]: 0（0）
              - generic [ref=e175]:
                - generic [ref=e176]: 摊薄成本
                - strong [ref=e177]: "--"
            - generic [ref=e179]:
              - tablist "下单方式" [ref=e180]:
                - tab "普通下单" [selected] [ref=e181] [cursor=pointer]
              - generic [ref=e182]: 按当日收盘价成交
            - generic [ref=e183]:
              - button "10%" [ref=e184] [cursor=pointer]
              - button "20%" [ref=e185] [cursor=pointer]
              - button "25%" [ref=e186] [cursor=pointer]
              - button "30%" [ref=e187] [cursor=pointer]
              - button "50%" [ref=e188] [cursor=pointer]
              - button "75%" [ref=e189] [cursor=pointer]
              - button "100%" [ref=e190] [cursor=pointer]
              - spinbutton "自定义%" [ref=e191]
            - generic [ref=e192]:
              - spinbutton "按股数买卖" [ref=e193]
              - generic [ref=e194]: 留空则按左侧比例
            - generic [ref=e195]:
              - button "买入" [ref=e196] [cursor=pointer]
              - button "卖出" [ref=e197] [cursor=pointer]
          - generic [ref=e198]:
            - generic [ref=e199]:
              - button "折叠画线工具条" [expanded] [ref=e200] [cursor=pointer]
              - generic [ref=e203]: 常用工具
              - button "自定义常用" [ref=e204] [cursor=pointer]
            - generic [ref=e208]:
              - generic [ref=e209]:
                - button "线段" [ref=e211] [cursor=pointer]
                - button "射线" [ref=e213] [cursor=pointer]
                - button "直线" [ref=e215] [cursor=pointer]
                - button "水平直线" [ref=e217] [cursor=pointer]
                - button "垂直直线" [ref=e219] [cursor=pointer]
                - button "价位线" [ref=e221] [cursor=pointer]
                - button "百分比线" [ref=e223] [cursor=pointer]
              - button "其他工具 16" [ref=e224] [cursor=pointer]:
                - text: 其他工具
                - generic [ref=e227]: "16"
            - generic [ref=e228]:
              - button "多选" [ref=e229] [cursor=pointer]
              - button "撤销" [disabled] [ref=e230]
              - button "重做" [disabled] [ref=e234]
              - button "清空" [ref=e238] [cursor=pointer]
              - combobox "吸附" [ref=e242]:
                - option "关闭"
                - option "弱吸附" [selected]
                - option "强吸附"
            - status "已保存" [ref=e244]
```

# Test source

```ts
  193 | 
  194 |     const createBodies: Array<Record<string, unknown>> = []
  195 |     await page.route('**/api/trainings/random', async route => {
  196 |       createBodies.push(JSON.parse(route.request().postData() ?? '{}'))
  197 |       await route.fulfill({ status: 201, json: { training: { id: 9102 } } })
  198 |     })
  199 |     // 默认 3个月档 → window_months=3，不带 window_bars
  200 |     await page.getByRole('button', { name: '开始训练', exact: true }).click()
  201 |     await expect.poll(() => createBodies.length).toBe(1)
  202 |     expect(createBodies[0].dimension).toBe('random_time')
  203 |     expect(createBodies[0].code).toBe('600519')
  204 |     expect(createBodies[0].window_months).toBe(3)
  205 |     expect(createBodies[0].window_bars).toBeUndefined()
  206 |     expect(createBodies[0].start_date).toBeUndefined()
  207 |     expect(createBodies[0].end_date).toBeUndefined()
  208 | 
  209 |     // 切 1年 档 → window_months=12
  210 |     await page.getByRole('button', { name: '1年', exact: true }).click()
  211 |     await page.getByRole('button', { name: '开始训练', exact: true }).click()
  212 |     await expect.poll(() => createBodies.length).toBe(2)
  213 |     expect(createBodies[1].window_months).toBe(12)
  214 |     expect(createBodies[1].window_bars).toBeUndefined()
  215 | 
  216 |     // 自定义根数档（旧 window_bars 口径保留）：根数输入进场，默认 250
  217 |     await page.getByRole('button', { name: '自定义根数', exact: true }).click()
  218 |     const windowInput = page.getByLabel('训练窗口长度（交易日）')
  219 |     await expect(windowInput).toBeVisible()
  220 |     expect(await windowInput.inputValue()).toBe('250')
  221 |     await windowInput.fill('40')
  222 |     await page.getByRole('button', { name: '开始训练', exact: true }).click()
  223 |     await expect.poll(() => createBodies.length).toBe(3)
  224 |     expect(createBodies[2].window_bars).toBe(40)
  225 |     expect(createBodies[2].window_months).toBeUndefined()
  226 |   })
  227 | 
  228 |   test('random panel: dimension-driven control visibility and payload for random_both', async ({ page }) => {
  229 |     await openLauncher(page)
  230 |     await switchToRandomMode(page)
  231 |     await page.getByRole('button', { name: DIMENSION_BUTTON.random_both }).click()
  232 | 
  233 |     // 全随机：选股器与起止日都退场；训练周期档位网格在（默认 3个月 → window_months=3）
  234 |     await expect(page.getByPlaceholder(CODE_INPUT)).toHaveCount(0)
  235 |     await expect(page.locator('input[type="date"]')).toHaveCount(0)
  236 |     await expect(page.getByLabel('训练窗口长度（交易日）')).toHaveCount(0)
  237 |     const tier3M = page.getByRole('button', { name: '3个月', exact: true })
  238 |     await expect(tier3M).toBeVisible()
  239 |     await expect(tier3M).toHaveClass(/selected/)
  240 | 
  241 |     let createBody: Record<string, unknown> | null = null
  242 |     await page.route('**/api/trainings/random', async route => {
  243 |       createBody = JSON.parse(route.request().postData() ?? '{}')
  244 |       await route.fulfill({ status: 201, json: { training: { id: 9103 } } })
  245 |     })
  246 |     await page.getByRole('button', { name: '开始训练', exact: true }).click()
  247 |     await expect.poll(() => createBody).toBeTruthy()
  248 |     expect(createBody!.dimension).toBe('random_both')
  249 |     expect(createBody!.window_months).toBe(3)
  250 |     expect(createBody!.window_bars).toBeUndefined()
  251 |     expect(createBody!.code).toBeUndefined()
  252 |     expect(createBody!.start_date).toBeUndefined()
  253 |     expect(createBody!.end_date).toBeUndefined()
  254 |   })
  255 | 
  256 |   // RF-04 真实创建：档位网格与经典同文案（五档＋自定义根数），选 3个月真实创建成功
  257 |   test('random period grid: tier options mirror classic and real creation with 3M succeeds', async ({ page }) => {
  258 |     const search = await searchRealStocks(page, '600519')
  259 |     expect(search.length, '真实目录应能检索到 600519').toBeGreaterThan(0)
  260 |     const code = search[0].code
  261 | 
  262 |     await openLauncher(page)
  263 |     await switchToRandomMode(page)
  264 |     await page.getByRole('button', { name: DIMENSION_BUTTON.random_time }).click()
  265 | 
  266 |     // 档位网格与经典训练周期同文案：五档＋自定义根数；默认 3个月；根数输入退场
  267 |     for (const label of ['1个月', '3个月', '6个月', '1年', '2年', '自定义根数']) {
  268 |       await expect(page.getByRole('button', { name: label, exact: true })).toBeVisible()
  269 |     }
  270 |     await expect(page.getByRole('button', { name: '3个月', exact: true })).toHaveClass(/selected/)
  271 |     await expect(page.getByLabel('训练窗口长度（交易日）')).toHaveCount(0)
  272 | 
  273 |     await page.getByPlaceholder(CODE_INPUT).fill(code)
  274 |     await expect(page.locator('.suggestions button').first()).toBeVisible()
  275 |     await page.locator('.suggestions button').first().click()
  276 |     await expect(page.getByText(/已选：/)).toBeVisible()
  277 | 
  278 |     await page.getByRole('button', { name: '开始训练', exact: true }).click()
  279 |     await waitTrainingInteractive(page)
  280 | 
  281 |     const active = await (await page.request.get('/api/trainings/active')).json() as {
  282 |       training: {
  283 |         tier: string
  284 |         random: { dimension: string; hideStock: boolean; hideTime: boolean }
  285 |         range: { mode: string; barCount: number }
  286 |       }
  287 |     }
  288 |     expect(active.training.random).toEqual({ dimension: 'random_time', hideStock: false, hideTime: true, remainingBars: expect.any(Number) })
  289 |     // 录制契约冻结：随机训练 tier 恒 RANGE 哨兵（档位口径进 range.notes）
  290 |     expect(active.training.tier).toBe('RANGE')
  291 |     expect(active.training.range.mode).toBe('random')
  292 |     // 3 个自然月 ≈ 40–70 个交易日（真实数据容差口径）
> 293 |     expect(active.training.range.barCount).toBeGreaterThanOrEqual(40)
      |                                            ^ Error: expect(received).toBeGreaterThanOrEqual(expected)
  294 |     expect(active.training.range.barCount).toBeLessThanOrEqual(70)
  295 |   })
  296 | 
  297 |   // RF2-01 真实创建：random_stock 档位网格与经典同文案（五档＋自定义范围，无自定义根数档），
  298 |   // 默认 3个月真实创建成功（窗口＝最近 3 个自然月，股票由服务器随机并隐藏）；
  299 |   // RF3-01 档位下起始日输入在场（照搬经典），改起始日后真实创建＝起始日起 3 自然月窗口
  300 |   test('random stock period grid: tier options mirror classic and real creation with 3M succeeds', async ({ page }) => {
  301 |     const liquid = (await searchRealStocks(page, '600519'))[0]
  302 |     expect(liquid?.lastDate, '真实目录应给出 600519 的 lastDate').toBeTruthy()
  303 | 
  304 |     await openLauncher(page)
  305 |     await switchToRandomMode(page)
  306 | 
  307 |     // 默认维度＝随机股票：档位网格与经典训练周期同文案（五档＋自定义范围）；根数输入退场
  308 |     for (const label of ['1个月', '3个月', '6个月', '1年', '2年', '自定义范围']) {
  309 |       await expect(page.getByRole('button', { name: label, exact: true })).toBeVisible()
  310 |     }
  311 |     await expect(page.getByRole('button', { name: '自定义根数', exact: true })).toHaveCount(0)
  312 |     await expect(page.getByRole('button', { name: '3个月', exact: true })).toHaveClass(/selected/)
  313 |     await expect(page.getByLabel('训练窗口长度（交易日）')).toHaveCount(0)
  314 |     // RF3-01 起始日输入在场（单输入，非自定义范围起止对），默认＝锚点回退 3 自然月
  315 |     const stockStart = page.locator('input[type="date"]')
  316 |     await expect(stockStart).toHaveCount(1)
  317 |     await expect(stockStart).toHaveValue('2026-06-24')
  318 | 
  319 |     // 改起始日（真实数据窗内、距数据末日约 6.5 自然月 → 3 自然月窗完整落在数据内）后创建
  320 |     const userStart = minusDays(liquid.lastDate as string, 200)
  321 |     await stockStart.fill(userStart)
  322 |     await page.getByRole('button', { name: '开始训练', exact: true }).click()
  323 |     await waitTrainingInteractive(page)
  324 | 
  325 |     const active = await (await page.request.get('/api/trainings/active')).json() as {
  326 |       training: {
  327 |         tier: string
  328 |         startDate: string
  329 |         random: { dimension: string; hideStock: boolean; hideTime: boolean }
  330 |         range: { mode: string; barCount: number }
  331 |       }
  332 |     }
  333 |     expect(active.training.random).toEqual({ dimension: 'random_stock', hideStock: true, hideTime: false, remainingBars: expect.any(Number) })
  334 |     // 录制契约冻结：随机训练 tier 恒 RANGE 哨兵（档位口径进 range.notes）
  335 |     expect(active.training.tier).toBe('RANGE')
  336 |     expect(active.training.range.mode).toBe('random')
  337 |     // 服务端把起始日对齐到前方最近交易日（≤ 用户输入，且不在数据边缘）
  338 |     expect(new Date(active.training.startDate).getTime()).toBeLessThanOrEqual(Date.parse(`${userStart}T00:00:00Z`))
  339 |     expect(new Date(active.training.startDate).getTime()).toBeGreaterThanOrEqual(Date.parse(`${userStart}T00:00:00Z`) - 10 * 86_400_000)
  340 |     // 用户起始日起 3 个自然月 ≈ 40–70 个交易日（真实数据容差口径，同 random_time 档位）
  341 |     expect(active.training.range.barCount).toBeGreaterThanOrEqual(40)
  342 |     expect(active.training.range.barCount).toBeLessThanOrEqual(70)
  343 |   })
  344 | 
  345 |   // RF-05 星号遮蔽（RAND-UI-MASK-STARS）：隐藏股票＝密码输入式 * 号（非占位文字）＋徽标＋眼睛按钮；
  346 |   // random_stock 日期不隐藏（RANDOM-HIDE-TIME-REMAINING 维度联动），当前日期按服务端下发原样呈现
  347 |   test('masked session: hidden stock shows star-masked title and badge while dates render as served', async ({ page }) => {
  348 |     // 真实创建（random_stock：隐藏股票、日期真实）；窗口末缘取目录流动股 lastDate 前推 14 天，
  349 |     // 保证随机池中 lastDate ≥ end 的股票充足（不依赖冷启慢完成的数据状态扫描）
  350 |     const liquid = (await searchRealStocks(page, '600519'))[0]
  351 |     expect(liquid?.lastDate, '真实目录应给出 600519 的 lastDate').toBeTruthy()
  352 |     const windowEnd = minusDays(liquid.lastDate as string, 14)
  353 |     const windowStart = minusMonths(windowEnd, 3)
  354 | 
  355 |     await openLauncher(page)
  356 |     await switchToRandomMode(page)
  357 |     // RF2-01 起随机股票默认档位网格；本用例走旧起止日期口径，先切「自定义范围」档
  358 |     await page.getByRole('button', { name: '自定义范围', exact: true }).click()
  359 |     const dates = page.locator('input[type="date"]')
  360 |     await dates.nth(0).fill(windowStart)
  361 |     await dates.nth(1).fill(windowEnd)
  362 |     await page.getByRole('button', { name: '开始训练', exact: true }).click()
  363 | 
  364 |     await waitTrainingInteractive(page)
  365 |     // 遮蔽态：星号遮蔽标题（不含任何股票名/码）＋徽标＋眼睛按钮；旧占位文字退场
  366 |     await expect(page.locator('.workspace-title')).toHaveText('****** · ******')
  367 |     await expect(page.locator('.workspace-title')).not.toContainText('随机标的')
  368 |     await expect(page.locator('.random-mode-badge')).toBeVisible()
  369 |     await expect(page.getByRole('button', { name: '显示被隐藏的信息' })).toBeVisible()
  370 |     const active = await (await page.request.get('/api/trainings/active')).json() as {
  371 |       training: { code: string | null; name: string | null; currentDate: string | null; random: { dimension: string; hideStock: boolean; hideTime: boolean; remainingBars: number } }
  372 |     }
  373 |     expect(active.training.code).toBeNull()
  374 |     expect(active.training.name).toBeNull()
  375 |     expect(active.training.random).toEqual({ dimension: 'random_stock', hideStock: true, hideTime: false, remainingBars: expect.any(Number) })
  376 |     // random_stock 维度联动：日期不隐藏，当前日期真实呈现
  377 |     await expect(page.locator('.training-current-date strong')).toHaveText(active.training.currentDate ?? '')
  378 |     await expect(page.locator('.training-current-date')).toContainText('当前')
  379 |   })
  380 | 
  381 |   // RF-05 眼睛按钮＋确认揭示（RAND-UI-MASK-STARS / RANDOM-REVEAL-MIDRUN）：全随机会话；
  382 |   // 取消维持遮蔽；确认（spoiler 风险自担文案）后显示真实标的与真实日期；再点恢复遮蔽
  383 |   test('eye toggle: confirm reveals real stock and dates, cancel keeps mask, re-click restores', async ({ page }) => {
  384 |     await openLauncher(page)
  385 |     await switchToRandomMode(page)
  386 |     await page.getByRole('button', { name: DIMENSION_BUTTON.random_both }).click()
  387 |     await page.getByRole('button', { name: '自定义根数', exact: true }).click()
  388 |     await page.getByLabel('训练窗口长度（交易日）').fill('20')
  389 |     await page.getByRole('button', { name: '开始训练', exact: true }).click()
  390 |     await waitTrainingInteractive(page)
  391 | 
  392 |     // 遮蔽态：标题星号＋日期区显示剩余根数（random_both 双隐藏）
  393 |     await expect(page.locator('.workspace-title')).toHaveText('****** · ******')
```