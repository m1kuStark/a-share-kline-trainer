# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: m4-rankings.spec.ts >> 运行中守卫（排行关闭、零行）与放弃不入榜（浅色840）
- Location: e2e\m4-rankings.spec.ts:150:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('button', { name: '开始训练' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('button', { name: '开始训练' }) with timeout 5000ms
  - waiting for getByRole('button', { name: '开始训练' })

```

```yaml
- complementary "主导航":
  - text: K
  - navigation:
    - button "训练"
    - button "历史排行": 排行
    - button "历史训练": 历史
    - button "训练录像": 录像
  - button "保存并退出训练器": 退出
  - button "训练默认设置": 设置
- main:
  - text: A股 K线训练器 创建训练
  - button "切换到浅色主题"
  - status "应收收盘日为 2026-10-19，但来源最大日期未知，无法确认数据新鲜度。来源末日不证明所有股票完整。": 数据截至 2026-09-16，最新交易日待确认
  - button "重新读取"
  - heading "创建训练" [level=1]
  - paragraph: 选一只股票、一个周期档和一个起始日，从起始日向前盲走训练。创建后复权方式锁定，训练中不可切换。
  - tablist "训练模式":
    - tab "经典模式" [selected]
    - tab "随机模式"
  - region "训练配置":
    - region "标的与时间":
      - heading "标的与时间" [level=2]
      - text: 确定这一局的练习范围 股票
      - textbox "股票代码":
        - /placeholder: 股票代码，如 600519
      - textbox "股票名称":
        - /placeholder: 股票名称，如 贵州茅台（可用拼音首字母 GZMT）
      - text: 训练周期
      - button "1个月"
      - button "3个月"
      - button "6个月"
      - button "1年"
      - button "2年"
      - button "自定义范围"
      - text: 起始日
      - textbox: 2026-07-20
      - text: 选择周期后自动从最新数据日回退对应时长；手动修改保留到下次切换周期。起始日之前最多 840 根 K 线同屏显示 初始资金
      - spinbutton: "1000000"
    - region "本局规则":
      - heading "本局规则" [level=2]
      - text: 创建后按以下设置训练 复权方式（创建后锁定）
      - button "前复权"
      - button "不复权"
      - text: 训练时钟
      - button "仅收盘"
      - button "开盘 + 收盘"
      - text: 开盘 + 收盘会把每个交易日拆成两个阶段；阶段和成交价在创建后锁定。
      - checkbox "启用条件单"
      - text: 启用条件单
      - checkbox "记录操作" [checked]
      - text: 记录操作 建议保持开启，方便复盘、分享操作和排查问题。记录保存在本机浏览器，可随时暂停。
    - paragraph: 正在读取训练默认设置…
    - button "开始训练" [disabled]
```

# Test source

```ts
  1   | // M4-01 历史排行（旧称五档排行）e2e：真实隔离服务＋真实样本数据（600519/300857）。
  2   | // 覆盖（真实用户动作，不用 API 替代关键用户路径）：
  3   | // 真实买入/卖出/结算两局 → 侧栏排行 → 切 3个月档 → 按本局 id 定位两行（提前结算组＋实际天数、
  4   | // 指标列呈现：零卖出胜率/盈亏比 '--' 不冒充 0、已平仓胜率 100%）→ 点行打开成绩单 →
  5   | // 排行行点击打开成绩单事实浮窗 → 关闭；成绩单暂不承载 K 线复盘。
  6   | // 运行中守卫（排行 409 说明、零行）与放弃不入榜；深/浅 1440/840 截图与 pageerror 0。
  7   | // 共库约定（FM-015/F1）：排行断言一律按本局创建的 training id 定位（data-training-id），
  8   | // 不作绝对行数假设；基准超额取决于样本 TDX 是否含 sh000300 日线，不硬编码数值，只禁 NaN/undefined。
  9   | import { startTrainingFromForm } from './training-flow'
  10  | import { expect, test, type Page } from '@playwright/test'
  11  | import { evidencePath } from './runtime'
  12  | 
  13  | test.describe.configure({ mode: 'serial' })
  14  | test.use({ viewport: { width: 1440, height: 940 } })
  15  | 
  16  | async function resetToLauncher(page: Page): Promise<void> {
  17  |   const active = (await (await page.request.get('/api/trainings/active')).json()).training
  18  |   if (active) await page.request.post(`/api/trainings/${active.id}/abandon`)
  19  |   await page.goto('/')
  20  |   await page.waitForTimeout(400)
> 21  |   await expect(page.getByRole('button', { name: '开始训练' })).toBeVisible()
      |                                                            ^ Error: expect(locator).toBeVisible() failed
  22  | }
  23  | 
  24  | /** 表单创建 3 个月训练并返回本局 id（排行断言一律按此 id 定位自己的行）。 */
  25  | async function createTrainingFromForm(page: Page, code: string): Promise<number> {
  26  |   await resetToLauncher(page)
  27  |   // UI-03 双框选股（Launcher.vue 代码框 placeholder＝『股票代码，如 600519』）：填精确代码，
  28  |   // 搜索结果必须由用户点击确认，避免精确输入产生隐式选择。
  29  |   await page.getByPlaceholder('股票代码，如 600519').fill(code)
  30  |   await expect(page.locator('.suggestions button').first()).toBeVisible()
  31  |   await page.locator('.suggestions button').first().click()
  32  |   await expect(page.getByText(/已选：/)).toBeVisible()
  33  |   await page.getByRole('button', { name: '3个月' }).click()
  34  |   // 股票已由用户明确选中；切周期不会重新打开建议列表。
  35  |   await expect(page.getByText(/已选：/)).toBeVisible()
  36  |   await page.locator('input[type="date"]').fill('2026-09-01')
  37  |   await startTrainingFromForm(page)
  38  |   await expect(page.locator('.training-meta')).toContainText('时长 3个月')
  39  |   const snapshot = (await (await page.request.get('/api/trainings/active')).json())
  40  |   return snapshot.training.id
  41  | }
  42  | 
  43  | async function waitRecordingReady(page: Page): Promise<void> {
  44  |   await expect(page.getByRole('status').filter({ hasText: '正在记录' })).toBeVisible()
  45  |   await expect(page.locator('.training-grid')).not.toHaveAttribute('inert', '')
  46  | }
  47  | 
  48  | async function buyAll(page: Page): Promise<void> {
  49  |   await page.getByRole('button', { name: '100%', exact: true }).click()
  50  |   await page.getByRole('button', { name: '买入', exact: true }).click()
  51  |   await expect(page.locator('.status-message')).toContainText('买入成交')
  52  | }
  53  | 
  54  | async function sellAll(page: Page): Promise<void> {
  55  |   await page.getByRole('button', { name: '100%', exact: true }).click()
  56  |   await page.getByRole('button', { name: '卖出', exact: true }).click()
  57  |   await expect(page.locator('.status-message')).toContainText('卖出成交')
  58  | }
  59  | 
  60  | async function advanceDays(page: Page, days: number): Promise<void> {
  61  |   for (let index = 0; index < days; index += 1) {
  62  |     await page.getByRole('button', { name: '推进下一日' }).click()
  63  |     await expect(page.getByRole('button', { name: '推进下一日' })).toBeEnabled({ timeout: 15_000 })
  64  |   }
  65  | }
  66  | 
  67  | async function settleThroughButtons(page: Page): Promise<void> {
  68  |   await page.getByRole('button', { name: '提前结算', exact: true }).click()
  69  |   const dialog = page.getByRole('dialog', { name: '结束训练' })
  70  |   await expect(dialog).toBeVisible()
  71  |   await dialog.getByRole('button', { name: '确认结算', exact: true }).click()
  72  |   await expect(page.getByRole('dialog', { name: '训练结算' })).toBeVisible()
  73  | }
  74  | 
  75  | function railButton(page: Page, label: string): ReturnType<Page['locator']> {
  76  |   return page.locator('.rail-item').filter({ has: page.locator(`text="${label}"`) })
  77  | }
  78  | 
  79  | async function openRankings(page: Page): Promise<void> {
  80  |   await railButton(page, '排行').click()
  81  |   await expect(page.getByRole('region', { name: '历史排行' })).toBeVisible()
  82  | }
  83  | 
  84  | test('结算两局→排行定位本局行→指标呈现→打开事实成绩单（深色1440）', async ({ page }) => {
  85  |   test.setTimeout(240_000)
  86  |   const errors: string[] = []
  87  |   page.on('pageerror', error => errors.push(error.message))
  88  | 
  89  |   // 第一局：买入→次日全卖（1 笔已平仓，胜率 100%）→ 提前结算
  90  |   const tradedId = await createTrainingFromForm(page, '600519')
  91  |   await waitRecordingReady(page)
  92  |   await buyAll(page)
  93  |   await advanceDays(page, 1)
  94  |   await sellAll(page)
  95  |   await settleThroughButtons(page)
  96  |   await page.getByRole('dialog', { name: '训练结算' }).getByRole('button', { name: '完成，返回首页' }).click()
  97  | 
  98  |   // 第二局：只买入不卖出（零卖出 → 胜率/盈亏比 '--'）→ 提前结算
  99  |   const buyOnlyId = await createTrainingFromForm(page, '300857')
  100 |   await waitRecordingReady(page)
  101 |   await buyAll(page)
  102 |   await settleThroughButtons(page)
  103 |   // 结算面板是模态（settle-mask 拦截指针）：先关闭再走侧栏入口，否则排行按钮点不进
  104 |   await page.getByRole('dialog', { name: '训练结算' }).getByRole('button', { name: '完成，返回首页' }).click()
  105 | 
  106 |   await openRankings(page)
  107 |   // 默认 1个月档为空或只有他局：切到 3个月档
  108 |   await page.getByRole('button', { name: '3个月' }).click()
  109 |   const rankings = page.getByRole('region', { name: '历史排行' })
  110 |   await expect(rankings.getByRole('heading', { name: /完整周期/ })).toBeVisible()
  111 |   await expect(rankings.getByRole('heading', { name: /提前结算/ })).toBeVisible()
  112 | 
  113 |   // 按本局 id 定位：两局都是提前结算，进提前结算组
  114 |   const tradedRow = rankings.locator(`.rankings-row[data-training-id="${tradedId}"]`)
  115 |   const buyOnlyRow = rankings.locator(`.rankings-row[data-training-id="${buyOnlyId}"]`)
  116 |   await expect(tradedRow).toBeVisible()
  117 |   await expect(buyOnlyRow).toBeVisible()
  118 |   await expect(tradedRow).toContainText('600519')
  119 |   // 指标呈现：数值不含 NaN/undefined
  120 |   for (const row of [tradedRow, buyOnlyRow]) {
  121 |     const text = await row.innerText()
```