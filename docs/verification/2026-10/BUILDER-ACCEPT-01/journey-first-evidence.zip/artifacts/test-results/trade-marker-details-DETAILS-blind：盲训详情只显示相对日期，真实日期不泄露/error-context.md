# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: trade-marker-details.spec.ts >> DETAILS-blind：盲训详情只显示相对日期，真实日期不泄露
- Location: e2e\trade-marker-details.spec.ts:327:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.trade-marker-badge')
Expected: 1
Received: 0
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('.trade-marker-badge') with timeout 5000ms
  - waiting for locator('.trade-marker-badge')
    14 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - complementary "主导航" [ref=f1e4]:
    - generic [ref=f1e5]: K
    - navigation [ref=f1e6]:
      - button "训练" [ref=f1e7] [cursor=pointer]
      - button "历史排行" [ref=f1e13] [cursor=pointer]:
        - generic [ref=f1e20]: 排行
      - button "历史训练" [ref=f1e21] [cursor=pointer]:
        - generic [ref=f1e26]: 历史
      - button "训练录像" [ref=f1e27] [cursor=pointer]:
        - generic [ref=f1e31]: 录像
    - button "保存并退出训练器" [ref=f1e32] [cursor=pointer]:
      - generic [ref=f1e35]: 退出
    - button "训练默认设置" [ref=f1e36] [cursor=pointer]:
      - generic [ref=f1e40]: 设置
  - main [ref=f1e41]:
    - generic [ref=f1e42]:
      - generic [ref=f1e43]: A股 K线训练器
      - generic [ref=f1e45]:
        - button "切换到浅色主题" [ref=f1e46] [cursor=pointer]
        - generic [ref=f1e54]: TDX 未连接
    - generic [ref=f1e55]: 正在连接本地服务…
```

# Test source

```ts
  231 |   // 解固定后恢复普通关闭：外部按下关闭
  232 |   await panel(page).getByRole('button', { name: '已固定', exact: true }).click()
  233 |   await expect(panel(page).getByRole('button', { name: '固定', exact: true })).toHaveAttribute('aria-pressed', 'false')
  234 |   await page.locator('.chart-host').click({ position: { x: 200, y: 120 } })
  235 |   await expect(panel(page)).toHaveCount(0)
  236 | 
  237 |   // 切回日K（周K右缘相邻周线合并为一个徽标），再做 Esc 关闭与焦点归还序列
  238 |   await page.keyboard.press('BracketLeft')
  239 |   await expect(page.locator('.timeframe-tabs button.selected')).toHaveText('日K')
  240 |   await expect(page.locator('.loading-dot')).not.toBeVisible()
  241 | 
  242 |   // Esc 始终可关闭（含固定态），焦点归还徽标
  243 |   await page.locator('.trade-marker-badge[data-count="2"]').click()
  244 |   await panel(page).getByRole('button', { name: '固定', exact: true }).click()
  245 |   await page.keyboard.press('Escape')
  246 |   await expect(panel(page)).toHaveCount(0)
  247 |   expect(await page.evaluate(() => document.activeElement?.className)).toContain('trade-marker-badge')
  248 | })
  249 | 
  250 | test('DETAILS-replay-hotkeys：浮层内 Space/B/S/Delete/方向不触发交易、推进或画线', async ({ page }) => {
  251 |   const id = await open(page)
  252 |   expect((await page.request.post(`/api/trainings/${id}/trade`, { data: { side: 'buy', weightPct: 1 } })).ok()).toBe(true)
  253 |   await page.reload()
  254 |   await expect(page.locator('.trade-marker-badge')).toHaveCount(1)
  255 |   await page.locator('.trade-marker-badge').click()
  256 |   await panel(page).getByRole('button', { name: '固定', exact: true }).focus()
  257 | 
  258 |   const before = await (await page.request.get(`/api/trainings/${id}`)).json()
  259 |   for (const key of ['Space', 'b', 's', 'B', 'S', 'Delete', 'ArrowDown', 'ArrowUp']) await page.keyboard.press(key)
  260 |   const after = await (await page.request.get(`/api/trainings/${id}`)).json()
  261 |   expect(after.trades).toHaveLength(before.trades.length)
  262 |   expect(after.training.currentDate).toBe(before.training.currentDate)
  263 |   // 固定按钮吃到的 Space 只切换自身按压态，面板保持打开
  264 |   await expect(panel(page)).toBeVisible()
  265 |   await page.keyboard.press('Escape')
  266 |   await expect(panel(page)).toHaveCount(0)
  267 | })
  268 | 
  269 | test('DETAILS-replay-no-future：离线回放可查看，退至成交日前立即隐藏且无业务写请求', async ({ page }) => {
  270 |   test.setTimeout(120_000)
  271 |   const active = await (await page.request.get('/api/trainings/active')).json()
  272 |   if (active.training) await page.request.post(`/api/trainings/${active.training.id}/abandon`)
  273 |   await page.goto('/')
  274 |   await expect(page.getByLabel('记录操作', { exact: true })).toBeChecked()
  275 |   await page.getByPlaceholder('股票代码，如 600519').fill('600519')
  276 | await expect(page.locator(".suggestions button").first()).toBeVisible()
  277 | await page.locator(".suggestions button").first().click()
  278 |   await expect(page.getByText(/已选：/)).toBeVisible()
  279 |   await page.locator('input[type="date"]').fill('2026-09-01')
  280 |   await startTrainingFromForm(page)
  281 |   await page.getByRole('button', { name: '买入', exact: true }).click()
  282 |   await expect(page.locator('.status-message')).toContainText(/成交|买入/)
  283 |   await page.getByRole('button', { name: '推进下一日', exact: true }).click()
  284 |   await page.getByRole('button', { name: '买入', exact: true }).click()
  285 |   await expect(page.locator('.status-message')).toContainText(/成交|买入/)
  286 | 
  287 |   const pending = page.waitForEvent('download')
  288 |   await page.getByRole('button', { name: '导出录制', exact: true }).click()
  289 |   const download = await pending
  290 |   const output = evidencePath('details-recorded.json.gz')
  291 |   await download.saveAs(output)
  292 | 
  293 |   await page.getByRole('button', { name: '训练录像', exact: true }).click()
  294 |   await expect(page.getByRole('heading', { name: '训练录像', exact: true })).toBeVisible()
  295 |   await page.route('**/api/**', route => route.abort())
  296 |   await page.getByLabel('导入录制', { exact: true }).setInputFiles(output)
  297 |   await expect(page.getByRole('button', { name: '关闭回放', exact: true })).toBeVisible()
  298 |   const writes: string[] = []
  299 |   page.on('request', request => { if (/\/api\//.test(request.url()) && ['POST', 'PUT', 'DELETE'].includes(request.method())) writes.push(request.url()) })
  300 | 
  301 |   await page.getByRole('button', { name: '跳到最后一天' }).click()
  302 |   await expect(page.locator('.replay-day')).toHaveText(/第 \d+ \/ \d+ 日/)
  303 |   // 相邻两日合并为一个聚合徽标：打开后选第二天（末日）那笔再固定
  304 |   await expect(page.locator('.trade-marker-badge')).toHaveCount(1)
  305 |   await page.locator('.trade-marker-badge').click()
  306 |   await expect(panel(page)).toBeVisible()
  307 |   await panel(page).locator('.details-list button', { hasText: '#2' }).click()
  308 |   await panel(page).getByRole('button', { name: '固定', exact: true }).click()
  309 |   await expect(factValue(page, '日期')).toHaveText('2026-09-02')
  310 | 
  311 |   // 退至成交日前：选中成交消失，面板立即清空（含固定）；日1成交仍显示
  312 |   await page.getByRole('button', { name: '上一日', exact: true }).click()
  313 |   await expect(page.locator('.trade-marker-badge')).toHaveCount(1)
  314 |   await expect(panel(page)).toHaveCount(0)
  315 | 
  316 |   // 回到成交日：无固定残留，可重新打开
  317 |   await page.getByRole('button', { name: '下一日', exact: true }).click()
  318 |   await expect(page.locator('.trade-marker-badge')).toHaveCount(1)
  319 |   await expect(panel(page)).toHaveCount(0)
  320 |   await page.locator('.trade-marker-badge').click()
  321 |   await expect(panel(page)).toBeVisible()
  322 |   await page.keyboard.press('Escape')
  323 |   expect(writes).toEqual([])
  324 |   await shot(page, 'replay-details')
  325 | })
  326 | 
  327 | test('DETAILS-blind：盲训详情只显示相对日期，真实日期不泄露', async ({ page }) => {
  328 |   const id = await open(page, { blind: true })
  329 |   expect((await page.request.post(`/api/trainings/${id}/trade`, { data: { side: 'buy', weightPct: 1 } })).ok()).toBe(true)
  330 |   await page.reload()
> 331 |   await expect(page.locator('.trade-marker-badge')).toHaveCount(1)
      |                                                     ^ Error: expect(locator).toHaveCount(expected) failed
  332 |   await page.locator('.trade-marker-badge').click()
  333 |   await expect(panel(page)).toBeVisible()
  334 |   await expect(factValue(page, '日期')).toHaveText('今日')
  335 |   const panelText = await panel(page).innerText()
  336 |   expect(panelText).not.toMatch(/\d{4}-\d{2}-\d{2}/)
  337 |   const aria = await page.locator('.trade-marker-badge').getAttribute('aria-label')
  338 |   expect(aria).not.toMatch(/\d{4}-\d{2}-\d{2}/)
  339 |   expect(aria).toContain('今日')
  340 |   // 原生 title 已由详情浮层取代
  341 |   expect(await page.locator('.trade-marker-badge').getAttribute('title')).toBeNull()
  342 |   await shot(page, 'blind')
  343 | })
  344 | 
  345 | test('DETAILS-visual-regression：深浅主题、840/1440px 面板完整可见且徽标无重叠', async ({ page }) => {
  346 |   const id = await open(page)
  347 |   await trainSingleAndCluster(page, id)
  348 |   await page.locator('.trade-marker-badge[data-count="2"]').click()
  349 |   await expect(panel(page)).toBeVisible()
  350 |   await panel(page).getByRole('button', { name: '固定', exact: true }).click()
  351 |   await page.mouse.move(15, 15)
  352 | 
  353 |   async function setTheme(theme: 'dark' | 'light') {
  354 |     const isDark = await page.evaluate(() => document.body.classList.contains('dark'))
  355 |     if ((theme === 'dark') !== isDark) await page.getByRole('button', { name: /切换到(深色|浅色)主题/ }).click()
  356 |   }
  357 | 
  358 |   for (const theme of ['dark', 'light'] as const) {
  359 |     await setTheme(theme)
  360 |     for (const width of [840, 1440]) {
  361 |       await page.setViewportSize({ width, height: 900 })
  362 |       await page.waitForTimeout(350)
  363 |       await expect(panel(page)).toBeVisible()
  364 |       // F4：聚合列表文字必须随主题可读（深色亮字/浅色暗字），不接受深字叠深底
  365 |       const rowColor = await panel(page).locator('.details-list button').first().evaluate(el => getComputedStyle(el).color)
  366 |       const channels = rowColor.match(/\d+/g)!.map(Number)
  367 |       const brightness = channels[0]! + channels[1]! + channels[2]!
  368 |       if (theme === 'dark') expect(brightness).toBeGreaterThan(400)
  369 |       else expect(brightness).toBeLessThan(400)
  370 |       const box = await panel(page).boundingBox()
  371 |       expect(box!.x).toBeGreaterThanOrEqual(0)
  372 |       expect(box!.y).toBeGreaterThanOrEqual(0)
  373 |       expect(box!.x + box!.width).toBeLessThanOrEqual(width)
  374 |       expect(box!.y + box!.height).toBeLessThanOrEqual(900)
  375 |       // 同侧徽标两两无重叠
  376 |       const badges = await page.locator('.trade-marker-badge').evaluateAll(elements => elements.map(el => {
  377 |         const rect = el.getBoundingClientRect()
  378 |         return { side: el.getAttribute('data-side'), left: rect.left, right: rect.right }
  379 |       }))
  380 |       for (const [index, badge] of badges.entries()) {
  381 |         for (const other of badges.slice(index + 1)) {
  382 |           if (badge.side !== other.side) continue
  383 |           expect(badge.right <= other.left || other.right <= badge.left).toBe(true)
  384 |         }
  385 |       }
  386 |       await shot(page, `${theme}-${width}`)
  387 |     }
  388 |   }
  389 | })
  390 | 
```